package com.ubs.wmap.eisl.registryaccessservice.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessBadRequestException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessNotFoundException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryBadRequestException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@CrossOrigin
public class RegistryAccessController{

	private final RegistryReferenceService registryReferenceService;
	
	private final EislClaimsContextUtil eislClaimsContextUtil;
	
	@Value("${service.message.REGISTRY_NOT_FOUND_MSG}")
	private String REGISTRY_NOT_FOUND_MSG;
	
	@Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${service.message.SERVICE_ID_EMPTY_MESSAGE}")
	private String SERVICE_ID_EMPTY;
	
	@GetMapping("/eisl/users/v1/registrations")
	public ResponseEntity<RegistrationResponseVO> getRegistryDetails(@RequestParam("eislToken") String eislToken)
			throws RegistryReferenceException, RegistryAccessBadRequestException, RegistryBadRequestException {
		log.debug("Controller Enetr: Entering getDataReferenceDetails");
		log.debug("eislToken:{}",eislToken);
		String serviceId = (String) eislClaimsContextUtil.getContextParam("serviceId");
		log.debug("serviceId from claim:{}",serviceId);
		if (StringUtils.isEmpty(serviceId)) {
			throw new RegistryBadRequestException(SERVICE_ID_EMPTY);
		}

		RegistrationResponseVO registrationResponse = null;
		try {
			RegistryAccessRequestVO request = new RegistryAccessRequestVO();
			request.setServiceId(serviceId);
			registrationResponse = registryReferenceService.getRegistryReference(request);
			if (null == registrationResponse) {
				log.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new RegistryAccessNotFoundException(REGISTRY_NOT_FOUND_MSG);
			}
		} catch (RegistryReferenceException ex) {
			log.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(registrationResponse);
	}
	
	@PostMapping("/eisl/users/v1/registrations")
	public ResponseEntity<RegistrationResponseVO> postRegistry(@RequestBody RegistrationRequestVO registrationRequestVO,
			@RequestParam("eislToken") String eislToken) throws RegistryReferenceException {
		log.debug("Controller : Entering postRegistry");
		RegistrationResponseVO registrationResponseVO = null;
		try {
			registrationResponseVO = registryReferenceService.persistRegistry(registrationRequestVO);
		} catch (RegistryReferenceException e) {
			log.error( e.getMessage(), e);
			log.debug("Controller : Exiting postRegistry");
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller : Exiting postRegistry");
		return new ResponseEntity<RegistrationResponseVO>(registrationResponseVO, HttpStatus.OK);
	}
}
