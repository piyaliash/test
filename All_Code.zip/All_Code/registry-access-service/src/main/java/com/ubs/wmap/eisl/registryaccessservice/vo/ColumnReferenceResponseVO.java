package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

import lombok.Data;
@Data
public class ColumnReferenceResponseVO implements Serializable {

	private static final long serialVersionUID = 5996480652849234318L;
	
	private Integer columnReferenceId;
	private String Name;
	private String Type;
}
