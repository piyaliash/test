package com.ubs.wmap.eisl.registryaccessservice.repository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.registryaccessservice.model.Registration;

@Repository
public interface RegistrationRepository extends CustomRepository<Registration, Long> {
	
	Registration findByUserId(@Param("userId") String userId);

	Registration findByServiceId(@Param("serviceId") String serviceId);

	Registration findByUserIdAndServiceId(@Param("userId") String userId, @Param("serviceId") String serviceId);
}
