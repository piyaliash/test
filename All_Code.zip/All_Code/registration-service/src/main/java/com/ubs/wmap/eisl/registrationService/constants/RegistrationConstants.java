package com.ubs.wmap.eisl.registrationService.constants;




public class RegistrationConstants {
   
	public static final String INVALID_ESIL_TOKEN = "Invalid Eisl Token";
	public static final String DATA_NOT_FOUND = "Data could not be found";
	
	
	public static final String REGISTRATION_END_POINT = "/eisl/registrations/v1/registrations";


}
