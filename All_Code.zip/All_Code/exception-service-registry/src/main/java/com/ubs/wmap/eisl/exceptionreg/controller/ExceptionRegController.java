package com.ubs.wmap.eisl.exceptionreg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.exceptionreg.controller.delegates.ExceptionDelegate;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegBadRequestException;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@Slf4j
public class ExceptionRegController {


	private final ExceptionDelegate exceptionDelegate;
	
	
	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${app.message.EXCEPTIONREF_NOT_FOUND_MSG}")
	private String EXCEPTIONREF_NOT_FOUND_MSG;
	
	@Value("${app.message.EXCEPTION_SERVICEID_EMPTY_MSG}")
	private String EXCEPTION_SERVICEID_EMPTY_MSG;
	
	
	@RequestMapping(value = "/eisl/exception/v1/exceptions", method = RequestMethod.GET)
	public ResponseEntity<ExceptionResponseSO> getExceptionDetails(@RequestParam("exceptionServiceId") String exceptionServiceId )
			throws ExceptionRegException, ExceptionRegBadRequestException, ExceptionRefNotFoundException {
		log.debug("exceptionServiceId:{}",exceptionServiceId);
		ExceptionResponseSO exceptionResponseSO = null;
		
		if(StringUtils.isEmpty(exceptionServiceId)) {
			throw new ExceptionRegBadRequestException(EXCEPTION_SERVICEID_EMPTY_MSG);
		}
		
		try {
			exceptionResponseSO = exceptionDelegate.getExceptionDetails(exceptionServiceId);
			if (exceptionResponseSO == null) {
				throw new ExceptionRefNotFoundException(EXCEPTIONREF_NOT_FOUND_MSG + ": " +exceptionServiceId);
			}

		} catch (ExceptionRegException exceptionRefException) {
			log.error( exceptionRefException.getMessage(), exceptionRefException);
			throw new ExceptionRegException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(exceptionResponseSO);
	}
	
	
	@RequestMapping(value = "/eisl/exception/v1/exception", method = RequestMethod.POST)
	public ResponseEntity<ExceptionResponseSO> saveExceptionDetails(@RequestBody ExceptionRequestSO exceptionRequestSO)
			throws ExceptionRegException, ExceptionRegBadRequestException {
		log.debug("exceptionRequestSO:{}",exceptionRequestSO);
		ExceptionResponseSO exceptionResponseSO = null;
		
		try {
			exceptionResponseSO = exceptionDelegate.saveExceptionDetails(exceptionRequestSO);

		} catch (ExceptionRegException exceptionRefException) {
			log.error( exceptionRefException.getMessage(), exceptionRefException);
			throw new ExceptionRegException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("exceptionResponseSO:{}",exceptionResponseSO);
		return ResponseEntity.ok(exceptionResponseSO);
	}
}
