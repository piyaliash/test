package com.ubs.wmap.eisl.exceptionreg.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ubs.wmap.eisl.exceptionreg.controller.ExceptionRegController;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionControllerTest {

	@Autowired
	private ExceptionRegController eventController;

	@Test
	public void eventControllerDataTest() throws Exception {

		ResponseEntity<ExceptionResponseSO> responseEntity = eventController.getExceptionDetails("1");
		assertNotNull(responseEntity);
	}

	@Test
	public void eventControllerWithoutDataTest() throws Exception {
		try {
			ResponseEntity<ExceptionResponseSO> responseEntity = eventController.getExceptionDetails("3");
			assertNotNull(responseEntity);
		} catch (ExceptionRefNotFoundException ex) {
			assertTrue(true);
		}
	}

}
