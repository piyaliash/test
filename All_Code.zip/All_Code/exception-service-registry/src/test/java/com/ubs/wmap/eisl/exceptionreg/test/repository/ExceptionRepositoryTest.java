package com.ubs.wmap.eisl.exceptionreg.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ubs.wmap.eisl.exceptionreg.model.ExceptionReference;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionRefRepository;


@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionRepositoryTest {

	@Autowired
	private ExceptionRefRepository eventRepository;

	@Test
	public void testfindByServiceIdWithData() throws Exception {
		ExceptionReference values = eventRepository.findByExceptionServiceId(new Integer(1));
		assertNotNull(values);
	}
	
	
	/*@Test
	public void testfindByServiceIdWithOutData() throws Exception {
		ExceptionReference values = eventRepository.findByExceptionServiceId(new Integer(2));
		assertNull(values);
	}*/

}
