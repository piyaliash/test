package com.ubs.wmap.eisl.dataserviceregistry.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataFilterReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataOutReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataFilterReferenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataOutReferenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataRefefrenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataReferenceServiceImpl implements DataReferenceService {
	
	private final DataRefefrenceRepository dataRefefrenceRepository;
	
	private final DataOutReferenceRepository dataOutReferenceRepository;
	
	private final DataFilterReferenceRepository dataFilterReferenceRepository;
	
	@Value("${service.message.DATA_REFERENCE_NOT_FOUND_MSG}")
	private String DATA_REFERENCE_NOT_FOUND_MSG;
	
	@Override
	public DataReferenceResponse getDataReference(DataReferenceRequest dataReferenceRequest)
			throws DataReferenceException {
		log.debug("Service Enter:Inside getDataReference");
		log.debug("DataReferenceRequest : {}",dataReferenceRequest);
		DataReferenceResponse response = null;
		DataReference dataReference = dataRefefrenceRepository
				.findBydataServiceId(dataReferenceRequest.getDataServiceId());
		if (dataReference == null) {
			throw new DataReferenceNotFoundException(DATA_REFERENCE_NOT_FOUND_MSG);
		} else {
			response = constructDataReference(dataReference);
			if (dataReference.getDataOutReferences() != null) {
				response.setDataOutReferences(constructDataOutReferences(dataReference.getDataOutReferences()));
			}
		}
		log.debug("DataReferenceResponse : {}",response);
		log.debug("Service Exit:Exiting getDataReference");
		return response;
	}
	
	private Set<DataOutReferenceResponse> constructDataOutReferences(Set<DataOutReference> dataOutReferences) {
		Set<DataOutReferenceResponse> dataOutSet = new HashSet<>();
		for (DataOutReference dataOutReference : dataOutReferences) {
			DataOutReferenceResponse constructDataOutReference = constructDataOutReference(dataOutReference);
			dataOutSet.add(constructDataOutReference);
		}
		return dataOutSet;
	}

	private DataFilterResponse constructDataFilterResponse(DataFilterReference dataFilterReference) {
		DataFilterResponse dataFilterResponse = new DataFilterResponse();
		BeanUtils.copyProperties(dataFilterReference, dataFilterResponse);
		return dataFilterResponse;
	}
	
	private DataOutReferenceResponse constructDataOutReference(DataOutReference dataOutReference) {
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		DataFilterReference dataFilterReference = dataOutReference.getDataFilterReference();
		DataFilterResponse constructDataFilterResponse = null;
		if(dataFilterReference != null) {
			constructDataFilterResponse = constructDataFilterResponse(dataFilterReference);
		}
		BeanUtils.copyProperties(dataOutReference, dataOutReferenceResponse);
		dataOutReferenceResponse.setDataFilterReference(constructDataFilterResponse);
		return dataOutReferenceResponse;
	}
	private DataReferenceResponse constructDataReference (DataReference dataReference){
		DataReferenceResponse dataReferenceResponse = new DataReferenceResponse();
		BeanUtils.copyProperties(dataReference, dataReferenceResponse);
		return dataReferenceResponse;
	}
	
	@Transactional
	@Override
	public DataReferenceResponse saveDataReference(DataReferenceRequest dataReferencerequest)
			throws DataReferenceException {
		//Save Parent
		DataReference dataReference=constructDataReferenceEntityFromSO(dataReferencerequest);
		dataRefefrenceRepository.save(dataReference);
		dataRefefrenceRepository.flush();
		//Save child 
		saveDataOutRefefrence(dataReferencerequest, dataReference);
		//get latest data
		dataRefefrenceRepository.refresh(dataReference);
		DataReferenceResponse response = null;
		Optional<DataReference> dataRef = dataRefefrenceRepository.findById(dataReference.getDataReferenceId());
		if(dataRef.isPresent()) {
			DataReference drLatest = dataRef.get();
			response = constructDataReference(drLatest);
			if (drLatest.getDataOutReferences() != null) {
				response.setDataOutReferences(constructDataOutReferences(drLatest.getDataOutReferences()));
			}
		}
		return response;
	}

	private void saveDataOutRefefrence(DataReferenceRequest dataReferencerequest, DataReference dataReference) {
		List<DataOutReferenceRequest> outReferenceRequests = dataReferencerequest.getOutReferenceRequests();
		if (!CollectionUtils.isEmpty(outReferenceRequests)) {
			for (DataOutReferenceRequest outReferenceRequest : outReferenceRequests) {
				DataOutReference dataOutReference = constructDataOutRefEntityFromSO(outReferenceRequest);
				dataOutReference.setDataOutReference(dataReference);
				dataOutReferenceRepository.save(dataOutReference);
				if (outReferenceRequest.getDataFilterReferenceRequest() != null) {
					DataFilterReference dataFilterReference = ConstructDataFilterRefFromSO(
							outReferenceRequest.getDataFilterReferenceRequest());
					dataFilterReference.setDataOutReference(dataOutReference);
					dataFilterReferenceRepository.save(dataFilterReference);
					dataOutReference.setDataFilterReference(dataFilterReference);
				}
			}
		}
	}
	
	private DataFilterReference ConstructDataFilterRefFromSO(DataFilterReferenceRequest dataFilterReferenceRequest) {
		DataFilterReference dataFilterReference = new DataFilterReference();
		BeanUtils.copyProperties(dataFilterReferenceRequest, dataFilterReference);
		return dataFilterReference;
	}

	private DataReference constructDataReferenceEntityFromSO(DataReferenceRequest dataReferencerequest){
		DataReference dataReference= new DataReference();
		BeanUtils.copyProperties(dataReferencerequest, dataReference);
		return dataReference;
		
	}
	private DataOutReference constructDataOutRefEntityFromSO(DataOutReferenceRequest dataOutReferenceRequest){
		DataOutReference dataOutReference= new DataOutReference();
		BeanUtils.copyProperties(dataOutReferenceRequest, dataOutReference);
		return dataOutReference;
		
	}
}
