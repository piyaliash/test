package com.ubs.wmap.eisl.dataserviceregistry.repository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;

@Repository
public interface DataRefefrenceRepository extends CustomRepository<DataReference, Integer> {

	DataReference findBydataServiceId(@Param("dataServiceId") String dataServiceId);
	
}
