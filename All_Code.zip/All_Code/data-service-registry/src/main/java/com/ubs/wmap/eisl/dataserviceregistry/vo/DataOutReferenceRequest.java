package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
public class DataOutReferenceRequest implements Serializable {
	
	private static final long serialVersionUID = -83396507865626884L;
	
	private Integer dataOutReferenceId;
	private String protocolName;
	private String dataType;
	private String topic;
	@EqualsAndHashCode.Exclude
	private DataFilterReferenceRequest dataFilterReferenceRequest;
}
