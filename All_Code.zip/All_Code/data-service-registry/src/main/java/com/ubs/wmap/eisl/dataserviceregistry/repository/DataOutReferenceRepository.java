package com.ubs.wmap.eisl.dataserviceregistry.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.dataserviceregistry.model.DataOutReference;

@Repository
public interface DataOutReferenceRepository extends JpaRepository<DataOutReference, Integer> {

}
