package com.ubs.wmap.eisl.dataserviceregistry.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataRegistryBadRequestException;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataServiceRegistryController {

	private final DataReferenceService dataReferenceService;
	
	@Value("${service.message.DATA_REFERENCE_NOT_FOUND_MSG}")
	private String DATA_REFERENCE_NOT_FOUND_MSG;
	
	@Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${service.message.SERVICE_ID_EMPTY}")
	private String SERVICE_ID_EMPTY;
	
	@GetMapping("/eisl/data/v1/data")
	public ResponseEntity<DataReferenceResponse> getDataReferenceDetails(@RequestParam("eislToken") String eislToken,@RequestParam("dataServiceId") String dataServiceId)
			throws DataReferenceException, DataRegistryBadRequestException {
		log.debug("Controller : Entering getDataReferenceDetails");
		log.debug("token:{}", eislToken);
		log.debug("dataServiceId:{}", dataServiceId);
		if (StringUtils.isEmpty(dataServiceId)) {
			throw new DataRegistryBadRequestException(SERVICE_ID_EMPTY);
		}
		DataReferenceResponse dataReference = null;
		try {
			DataReferenceRequest request = new DataReferenceRequest();
			request.setDataServiceId(dataServiceId);
			dataReference = dataReferenceService.getDataReference(request);
			if (null == dataReference) {
				log.debug("Controller: Exiting getDataReferenceDetails");
				throw new DataReferenceNotFoundException(DATA_REFERENCE_NOT_FOUND_MSG);
			}
		} catch (DataReferenceException ex) {
			log.debug("Controller: Exiting getDataReferenceDetails");
			throw new DataReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(dataReference);
	}
	
	@PostMapping("/eisl/data/v1/data")
	public ResponseEntity<DataReferenceResponse> postDataReference(
			@RequestBody DataReferenceRequest dataReferencerequest, @RequestParam("eislToken") String eislToken)
			throws DataReferenceException, DataRegistryBadRequestException {
		log.debug("Controller : Entering postdatareferencemethod");
		log.debug("token:{}", eislToken);
		DataReferenceResponse persistDataReference = null;
		try {
			persistDataReference = dataReferenceService.saveDataReference(dataReferencerequest);
		} catch (DataReferenceException e) {
			log.error(e.getMessage(), e);
			log.debug("Controller : Exiting postdatareferencemethod");
			throw new DataReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller : Exiting postdatareferencemethod");
		return new ResponseEntity<DataReferenceResponse>(persistDataReference, HttpStatus.OK);
	}
}
