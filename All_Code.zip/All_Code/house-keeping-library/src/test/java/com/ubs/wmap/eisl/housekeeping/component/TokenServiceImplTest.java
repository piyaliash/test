package com.ubs.wmap.eisl.housekeeping.component;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Import(TokenServiceConfiguration.class)
@Slf4j
public class TokenServiceImplTest {

    @Autowired
    TokenService tokenService;

    @Test
    public void testInitiazationEISL() {
        String eislToken = tokenService.init("uesr123","TestService1","admin");
       log.info("EISL Token Generated: {}", eislToken);
        assertNotNull(eislToken);
    }

    @Test
    public void testEISLTokenValidation() {
        String eislToken = tokenService.init("Utkarsh","get_acc","admin");
        log.info("EISL Token Generated: {}", eislToken);
        assertTrue(tokenService.isEISLTokenValid(eislToken));
    }

    @Test
    public void test() {
        boolean eislToken = tokenService.isEISLTokenValid("eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs");
        log.info("EISL Token Generated: {}", eislToken);

    }

}