package com.ubs.wmap.eisl.housekeeping;

import javax.validation.constraints.NotBlank;

import io.jsonwebtoken.Claims;

public interface TokenService {

    String init(@NotBlank String userId, @NotBlank String serviceId, @NotBlank String role);
    boolean isEISLTokenValid(@NotBlank String eislToken);
    Claims unwrapEislToken(@NotBlank String token);

   /* boolean isBasicTokenValid(@NotBlank String basicToken);
    String buildBasicToken(@NotBlank String basicToken, @NotBlank String serviceId);
    Claims unwrapBasicToken(@NotBlank String token);
    */

}