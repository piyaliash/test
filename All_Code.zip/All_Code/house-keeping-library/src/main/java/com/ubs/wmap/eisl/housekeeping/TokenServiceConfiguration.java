package com.ubs.wmap.eisl.housekeeping;

import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.ubs.wmap.eisl.housekeeping")
public class TokenServiceConfiguration {

    @Bean
    public TokenService tokenService() {
        return new TokenServiceImpl();
    }

}