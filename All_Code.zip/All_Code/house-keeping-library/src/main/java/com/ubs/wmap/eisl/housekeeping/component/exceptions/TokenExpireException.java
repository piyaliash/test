package com.ubs.wmap.eisl.housekeeping.component.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class TokenExpireException extends RuntimeException {

    private static final String MESSAGE_PREFIX = "The JWT token is Expired";

    public TokenExpireException(String message, Throwable cause) {
        super(MESSAGE_PREFIX + ": " + message + ".");
    }
}
