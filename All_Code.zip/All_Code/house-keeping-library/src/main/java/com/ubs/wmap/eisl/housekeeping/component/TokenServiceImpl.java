package com.ubs.wmap.eisl.housekeeping.component;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.util.AuthorizationHelper;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;
import java.util.Map;

@Component
//@ComponentScan(basePackages = { "com.ubs.wmap.eisl.*" })
@PropertySource("classpath:config.properties")
public class TokenServiceImpl implements TokenService {


    @Value("${eisl.tokenLifeTimeMls}")
    private long tokenLifeTimeMls;

    @Value("${eisl.userNameClaim}")
    private String userNameClaim;

    @Value("${eisl.serviceIdClaim}")
    private String serviceIdClaim;

    @Value("${eisl.public_key}")
    private String eislPublicKey;

    @Value("${eisl.private_key}")
    private String eislPrivateKey;

    @Value("${eisl.basic_public_key}")
    private String basicPublicKey;

    @Value("${eisl.basic_private_key}")
    private String basicPrivateKey;

    @Value("${eisl.role}")
    private String role;

    @Autowired
    private EislTokenGenerator eislTokenGenerator;

    @Autowired
    private AuthorizationHelper authorizationHelper;

    @Override
    public String init(@NotBlank String userName, @NotBlank String serviceId, @NotBlank String roleInput ) {

        Map<String, Object> eislClaims = new HashMap<>();
        eislClaims.put(userNameClaim, userName);
        eislClaims.put(serviceIdClaim, serviceId);
        eislClaims.put(role, roleInput);

        Map<String, Object> eislClaim = eislTokenGenerator.getEislClaims(eislClaims);
        return authorizationHelper.encryptJwtToken(eislClaim, eislPrivateKey, tokenLifeTimeMls);
    }

    @Override
    public boolean isEISLTokenValid(@NotBlank String eislToken) {
        return authorizationHelper.isValidToken(eislToken, eislPublicKey);
    }

    @Override
    public Claims unwrapEislToken(@NotBlank String token) {
        return authorizationHelper.decryptJwtToken(token, eislPublicKey);
    }

    /* Code put as placeholder for basic token

    @Override
    public boolean isBasicTokenNotValid(@NotBlank String basicToken) {
        return !isBasicTokenValid(basicToken);
    }


    @Override
    public String buildBasicToken(@NotBlank String userName, @NotBlank String password) {


        Map<String, Object> inputParams = new HashMap<>();
        inputParams.put(userNameClaim, userName);
        return authorizationHelper.encryptJwtToken(inputParams, basicPrivateKey, tokenLifeTimeMls);
    }

    @Override
    public Claims unwrapBasicToken(@NotBlank String token) {
        return authorizationHelper.decryptJwtToken(token, basicPublicKey);
    }


    */


}
