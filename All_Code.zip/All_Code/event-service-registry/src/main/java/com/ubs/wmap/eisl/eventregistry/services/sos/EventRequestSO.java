package com.ubs.wmap.eisl.eventregistry.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class EventRequestSO implements Serializable{
	
	private static final long serialVersionUID = -998787659770475488L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;

	
}
