package com.ubs.wmap.eisl.eventregistry.exception;

public class EventException extends RuntimeException  {
	
	private static final long serialVersionUID = 8089713711480335861L;

	public EventException(String message) {
		super(message);
	}
	

}
