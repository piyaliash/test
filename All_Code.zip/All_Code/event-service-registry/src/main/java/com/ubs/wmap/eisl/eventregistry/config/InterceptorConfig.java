package com.ubs.wmap.eisl.eventregistry.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ubs.wmap.eisl.eventregistry.interceptor.EventInterceptor;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

	
	private final EventInterceptor eventInterceptor;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(eventInterceptor).addPathPatterns("/**")
	    .excludePathPatterns("/v2/api-docs", "/configuration/ui", 
	            "/swagger-resources/**", "/configuration/**", "/swagger-ui.html"
	            , "/webjars/**", "/csrf", "/");
	}

	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry.addResourceHandler("swagger-ui.html")
	      .addResourceLocations("classpath:/META-INF/resources/");

	    registry.addResourceHandler("/webjars/**")
	      .addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
}
