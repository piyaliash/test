package com.ubs.wmap.eisl.eventregistry.exception;

public class EventNotFoundException extends Exception{
	
	private static final long serialVersionUID = -7408420202454263359L;

	public EventNotFoundException(String message) {
		super(message);
	}

}
