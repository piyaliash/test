package com.ubs.wmap.eisl.eventregistry.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.eventregistry.context.EislClaimsContext;
import com.ubs.wmap.eisl.eventregistry.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.eventregistry.controller.EventController;
import com.ubs.wmap.eisl.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

import io.jsonwebtoken.Claims;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@Import(TokenServiceConfiguration.class)
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.eventregistry" })
public class EventControllerTest {

	@Autowired
	private EventController eventController;
	
	@Autowired
	private TokenService tokenService;

	@Test
	public void testEventControllerwithData() throws Exception {
		
		//create context
		createEislContext();

		ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("eislToken");
		assertNotNull(responseEntity);
	}

	@Test
	public void testPostEventData() throws Exception {
		createEislContext();
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId("service11");
		eventRequestSO.setServiceName("service11Name");
		eventRequestSO.setEventTopic("topic11");
		eventRequestSO.setExceptionServiceId(Integer.valueOf(1));
		ResponseEntity<EventResponseSO> responseEntity = eventController.saveEventDetails("eislToken",eventRequestSO);
		assertNotNull(responseEntity.getBody().getEventServiceId());
	
	}
	
	
	@Test
	public void testEeventControllerWithoutData() throws Exception {
		createEislContext();
		try {
			ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("eislToken");
			assertNotNull(responseEntity);
		} catch (EventNotFoundException ex) {
			assertTrue(true);
		}
	}
	
	public void createEislContext() {
		/** This is just for testing and to be remove**/
		String eislToken = tokenService.init("userid", "1", "Admin");
		Claims claims = tokenService.unwrapEislToken(eislToken);
		createAndSetClaimsInContext(claims);
	}
	
	
	private void createAndSetClaimsInContext(Claims claims) {
		EislClaimsContext eislClaimsContext = new EislClaimsContext();
		eislClaimsContext.setClaims(claims);
		EislClaimsContextHolder.set(eislClaimsContext);
	}

	
}
