package com.ubs.wmap.eisl.eventregistry.test.services;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.eventregistry.services.EventService;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;

@RunWith(SpringRunner.class)
@EnableAutoConfiguration
@DataJpaTest
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.eventregistry"})
public class EventServiceTest {
	
	@Autowired
	private EventService eventService;
	
	@Test
	public void testGetEventDetailsWithData() throws Exception {
		EventRequestSO eventRequestSO=new EventRequestSO();
		eventRequestSO.setServiceId("1");
		EventResponseSO eventResponseSO = eventService.getEventDetails(eventRequestSO);
		assertNotNull(eventResponseSO);
	}
	
	@Test
	public void testGetEventDetailsWithOutData() throws Exception {
		EventRequestSO eventRequestSO=new EventRequestSO();
		eventRequestSO.setServiceId("3");
		EventResponseSO eventResponseSO = eventService.getEventDetails(eventRequestSO);
		assertNull(eventResponseSO);
	}
	
	
	@Test
	public void testSaveEventData() throws Exception {
		
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId("service11");
		eventRequestSO.setServiceName("service11Name");
		eventRequestSO.setEventTopic("topic11");
		eventRequestSO.setExceptionServiceId(Integer.valueOf(1));
		EventResponseSO eventResponseSO = eventService.saveEventDetails(eventRequestSO);
		assertNotNull(eventResponseSO);
	
	}
}
