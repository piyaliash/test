package com.ubs.wmap.eisl.mappingservice.exception;

public class MappingDataFoundException extends Exception{

    public MappingDataFoundException(String message) {
        super(message);
    }
}
