package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("squid:S1068")
@Data
public class MappingResponseSO implements Serializable {

    private Long mappingId;

    private Integer orderNumber;

    private Integer sequence;

    private Long ubsAttributeId;

    private String ubsAtrributeName;

    private Long ontologyAttributeId;

    private String ontologyAtrributeName;

    private MappingFormatResponseSO mappingFormatResponseSO;

    private List<EnumMappingResponseSO> enumMappingResponseSOS;
}
