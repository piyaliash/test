package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("squid:S1068")
@Data
public class OntologyEnumResponseSO implements Serializable{

    private static final long serialVersionUID = -2405172041950251807L;

    private Long ontologyEnumId;

    private String description;

    private String audit;

    private String enumName;

    private ArrayList<OntologyEnumDetailsResponseSO> ontologyEnumDetails;
}
