package com.ubs.wmap.eisl.mappingservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@SuppressWarnings("squid:S1068")
@Data
public class UbsAttributeListResponseSO {

    @JsonProperty("result")
    private List<UbsAttributeResponseSO> ubsAttributeResponseSOList;
}
