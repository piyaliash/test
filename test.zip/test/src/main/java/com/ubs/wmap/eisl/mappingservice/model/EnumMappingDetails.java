package com.ubs.wmap.eisl.mappingservice.model;

import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Entity
@Table(name = "ENUM_MAPPING_DETAILS", schema = "mapping")
@EntityListeners(AuditingEntityListener.class)
@DynamicUpdate
public class EnumMappingDetails implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "enum_mapping_id")
    private Long enumMappingId;

    @Column(name = "enum_ubs_id")
    private Long enumUbsId;

    @Column(name = "enum_ontology_id")
    private Long enumOntologyId;

    @Column(name = "format_id")
    private Long formatId;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private String createdDate;

    @Column(name = "modified_by")
    private String modifieddBy;

    @Column(name = "modified_date")
    private String modifiedDate;

}
