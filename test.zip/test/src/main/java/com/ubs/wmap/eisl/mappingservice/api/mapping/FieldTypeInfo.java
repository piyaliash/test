package com.ubs.wmap.eisl.mappingservice.api.mapping;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldTypeInfo {
  FieldType type;
  Optional<String> typeName;



  public enum FieldType {
    STRING,
    NUMBER,
    ENUM,
    OBJECT,
    DATETIME,
    DATE,
    TIME,
    UNKNOWN,
    BOOLEAN,
    DEFAULT
  }
}
