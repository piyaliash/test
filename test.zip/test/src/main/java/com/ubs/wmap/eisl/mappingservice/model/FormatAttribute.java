package com.ubs.wmap.eisl.mappingservice.model;


import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Entity
@Table(name = "FORMAT_ATTRIBUTE")
@EntityListeners(AuditingEntityListener.class)
@DynamicUpdate
public class FormatAttribute implements Serializable {

    private static final long serialVersionUID = 3770085916847755446L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FORMAT_ID")
    private Long formatId;

    @Column(name = "FORMAT_TYPE")
    private String formatType;

    @Column(name = "DOMAIN_NAME")
    private String domain;

    @Column(name = "SUBDOMAIN_NAME")
    private String subDomain;

    @Column(name = "DESCRIPTION")
    private String description;

}
