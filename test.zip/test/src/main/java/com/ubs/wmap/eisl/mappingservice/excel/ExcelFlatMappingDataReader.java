package com.ubs.wmap.eisl.mappingservice.excel;

import java.io.IOException;
import java.io.InputStream;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class ExcelFlatMappingDataReader implements FlatMappingDataReader {

    private static final int MAPPING_DATA_SHEET_INDEX = 0;
    private static final int ENUM_DATA_SHEET_INDEX = 1;
    private final MappingDefinitionReader mappingDefinitionReader;
    private final EnumMappingDefinitionReader enumMappingDefinitionReader;

    @Override
    public FlatMappingData readFlatMappingData(InputStream inputStream)
            {
        FlatMappingData flatMappingData = new FlatMappingData();
        try {
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

            XSSFSheet sheet = workbook.getSheetAt(MAPPING_DATA_SHEET_INDEX);
            XSSFSheet enumSheet = workbook.getSheetAt(ENUM_DATA_SHEET_INDEX);

            flatMappingData.setMappingDefinitions(mappingDefinitionReader.readMappingDefinitions(sheet));
            flatMappingData.setEnumMappingDefinitions(
                    enumMappingDefinitionReader.readEnumMappingDefinitions(enumSheet));

        } catch (IOException ioException) {
            log.error("Exception while reading excel sheet", ioException);
            throw new FlatMappingDataReaderException(
                    "Failed to open Excel spreadsheet for processing", ioException);
        }
        log.debug("flatMappingData:{}", flatMappingData);
        return flatMappingData;
    }
}
