package com.ubs.wmap.eisl.mappingservice.exception;

public class ServiceUnavailableException extends Exception{

    public ServiceUnavailableException(String message) {
        super(message);
    }
}
