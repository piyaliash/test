package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class UbsEnumDetailsResponseSO implements Serializable {

    private static final long serialVersionUID = -1905122041950251207L;

    private Long ubsEnumDetailsId;
    private String enumKey;
    private String enumKeyValue;
}
