package com.ubs.wmap.eisl.mappingservice.exception;

import lombok.Data;

import java.time.Instant;

@SuppressWarnings("squid:S1068")
@Data
public class ErrorDetails {

	private String message;
	private String details;
	private Instant timestamp;

	public ErrorDetails(String message, String details) {
		super();
		this.timestamp =  Instant.now();
		this.message = message;
		this.details = details;
	}
}