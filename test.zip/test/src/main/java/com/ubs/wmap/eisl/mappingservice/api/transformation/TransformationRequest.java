package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransformationRequest {
  @NotBlank private String entityName;
  @NotBlank private String sourceFormatName;
  @NotBlank private String destinationFormatName;
  @NotNull private JsonNode source;
}
