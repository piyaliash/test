package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.DecimalNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.databind.node.ValueNode;
import com.ubs.wmap.eisl.mappingservice.api.mapping.BooleanValues;
import com.ubs.wmap.eisl.mappingservice.api.mapping.EnumDetails;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.SourceFieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.TargetFieldMappingInformation;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;

import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@SuppressWarnings("squid:S1612")

@Slf4j
@Service
@RequiredArgsConstructor
public class FormatterService {

    /**
     * Transform source value to target value based on formatter type e:g NumberFormatter, StringFormmater, Default value
     * @param mapping
     * @param value
     * @return
     * @throws ParseException
     */

    public ValueNode toValueNode(TargetFieldMappingInformation mapping, Optional<Object> value) throws ParseException {
        Optional<String> formatvalue = mapping.getFormat();
        Optional<String> defaultValuevalue=mapping.getDefaultValue();
        if (!value.isPresent()) {
          return TextNode.valueOf(mapping.getDefaultValue().orElse(""));
        }
    switch (mapping.getTypeInfo().getType()) {
      case NUMBER:
        if (!mapping.getFormat().isPresent()) {
          return DecimalNode.valueOf((BigDecimal) value.get());
        }
        DecimalFormat df = new DecimalFormat(formatvalue.isPresent()?formatvalue.get():null);
        return TextNode.valueOf(df.format(value.get()));
        case DATETIME:
        try{
          return TextNode.valueOf(
                  ((LocalDateTime) value.get())
                          .format(
                                  DateTimeFormatter.ofPattern(formatvalue.isPresent()?formatvalue.get():null, Locale.getDefault())));
        }catch(Exception ex) {
            return transformDateTime(formatvalue,mapping,value);
        }
        case TIME:
        return TextNode.valueOf(
            ((LocalTime) value.get())
                .format(
                    DateTimeFormatter.ofPattern(mapping.getFormat().orElseGet(null), Locale.getDefault())));
      case STRING:

          String finalResult = transformStringValue(formatvalue,defaultValuevalue,mapping,value);
          mapping
            .getSize()
            .ifPresent(
                size -> {
                  if (finalResult.length() > size)
                    throw new IllegalArgumentException(
                        "The target field '"
                            + mapping.getName()
                            + "' is defined with a size of '"
                            + size
                            + "' but the value of the source field '"
                            + finalResult.length()
                            + "' which is larger than the target field size.");
                });
        return TextNode.valueOf(finalResult);
      case ENUM:
          return transformEnumValue(mapping, value);
      case BOOLEAN:
          return transformBooleanValue(mapping, value);
        default:
        return TextNode.valueOf(value.get().toString());
    }
  }

    /**
     * Transform source value to target value based on formatter type for Dates using Dateformatter
     * @param formatvalue
     * @param mapping
     * @param value
     * @return
     * @throws ParseException
     */
    private ValueNode transformDateTime(Optional<String> formatvalue, TargetFieldMappingInformation mapping, Optional<Object> value) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(formatvalue.isPresent()?formatvalue.get():null);
        SimpleDateFormat format = new SimpleDateFormat(mapping.getSourceDateFormatter());
        Date date = new Date();
        if(value.isPresent()) {
            date = format.parse(value.get().toString());
        }
        if(formatvalue.isPresent() && formatvalue.get().equalsIgnoreCase(StaticDataAttributes.source_year_formatter.getName())) {
            String century= formatter.format(date).substring(0,2);
            return TextNode.valueOf(century);
        }else{
            return TextNode.valueOf(formatter.format(date));
        }
    }

    /**
     * Transform source value to target value based on formatter type for String using StringFormatter
     * @param formatvalue
     * @param defaultValuevalue
     * @param mapping
     * @param value
     * @return
     */
    private String transformStringValue(Optional<String> formatvalue,Optional<String> defaultValuevalue, TargetFieldMappingInformation mapping, Optional<Object> value){
        String result="";
        if(formatvalue.isPresent() && formatvalue.get().contains(",") && mapping.getDefaultValue().isPresent()&& value.isPresent()) {
            String[] splitformatterValue = formatvalue.get().split(",");
            result = value.get().toString().substring(Integer.parseInt(splitformatterValue[0]), Integer.parseInt(splitformatterValue[1]));
            result = (defaultValuevalue.isPresent()?defaultValuevalue.get():null) + result;
        }else if(formatvalue.isPresent() && formatvalue.get().contains(",")&& value.isPresent()){
            String[] splitformatterValue =  formatvalue.get().split(",");
            result=value.get().toString().substring(Integer.parseInt(splitformatterValue[0]),Integer.parseInt(splitformatterValue[1]));
        }else if(formatvalue.isPresent() && formatvalue.get().contains(StaticDataAttributes.target_noOfLines.getName())&& value.isPresent()){
            int quotient = value.get().toString().trim().length() / Integer.parseInt(StaticDataAttributes.minimum_line_length.getName());
            int remainder = value.get().toString().trim().length() % Integer.parseInt(StaticDataAttributes.minimum_line_length.getName());
            result=getNoOfLines(quotient,remainder);

        }
        else {
            result = String.format(generateFormat(mapping), value.isPresent()?value.get():"");
        }
        return result;
    }

    /**
     * Transform source value to target value based on formatter type for getting noOfLines based on String length
     * @param quotient
     * @param remainder
     * @return
     */
    private String getNoOfLines(int quotient,int remainder) {
        String result="";
        if(quotient>0 && remainder>0){
            result = String.valueOf(quotient+1);
        }else if(quotient==0){
            result = String.valueOf(1);
        }
        else{
            result = String.valueOf(quotient);
        }
        return result;
    }

    /**
     * Transform source value to target value based on length e:g add space if target length is bigger than source field length
     * @param mapping
     * @return
     */
    private String generateFormat(TargetFieldMappingInformation mapping) {
      Optional<String> formatvalue = mapping.getFormat();
    StringBuilder sb = new StringBuilder("%");
    mapping
        .getSize()
        .ifPresent(
            size ->
              sb.append(size));
    if(formatvalue.isPresent()){
        sb.append(formatvalue.get());
    }else {
          sb.append('s');// %-10s  left justified string of length 10
      }
    return sb.toString();
  }

    /**
     * Transform source boolean value to target boolean value value
     * @param mapping
     * @param value
     * @return
     */
  private ValueNode transformBooleanValue(TargetFieldMappingInformation mapping, Optional<Object> value){
      if(mapping.getBooleanDetails()!=null && !mapping.getBooleanDetails().isEmpty()) {
          for (BooleanValues booleanValues :mapping.getBooleanDetails()) {
              if (value.isPresent()&& value.get().toString().equalsIgnoreCase(booleanValues.getSourceBooleanValue())) {
                  return TextNode.valueOf(booleanValues.getTargetBooleanValue());
              }
          }
      }
      throw new IllegalArgumentException("Boolean Mapping Details not present for Mapping transformation");
  }

    /**
     * Transform source enum value to target enum value
     * @param mapping
     * @param value
     * @return
     */
    private ValueNode transformEnumValue(TargetFieldMappingInformation mapping, Optional<Object> value){
        if(mapping.getEnumDetails()!=null && !mapping.getEnumDetails().isEmpty()) {
            for (EnumDetails enumDetails :mapping.getEnumDetails()) {
                if (value.isPresent()&& value.get().toString().equalsIgnoreCase(enumDetails.getSourceEnumValue())) {
                    return TextNode.valueOf(enumDetails.getTargetEnumValue());
                }
            }
        }
        throw new IllegalArgumentException("Enum Mapping Details not present for Mapping transformation");

    }

    /**
     * Transform source value based on formatter type DateFormatter, StringFormatter
     * @param mapping
     * @param sourceFieldNode
     * @return
     */
  public Object fromJsonNode(SourceFieldMappingInformation mapping, JsonNode sourceFieldNode) {
      Optional<String> formatvalue = mapping.getFormat();
    switch (mapping.getTypeInfo().getType()) {
      case DATETIME:
       if( mapping.getFormat().isPresent()){
           try {
               return LocalDateTime.parse(
                       sourceFieldNode.asText(),
                       DateTimeFormatter.ofPattern(formatvalue.isPresent()?formatvalue.get():null, Locale.getDefault()));
           }catch(Exception ex){
               return sourceFieldNode.asText();
           }
       }else{
         return sourceFieldNode.asText();
       }


        case DATE:
        return LocalDate.parse(
            sourceFieldNode.asText(),
            DateTimeFormatter.ofPattern(formatvalue.isPresent()?formatvalue.get():null, Locale.getDefault()));
      case TIME:
        return LocalTime.parse(
            sourceFieldNode.asText(),
            DateTimeFormatter.ofPattern(formatvalue.isPresent()?formatvalue.get():null, Locale.getDefault()));
      case STRING:
      default:
        return sourceFieldNode.asText();
    }
  }
}
