package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.service.MappingMetaDataService;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import com.ubs.wmap.eisl.mappingservice.validation.TokenValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;

@Slf4j
@RestController
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MappingController {

    private final TokenValidator tokenValidator;
    private final MappingMetaDataService mappingMetaDataService;
    private final MessageResourceUtil messageResourceUtil;

    @ApiOperation("Get Mapping Details for given format/copybook name")
    @GetMapping("/mapping")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully get the Mapping details for given format name"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<MappingResponseListSO> getMappings(
            @RequestParam(value = "formatName") String formatName,
            @RequestParam("token") @ApiParam("EISL Token") String token,
            @RequestParam(value = "domain") String domain,
            @RequestParam(value = "subDomain", required = false) String subDomain,
            @RequestParam(value = "fileName", required = false) String fileName
            ) throws MappingDataNotFoundException, ClaimsAttributeNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException, InvalidEislTokenException {
        log.debug("getMappings::formatName:{}", formatName);
        tokenValidator.validate(token);
        MappingResponseListSO mappingResponseListSO = new MappingResponseListSO();
        mappingResponseListSO.setMappingDetailsResponseSOS(
                mappingMetaDataService.getMappings(constructMappingRequest(domain, formatName,subDomain,fileName), token));
        log.debug("mappingResponseListSO::mappingResponseListSO:{}", mappingResponseListSO);
        return ResponseEntity.ok(mappingResponseListSO);
    }

    @ApiOperation("Get all Mapping Format Details")
    @GetMapping("/mappingformat")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully get the all Mapping Format details"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<MappingFormatResponseListSO> getMappingFormatDetails(
            @NotBlank @RequestParam("token") @ApiParam("EISL Token") String token) throws ClaimsAttributeNotFoundException, MappingFormatDataNotFoundException, InvalidEislTokenException {
        tokenValidator.validate(token);
        MappingFormatResponseListSO mappingFormatResponseListSO = new MappingFormatResponseListSO();
        mappingFormatResponseListSO.setMappingFormatResponseSOS(
                mappingMetaDataService.getAllMappingFormats());
        log.debug("mappingFormatResponseListSO::mappingFormatResponseListSO:{}", mappingFormatResponseListSO);
        return ResponseEntity.ok(mappingFormatResponseListSO);
    }

    @ApiOperation("Post Mapping Details")
    @PostMapping("/mapping")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully registred the mapping details for given payload"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<MappingResponseListSO> postMappingDetails(
            @NotBlank @RequestParam("token") @ApiParam("EISL Token") String token,
            @RequestBody MappingUpdateRequestSO mappingUpdateRequestSO) throws ClaimsAttributeNotFoundException, InvalidEislTokenException {
        log.debug("postMappingDetails:{}", mappingUpdateRequestSO);
        tokenValidator.validate(token);
        MappingResponseListSO mappingResponseListSO = new MappingResponseListSO();
        mappingResponseListSO.setMappingDetailsResponseSOS(mappingMetaDataService.saveMappings(mappingUpdateRequestSO));
        return ResponseEntity.ok(mappingResponseListSO);
    }

    @ApiOperation("Update Mapping Details")
    @PutMapping("/mapping")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully updated the mapping details for given payload"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<MappingResponseListSO> updateMappingDetails(
            @NotBlank @RequestParam("token") @ApiParam("EISL Token") String token,
            @RequestBody MappingUpdateRequestSO mappingUpdateRequestSO) throws ClaimsAttributeNotFoundException, MappingDataNotFoundException, MappingKeyNotFoundException, InvalidEislTokenException {
        log.debug("updateMappingDetails:{}", mappingUpdateRequestSO);
        tokenValidator.validate(token);
        MappingResponseListSO mappingResponseListSO = new MappingResponseListSO();
        mappingResponseListSO.setMappingDetailsResponseSOS(mappingMetaDataService.updateMappings(mappingUpdateRequestSO));
        return ResponseEntity.ok(mappingResponseListSO);
    }

    @ApiOperation("Delete all Mapping Details for given format name")
    @DeleteMapping("/mapping")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully deleted the mapping details for given format name"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<String> deleteMappingDetails(
            @NotBlank @RequestParam("token") @ApiParam("EISL Token") String token,
            @NotBlank @RequestParam(value = "formatName") String formatName,
            @NotBlank @RequestParam(value = "domain") String domain,
            @RequestParam(value = "subDomain",required = false) String subDomain,
            @RequestParam(value = "fileName",required = false) String fileName

    ) throws ClaimsAttributeNotFoundException, MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, InvalidEislTokenException {
        log.debug("deleteMappingDetails:{}", formatName);
        tokenValidator.validate(token);
        mappingMetaDataService.deleteMapping(constructMappingRequest(domain, formatName,subDomain,fileName), token);
        return ResponseEntity.ok(messageResourceUtil.getMessage(MessageKeys.DELETE_SUCCESS_MSG.getValue()));
    }

    @ApiOperation("Delete Mapping Details by format name,ontology attribute id and ubs attribute id")
    @DeleteMapping("/deletemapping")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully deleted the mapping details for given ids"),
            @ApiResponse(code = 401, message = "Not authorized to view the resource with the given details"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "The resource trying to reach is not found")})
    public ResponseEntity<String> deleteMappingDetailsByFormatIdAndAttributeId(
            @NotBlank @RequestParam("token") @ApiParam("EISL Token") String token,
            @NotBlank @RequestParam(value = "formatName") String formatName,
            @NotBlank @RequestParam(value = "ontologyAtrributeId") Long ontologyAtrributeId,
            @NotBlank @RequestParam(value = "ubsAtrributeId") Long ubsAtrributeId,
            @NotBlank @RequestParam(value = "domain") String domain) throws ClaimsAttributeNotFoundException, MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, InvalidEislTokenException {
        log.debug("deleteMappingDetails:{}", formatName);
        tokenValidator.validate(token);
        mappingMetaDataService.deleteMappingByFormatNameAndOntologyAndUbsAttributeId(constrctMappingRequestSOForDelete(formatName, domain, ontologyAtrributeId, ubsAtrributeId), token);
        return ResponseEntity.ok(messageResourceUtil.getMessage(MessageKeys.DELETE_SUCCESS_MSG.getValue()));
    }

    private MappingRequestSO constrctMappingRequestSOForDelete(String formatName, String domain, Long ontologyAtrributeId, Long ubsAtrributeId) {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setDomain(domain);
        mappingRequestSO.setFormatName(formatName);
        mappingRequestSO.setUbsAtrributeId(ubsAtrributeId);
        mappingRequestSO.setOntologyAtrributeId(ontologyAtrributeId);
        return mappingRequestSO;
    }

    private MappingRequestSO constructMappingRequest(String domain, String formatName, String subDomain, String fileName) throws BadRequestException {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        if(!StringUtils.isBlank(domain)) {
            mappingRequestSO.setDomain(domain);
        }else{
            throw new BadRequestException(messageResourceUtil.getMessage(MessageKeys.PARAM_DOMAIN_EMPTY.getValue()));
        }
        if(!StringUtils.isBlank(formatName)) {
            mappingRequestSO.setFormatName(formatName);
        }else{
            throw new BadRequestException(messageResourceUtil.getMessage(MessageKeys.PARAM_FORMAT_EMPTY.getValue()));
        }
        if(!StringUtils.isBlank(subDomain)){
            mappingRequestSO.setSubDomain(subDomain);
        }
        if(!StringUtils.isBlank(fileName)){
            mappingRequestSO.setFileName(fileName);
        }
        return mappingRequestSO;
    }


}
