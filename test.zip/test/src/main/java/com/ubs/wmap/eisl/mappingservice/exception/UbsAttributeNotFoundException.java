package com.ubs.wmap.eisl.mappingservice.exception;

public class UbsAttributeNotFoundException extends Exception {

    public UbsAttributeNotFoundException(final String message) {
        super(message);
    }
}
