package com.ubs.wmap.eisl.mappingservice.exception;

public class MappingServiceException  extends Exception{

    public MappingServiceException(String message) {
        super(message);
    }
}
