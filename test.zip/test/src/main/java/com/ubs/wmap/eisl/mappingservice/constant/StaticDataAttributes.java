package com.ubs.wmap.eisl.mappingservice.constant;

@SuppressWarnings("squid:S00115")
public enum StaticDataAttributes {

    DOMAIN_NAME("domain"),
    SUB_DOMAIN_NAME("subdomain"),
    ids("ids"),
    source_date_formatter("MM/dd/yyyy"),
    source_year_formatter("yyyy"),
    target_noOfLines("noOfLines"),
    minimum_line_length("30"),
    SOURCE_ATTRIBUTE("Ontology"),
    ONTOLOGY_ATTRIBUTE_ID("ontologyAttributeId"),
    TARGET_ATTRIBUTE_ID("targetAttributeId"),
    ATTRIBUTE_TYPE_BOOLEAN("BOOLEAN"),
    ATTRIBUTE_TYPE_ENUM("ENUM"),
    ONTOLOGY_ATTRIBUTE_NAME("ONTOLOGY"),
    UBS_ATTRIBUTE_NAME("UBS"),
    SEQUENCE_NO("1"),
    DATE_FORMATTER("/"),
    STRING_FORMATTER("-"),
    TIME_FORMATTER(":"),
    EISL_CLAIMS("claims"),
    EISL_TOKEN("token");

    private String name;

    StaticDataAttributes(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


}
