package com.ubs.wmap.eisl.mappingservice.exception;

public class EnumMappingDataFoundException extends Exception{

    public EnumMappingDataFoundException(String message) {
        super(message);
    }
}
