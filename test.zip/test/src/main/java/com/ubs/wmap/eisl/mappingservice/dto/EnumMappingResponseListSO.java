package com.ubs.wmap.eisl.mappingservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("squid:S1068")
@Data
public class EnumMappingResponseListSO implements Serializable {

    @JsonProperty("result")
    private List<EnumMappingResponseSO> mappingResponseSOS;
}
