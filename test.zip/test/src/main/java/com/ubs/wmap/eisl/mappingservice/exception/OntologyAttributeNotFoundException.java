package com.ubs.wmap.eisl.mappingservice.exception;

public class OntologyAttributeNotFoundException extends Exception {

    public OntologyAttributeNotFoundException(final String message) {
        super(message);
    }
}
