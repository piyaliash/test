package com.ubs.wmap.eisl.mappingservice.excel;

import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@NoArgsConstructor
public class FlatMappingData {

  private List<MappingDefinition> mappingDefinitions;

  private List<EnumMappingDefinition> enumMappingDefinitions;
}
