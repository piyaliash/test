package com.ubs.wmap.eisl.mappingservice.excel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MappingDefinitionReader {

  private static final List<Integer> HEADER_ROWS = Arrays.asList(0);

  public List<MappingDefinition> readMappingDefinitions(XSSFSheet sheet) {
    List<MappingDefinition> mappingDefinitions = new ArrayList<>();
    Map<String, Integer> columnNames = getRowColumnNamesAsMap(sheet);
    for (Row row : sheet) {
      if (!HEADER_ROWS.contains(row.getRowNum())) {
        mappingDefinitions.add(mapCellsToMappingDefinition(row, columnNames));
      }
    }

    return mappingDefinitions;
  }

  private MappingDefinition mapCellsToMappingDefinition(Row row, Map<String, Integer> columnNames) {
    MappingDefinition mappingDefinition = new MappingDefinition();
    FormatDefination formatDefination = new FormatDefination();
    mappingDefinition.setEntity(
        getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.ENTITY.getName()))));
    mappingDefinition.setSourceSystem(
        getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.SOURCEFORMAT.getName()))));
    mappingDefinition.setSourceField(
        getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.SOURCEFIELD.getName()))));
    mappingDefinition.setTargetSystem(
        getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.TARGETFORMAT.getName()))));
    mappingDefinition.setTargetField(
        getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.TARGETFIELD.getName()))));
    mappingDefinition.setOrderNo(
            getIntegerValue(row.getCell(columnNames.get(ExcelSheetColumnNames.ORDERNO.getName()))));
    mappingDefinition.setSequenceNo(
            getIntegerValue(row.getCell(columnNames.get(ExcelSheetColumnNames.SEQUENCENO.getName()))));
    formatDefination.setFormatType(
            getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.FORMATTYPE.getName()))));
    formatDefination.setFormatString(
            getStringValue(row.getCell(columnNames.get(ExcelSheetColumnNames.FORMATSTRING.getName()))));
    mappingDefinition.setFormatDefination( formatDefination);
    return mappingDefinition;
  }

  private Map<String, Integer> getRowColumnNamesAsMap(XSSFSheet sheet) {
    Map<String, Integer> columnNames = new HashMap<>();
    Row firstRow = sheet.getRow(0);
    for (int i = 0; i < firstRow.getLastCellNum(); i++) {
      columnNames.put(firstRow.getCell(i).getStringCellValue(), i);
    }
    return columnNames;
  }

  private String getStringValue(Cell cell) {
    if (cell == null) return null;
    return CellType.STRING.equals(cell.getCellTypeEnum()) ? cell.getStringCellValue() : null;
  }

  private int getIntegerValue(Cell cell) {
    if (cell == null) return 0;
    return Math.toIntExact(CellType.NUMERIC.equals(cell.getCellTypeEnum()) ? Math.round(cell.getNumericCellValue()) : 0);
  }
}
