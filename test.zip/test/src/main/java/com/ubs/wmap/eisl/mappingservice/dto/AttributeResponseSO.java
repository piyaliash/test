package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttributeResponseSO implements Serializable {

    private static final long serialVersionUID = -5931778942382735414L;

    private Long attributeId;

    private String attributeName;

    private String dataType;

    private String description;

    private Integer targetSize;

    private String defaultValue;

    private transient EnumResponseSO enumResponseSO;


}
