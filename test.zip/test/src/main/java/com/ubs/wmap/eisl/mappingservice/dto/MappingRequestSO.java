package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class MappingRequestSO implements Serializable {

    private Long formatId;
    private Long ubsAtrributeId;
    private Long ontologyAtrributeId;
    private String formatName;
    private String domain;
    private String token;
    private String subDomain;
    private String fileName;
}
