package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ValueNode;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import com.ubs.wmap.eisl.mappingservice.util.JsonUtil;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static java.util.Map.Entry.comparingByValue;
import static java.util.stream.Collectors.toMap;


@SuppressWarnings({"squid:S1612","squid:S1643"})

@Service
@Slf4j
@RequiredArgsConstructor
public class TransformationEngine {
    private final FieldTransformerService fieldTransformerService;

  private final FormatterService formatterService;

  private final ObjectMapper objectMapper;
  private  HashMap<String, String> hmap = new HashMap<>();

    /**
     * Transform Source Value to Target Value
     * @param mappingInfo
     * @param sourceRootNode
     * @return
     */
  public JsonNode transform(MappingInformation mappingInfo, JsonNode sourceRootNode) {
    ObjectNode rootNode = objectMapper.createObjectNode();
    mappingInfo.getFieldMappingInformation().stream()
        .forEach(
            mapping -> {
              Optional<Object> interimValue =
                  mapping
                      .getSourceFieldMappingInformation()
                      .map(sourceFieldMappingInfo -> sourceFieldMappingInfo.getName())
                      .map(name -> JsonUtil.getNode(sourceRootNode, name))
                      .map(
                          jsonNode ->
                              formatterService.fromJsonNode(
                                  mapping.getSourceFieldMappingInformation().get(), jsonNode))
                      .map(
                          sourceValue ->
                              fieldTransformerService.convertType(
                                     mapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                                      mapping.getTargetFieldMappingInformation()!=null ? mapping.getTargetFieldMappingInformation().getTypeInfo():null,
                                  sourceValue));
                        if(mapping.getTargetFieldMappingInformation()!=null) {
                          JsonUtil.setAt(
                                  rootNode, mapping.getTargetFieldMappingInformation().getName(), setValueNodeForTargetField(mapping, interimValue));
                        }


            });
    hmap.clear();
    return rootNode;
  }

    /**
     * Store source value in an ordered format in a map for Many source field to one target field
     * @param mapping
     * @param interimValue
     */
  private void setManyToOneOrderMap(FieldMappingInformation mapping, Optional<Object> interimValue){
          Optional<FieldMappingInformation.SourceFieldMappingInformation> sourceFieldMappingInformation= mapping.getSourceFieldMappingInformation();
          if(sourceFieldMappingInformation.isPresent() && interimValue.isPresent()){
          switch (mapping.getTargetFieldMappingInformation().getTypeInfo().getType()) {
              case STRING:
                  hmap.put((String) interimValue.get() + StaticDataAttributes.STRING_FORMATTER.getName() + sourceFieldMappingInformation.get().getSize().toString(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
                  break;
              case NUMBER:
                  hmap.put((String) interimValue.get() + StaticDataAttributes.STRING_FORMATTER.getName() + sourceFieldMappingInformation.get().getSize().toString(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
                  break;
              case DATETIME:
                  setManyToOnderMapIfFieldIsDateTime(mapping,interimValue);
                  break;

              default:
                  break;

          }
      }
  }

    /**
     * Store source value in an ordered format in a map for Many source field to one target field for data type DateTime
     * @param mapping
     * @param interimValue
     */
  private void setManyToOnderMapIfFieldIsDateTime(FieldMappingInformation mapping, Optional<Object> interimValue){
      Optional<FieldMappingInformation.SourceFieldMappingInformation> sourceFieldMappingInformation= mapping.getSourceFieldMappingInformation();
      if(sourceFieldMappingInformation.isPresent() && interimValue.isPresent()) {
          if (sourceFieldMappingInformation.get().getSequenceNo().toString().equalsIgnoreCase(StaticDataAttributes.SEQUENCE_NO.getName())) {
              if (mapping.getTargetFieldMappingInformation().getSourceDateFormatter().equalsIgnoreCase(StaticDataAttributes.source_date_formatter.getName())) {
                  hmap.put((String) interimValue.get() + StaticDataAttributes.DATE_FORMATTER.getName(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
              } else {
                  hmap.put((String) interimValue.get() + " ", sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
              }
          } else {
              if (mapping.getTargetFieldMappingInformation().getSourceDateFormatter().equalsIgnoreCase(StaticDataAttributes.source_date_formatter.getName()) && sourceFieldMappingInformation.get().getSequenceNo() > 2) {
                  hmap.put((String) interimValue.get(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
              } else if (mapping.getTargetFieldMappingInformation().getSourceDateFormatter().equalsIgnoreCase(StaticDataAttributes.source_date_formatter.getName())) {
                  hmap.put((String) interimValue.get() + StaticDataAttributes.DATE_FORMATTER.getName(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
              } else {
                  hmap.put((String) interimValue.get() + StaticDataAttributes.TIME_FORMATTER.getName(), sourceFieldMappingInformation.get().getSequenceNo() + StaticDataAttributes.STRING_FORMATTER.getName() + mapping.getTargetFieldMappingInformation().getOrderNo());
              }

          }
      }
  }

    /**
     * Return final target Value many to one field transformation
     * @param mapping
     * @param orderMap
     * @return
     */
  private String finalValueResponse (FieldMappingInformation mapping, Map<String, String> orderMap){
      String finalValueForSequence="";
      Map<String, String> sorted = orderMap
              .entrySet()
              .stream()
              .sorted(comparingByValue())
              .collect(
                      toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,
                              LinkedHashMap::new));

      for (Map.Entry<String, String> entry : sorted.entrySet()) {
          if(StringUtils.isBlank(mapping.getTargetFieldMappingInformation().getSourceDateFormatter())) {
              String[] splitSourceValue = entry.getKey().split(StaticDataAttributes.STRING_FORMATTER.getName());

              StringBuilder sb = new StringBuilder("%0");
              sb.append(splitSourceValue[1]);
              sb.append('d');

              try {
                  finalValueForSequence = finalValueForSequence + String.format(sb.toString(), Integer.parseInt(splitSourceValue[0]));
              }catch(NumberFormatException ex){
                  finalValueForSequence = finalValueForSequence + splitSourceValue[0];
              }
          }else{
              finalValueForSequence = finalValueForSequence +  entry.getKey();
          }

      }
      if(finalValueForSequence.endsWith(":")) {
          finalValueForSequence = finalValueForSequence.substring(0,finalValueForSequence.length() - 1);
      }
      return finalValueForSequence;
  }

    /**
     * Set final Value Node For Target Field
     * @param mapping
     * @param interimValue
     * @return
     */
  private ValueNode setValueNodeForTargetField(FieldMappingInformation mapping,Optional<Object> interimValue){
      ValueNode finalValue =
              null;
      Optional<FieldMappingInformation.SourceFieldMappingInformation> sourceFieldMappingInformation= mapping.getSourceFieldMappingInformation();
          if (mapping.getTargetFieldMappingInformation().getOrderNo() != null && sourceFieldMappingInformation.isPresent() && sourceFieldMappingInformation.get().getOrderNo().toString().
                  equalsIgnoreCase(mapping.getTargetFieldMappingInformation().getOrderNo().toString())) {

              if (sourceFieldMappingInformation.get().getSize() > 0) {
                  setManyToOneOrderMap(mapping, interimValue);
              }

              Map<String, String> orderMap = hmap.entrySet().stream()
                      .filter(map -> map.getValue().contains(mapping.getTargetFieldMappingInformation().getOrderNo().toString()))
                      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

              finalValue=getfinalValue(mapping, orderMap);

          } else {


                  try {
                      finalValue = formatterService.toValueNode(
                              mapping.getTargetFieldMappingInformation(), interimValue);
                  } catch (ParseException e) {
                      log.error("Parsing Exception {}", e);
                  }


              }

      return finalValue;
  }

    /**
     * Get final Value Node For Target Field
     * @param mapping
     * @param orderMap
     * @return
     */
  private ValueNode getfinalValue(FieldMappingInformation mapping, Map<String, String> orderMap){
      ValueNode finalValue =
              null;
      if (orderMap.size()==mapping.getTargetFieldMappingInformation().getMaxSequenceNo()) {

          Optional<Object> interimValue = Optional.ofNullable(finalValueResponse(mapping, orderMap));


          try {
              finalValue = formatterService.toValueNode(
                      mapping.getTargetFieldMappingInformation(), interimValue);
          } catch (ParseException e) {
              log.error("Parsing Exception {}", e);
          }

      }
      return finalValue;
  }

}
