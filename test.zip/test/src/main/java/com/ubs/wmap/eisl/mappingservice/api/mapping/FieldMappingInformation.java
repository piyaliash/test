package com.ubs.wmap.eisl.mappingservice.api.mapping;

import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldMappingInformation {
  private TargetFieldMappingInformation targetFieldMappingInformation;

  @Default
  private Optional<SourceFieldMappingInformation> sourceFieldMappingInformation = Optional.empty();

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class TargetFieldMappingInformation {
    private String name;
    private FieldTypeInfo typeInfo;
    @Default private Optional<String> format = Optional.empty();
    @Default private OptionalInt size = OptionalInt.empty();
    @Default private Optional<String> defaultValue = Optional.empty();
    @Default private Optional<PaddingDirection> paddingDirection = Optional.empty();
    private List<EnumDetails> enumDetails;
    private List<BooleanValues> booleanDetails;
    private Boolean isAdded;
    private Integer orderNo;
    private Integer maxSequenceNo;
    private String sourceDateFormatter;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class SourceFieldMappingInformation {
    private String name;
    private FieldTypeInfo typeInfo;
    private Integer size;
    private Optional<String> format;
    private Integer sequenceNo;
    private Integer orderNo;
  }
}
