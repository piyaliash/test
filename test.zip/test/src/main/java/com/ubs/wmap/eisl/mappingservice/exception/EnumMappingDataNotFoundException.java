package com.ubs.wmap.eisl.mappingservice.exception;

public class EnumMappingDataNotFoundException extends Exception{

    public EnumMappingDataNotFoundException(String message) {
        super(message);
    }
}
