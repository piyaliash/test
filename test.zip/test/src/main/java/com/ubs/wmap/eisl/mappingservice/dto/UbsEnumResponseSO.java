package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("squid:S1068")
@Data
public class UbsEnumResponseSO implements Serializable {

    private static final long serialVersionUID = -3456577759910496157L;

    private Long ubsEnumId;

    private String description;

    private String audit;

    private String enumName;

    private ArrayList<UbsEnumDetailsResponseSO> ubsEnumDetailsResponseSOList;
}
