package com.ubs.wmap.eisl.mappingservice.service.impl;

import com.ubs.wmap.eisl.mappingservice.api.mapping.*;
import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.excel.MappingKey;
import com.ubs.wmap.eisl.mappingservice.model.*;
import io.micrometer.core.instrument.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@SuppressWarnings("squid:S1481")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class MappingMetaDataTransformer {

    /**
     *Create mapping Details based on  Source and Target Attribute to Target Hierarchial structure
     * @param mappingDataList
     * @param attributes
     * @param enumMappingDetailsList
     * @param inputMappingKey
     * @param orderListMap
     * @return
     */
    public MappingInformation transformFlatMappingDataToHierarchicalData(
            List<MappingDetails> mappingDataList,
            Map<String, AttributeResponseSO> attributes,
            List<EnumMappingDetails> enumMappingDetailsList,
            MappingKey inputMappingKey,
            Map<Integer, List<MappingDetails>> orderListMap
    ) {
        Map<MappingKey, MappingInformation> mappingInformationMap = new HashMap<>();
        MappingKey mappingKey = null;
        for (MappingDetails mappingData : mappingDataList) {
            mappingKey = constructMappingKey(mappingData, inputMappingKey);
            if (!mappingInformationMap.containsKey(mappingKey)) {
                MappingInformation mappingInformation = new MappingInformation();
                mappingInformation.setEntity(mappingKey.getEntity());
                mappingInformation.setSourceSystem(mappingKey.getSourceSystem());
                mappingInformation.setTargetSystem(mappingData.getFormatId().toString());
                List<FieldMappingInformation> fieldMappingInformations = new ArrayList<>();
                fieldMappingInformations.add(
                        constructFieldMappingInformation(mappingData, attributes, enumMappingDetailsList, orderListMap,inputMappingKey));
                mappingInformation.setFieldMappingInformation(fieldMappingInformations);
                mappingInformationMap.put(constructMappingKey(mappingData, inputMappingKey), mappingInformation);
            } else {
                MappingInformation mappingInformation = mappingInformationMap.get(mappingKey);
                mappingInformation
                        .getFieldMappingInformation()
                        .add(
                                constructFieldMappingInformation(mappingData, attributes, enumMappingDetailsList, orderListMap,inputMappingKey));
                mappingInformationMap.put(constructMappingKey(mappingData, inputMappingKey), mappingInformation);
            }
        }
        log.debug("map:{}", mappingInformationMap);
        return mappingInformationMap.get(mappingKey);
    }

    /**
     * Construct Mapping Key based on source and target destination
     * @param mappingData
     * @param inputMappingKey
     * @return
     */
    private MappingKey constructMappingKey(MappingDetails mappingData, MappingKey inputMappingKey) {
        return new MappingKey(
                inputMappingKey.getEntity(), inputMappingKey.getSourceSystem(), mappingData.getFormatId().toString());
    }

    /**
     * Construct Source and Target Field Field Mapping Details
     * @param mappingData
     * @param attributes
     * @param enumMappingDetailsList
     * @param orderListMap
     * @param mappingKey
     * @return
     */
    private FieldMappingInformation constructFieldMappingInformation(
            MappingDetails mappingData,
            Map<String, AttributeResponseSO> attributes,
            List<EnumMappingDetails> enumMappingDetailsList,
            Map<Integer, List<MappingDetails>> orderListMap,
            MappingKey mappingKey) {

        FieldMappingInformation fieldMappingInformation = new FieldMappingInformation();
        fieldMappingInformation.setTargetFieldMappingInformation(
                constructTargetFieldMappingInformation(mappingData, attributes, enumMappingDetailsList, orderListMap,mappingKey));

        fieldMappingInformation.setSourceFieldMappingInformation(
                Optional.ofNullable(
                        constructSourceFieldMappingInformation(mappingData, attributes,mappingKey)));
        return fieldMappingInformation;
    }

    /**
     * Construct Source Attribute Key based on source and target destination
     * @param mappingDetails
     * @param mappingKey
     * @return
     */
    private String constructTargetAttributeKey(MappingDetails mappingDetails, MappingKey mappingKey){
        String attibuteKey=null;
        if(mappingKey.getTargetSystem().equalsIgnoreCase(StaticDataAttributes.SOURCE_ATTRIBUTE.getName())){

            attibuteKey=mappingDetails.getOntologyAttributeId()+ "-"+ StaticDataAttributes.ONTOLOGY_ATTRIBUTE_NAME.getName();
        }else{
            attibuteKey=mappingDetails.getUbsAttributeId() +"-"+StaticDataAttributes.UBS_ATTRIBUTE_NAME.getName();
        }
        return attibuteKey;
    }


    /**
     * Construct Target Attribute Key based on source and target destination
     * @param mappingDetails
     * @param mappingKey
     * @return
     */
    private String constructSourceAttributeKey(MappingDetails mappingDetails, MappingKey mappingKey){
        String attibuteKey=null;
        if(mappingKey.getSourceSystem().equalsIgnoreCase(StaticDataAttributes.SOURCE_ATTRIBUTE.getName())){
            attibuteKey=mappingDetails.getOntologyAttributeId() +"-"+StaticDataAttributes.ONTOLOGY_ATTRIBUTE_NAME.getName();
        }else{
            attibuteKey=mappingDetails.getUbsAttributeId() +"-"+StaticDataAttributes.UBS_ATTRIBUTE_NAME.getName();
        }
        return attibuteKey;
    }

    /**
     * Construct Target Field Mapping Information
     * @param mappingData
     * @param attributes
     * @param enumMappingDetailsList
     * @param orderListMap
     * @param mappingKey
     * @return
     */
    private FieldMappingInformation.TargetFieldMappingInformation
    constructTargetFieldMappingInformation(
            MappingDetails mappingData,
            Map<String, AttributeResponseSO> attributes, List<EnumMappingDetails> enumMappingDetailsList, Map<Integer, List<MappingDetails>> orderListMap,MappingKey mappingKey) {

        AttributeResponseSO targetAttribute = attributes.get(constructTargetAttributeKey(mappingData,mappingKey));

        AttributeResponseSO ontologyAttribute = attributes.get(constructSourceAttributeKey(mappingData,mappingKey));
        if (targetAttribute != null) {
            FieldMappingInformation.TargetFieldMappingInformation targetFieldMappingInformation =
                    new FieldMappingInformation.TargetFieldMappingInformation();
            targetFieldMappingInformation.setName(targetAttribute.getAttributeName());
            if (targetAttribute.getDataType().equalsIgnoreCase(StaticDataAttributes.ATTRIBUTE_TYPE_BOOLEAN.getName())) {
                targetFieldMappingInformation.setBooleanDetails(constructTargetFieldMappingInformationForBooleanValues(targetAttribute,ontologyAttribute));
            } else {
                targetFieldMappingInformation.setDefaultValue(
                        Optional.ofNullable(targetAttribute.getDefaultValue()));
            }

            if (orderListMap.get(mappingData.getOrderNumber())!=null) {
                targetFieldMappingInformation.setOrderNo(mappingData.getOrderNumber());
            }
            targetFieldMappingInformation.setMaxSequenceNo(getMaxSequenceNumberForTargetFieldMappingInformation(orderListMap,mappingData));
            targetFieldMappingInformation.setSize(OptionalInt.of(targetAttribute.getTargetSize()));

            targetFieldMappingInformation.setFormat(Optional.ofNullable(mappingData.getMappingFormat() != null ? mappingData.getMappingFormat().getFormatValue() : null));
            targetFieldMappingInformation.setSourceDateFormatter(ontologyAttribute!=null && ontologyAttribute.getDefaultValue() != null ? ontologyAttribute.getDefaultValue():"");

            targetFieldMappingInformation.setTypeInfo(constructTargetFieldTypeInfo(targetAttribute, mappingData));
            if (targetAttribute.getDataType().equalsIgnoreCase(StaticDataAttributes.ATTRIBUTE_TYPE_ENUM.getName()) && ontologyAttribute!=null) {
                targetFieldMappingInformation.setEnumDetails(constructTargetFieldMappingInformationForEnumDetails(targetAttribute,ontologyAttribute,enumMappingDetailsList));
            }


            return targetFieldMappingInformation;
        }
        return null;
    }


    /**
     * Construct Source Field Mapping Information
     * @param mappingData
     * @param attributes
     * @param mappingKey
     * @return
     */
    private FieldMappingInformation.SourceFieldMappingInformation
    constructSourceFieldMappingInformation(
            MappingDetails mappingData,
            Map<String, AttributeResponseSO> attributes,MappingKey mappingKey) {

        AttributeResponseSO attributeResponseSO = attributes.get(constructSourceAttributeKey(mappingData,mappingKey));
        if (attributeResponseSO != null) {
            FieldMappingInformation.SourceFieldMappingInformation sourceFieldMappingInformation =
                    new FieldMappingInformation.SourceFieldMappingInformation();
            sourceFieldMappingInformation.setName(mappingKey.getEntity()+"." + attributeResponseSO.getAttributeName());
            sourceFieldMappingInformation.setSize(attributeResponseSO.getTargetSize());
            sourceFieldMappingInformation.setTypeInfo(constructSourceFieldTypeInfo(attributeResponseSO));
          sourceFieldMappingInformation.setFormat(
                    Optional.ofNullable(attributeResponseSO.getDefaultValue()));

            sourceFieldMappingInformation.setOrderNo(mappingData.getOrderNumber());
            sourceFieldMappingInformation.setSequenceNo(mappingData.getSequence());

            return sourceFieldMappingInformation;
        }
        return null;
    }

    /**
     * Return source field formatter based on source field data type
     * @param ontologyAttribute
     * @return
     */
    private FieldTypeInfo constructSourceFieldTypeInfo(AttributeResponseSO ontologyAttribute) {
        return getFieldTypeInfo(ontologyAttribute.getDataType(), ontologyAttribute.getDefaultValue());
    }

    /**
     * Return target field formatter based on target field data type
     * @param targetAttribute
     * @param mappingData
     * @return
     */
    private FieldTypeInfo constructTargetFieldTypeInfo(AttributeResponseSO targetAttribute, MappingDetails mappingData) {
        return getFieldTypeInfo(targetAttribute.getDataType(), mappingData.getMappingFormat() != null ? mappingData.getMappingFormat().getFormatValue() : null);
    }

    /**
     * Return Field Data type
     * @param value
     * @param name
     * @return
     */
    private FieldTypeInfo getFieldTypeInfo(String value, String name) {
        FieldTypeInfo fieldTypeInfo = FieldTypeInfo.builder().build();
        if (StringUtils.isBlank(value)) return null;
        switch (value) {
            case "String":
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.STRING);
                break;
            case "DateTime":
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.DATETIME);
                if (name != null) {
                    fieldTypeInfo.setTypeName(Optional.of(name));
                }
                break;
            case "Object":
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.OBJECT);
                break;
            case "Number":
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.NUMBER);
                break;
            case "Boolean":
                fieldTypeInfo.setTypeName(Optional.of(value));
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.BOOLEAN);
                break;
            default:
                fieldTypeInfo.setTypeName(Optional.of(value));
                fieldTypeInfo.setType(FieldTypeInfo.FieldType.ENUM);
                break;
        }

        return fieldTypeInfo;
    }

    /**
     * Return Target Field Mapping information for Boolean data Type
     * @param targetAttribute
     * @param ontologyAttribute
     * @return
     */
    private List<BooleanValues>
    constructTargetFieldMappingInformationForBooleanValues(
            AttributeResponseSO targetAttribute,AttributeResponseSO ontologyAttribute) {
        String[] targetBooleanDetails = targetAttribute.getDefaultValue().split("/");
        String[] sourceBooleanDetails = ontologyAttribute.getDefaultValue().split("/");
        List<BooleanValues> booleanValuesList = new ArrayList<>();
        int index = 0;
        for (String targetBoolean : targetBooleanDetails) {
            BooleanValues booleanValues = new BooleanValues();
            booleanValues.setSourceBooleanValue(sourceBooleanDetails[index]);
            booleanValues.setTargetBooleanValue(targetBooleanDetails[index]);
            booleanValuesList.add(booleanValues);
            index++;

        }
        return booleanValuesList;

    }

    /**
     * Return Target Field Mapping information for Enum type
     * @param targetAttribute
     * @param ontologyAttribute
     * @param enumMappingDetailsList
     * @return
     */
    private List<EnumDetails> constructTargetFieldMappingInformationForEnumDetails(AttributeResponseSO targetAttribute,AttributeResponseSO ontologyAttribute,List<EnumMappingDetails> enumMappingDetailsList){
        List<EnumDetailsResponseSO> ubsEnumDetailsResponseSO = targetAttribute.getEnumResponseSO().getEnumDetailsResponseSOS();
        Map<Long, String> targetEnumListDetails = new HashMap<>();
        for (EnumDetailsResponseSO ubsEnumDetailsResponseSO1 : ubsEnumDetailsResponseSO) {
            targetEnumListDetails.put(ubsEnumDetailsResponseSO1.getEnumDetailsId(), ubsEnumDetailsResponseSO1.getEnumKeyValue());
        }

        List<EnumDetailsResponseSO> ontologyEnumDetailsResponseSO = ontologyAttribute.getEnumResponseSO().getEnumDetailsResponseSOS();
        Map<Long, String> ontologyEnumListDetails = new HashMap<>();
        for (EnumDetailsResponseSO ontologyEnumDetailsResponseSO1 : ontologyEnumDetailsResponseSO) {
            ontologyEnumListDetails.put(ontologyEnumDetailsResponseSO1.getEnumDetailsId(), ontologyEnumDetailsResponseSO1.getEnumKeyValue());
        }
        List<EnumDetails> enumDetailsList=new ArrayList<>();
        for (EnumMappingDetails enumMappingDetails : enumMappingDetailsList) {

            EnumDetails enumDetails = new EnumDetails();
            enumDetails.setSourceEnumValue(ontologyEnumListDetails.get(enumMappingDetails.getEnumOntologyId()));
            enumDetails.setTargetEnumValue(targetEnumListDetails.get(enumMappingDetails.getEnumUbsId()));
            enumDetailsList.add(enumDetails);
        }
        return enumDetailsList;
    }

    /**
     * Return maximum sequence number for many to one attribute transformation
     * @param orderListMap
     * @param mappingData
     * @return
     */
    private Integer getMaxSequenceNumberForTargetFieldMappingInformation(Map<Integer, List<MappingDetails>> orderListMap, MappingDetails mappingData) {
        List<MappingDetails> orderDetailsList= orderListMap.get(mappingData.getOrderNumber());
        int maxSequenceNo = 0;
        if(orderDetailsList!=null && !orderDetailsList.isEmpty()) {
            maxSequenceNo=orderDetailsList.size();
        }
        return maxSequenceNo;
    }

}
