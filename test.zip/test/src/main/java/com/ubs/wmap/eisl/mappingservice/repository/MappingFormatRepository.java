package com.ubs.wmap.eisl.mappingservice.repository;


import com.ubs.wmap.eisl.mappingservice.model.MappingFormat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MappingFormatRepository extends JpaRepository<MappingFormat, String> {

    List<MappingFormat> findAllByFormatTypeAndFormatValue(@Param("formatType") String formatType, @Param("formatValue") String formatValue);

    MappingFormat findByMappingFormatReferenceId(Long formatReferenceId);
}
