package com.ubs.wmap.eisl.mappingservice.util;


import com.ubs.wmap.eisl.mappingservice.exception.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Component
@Slf4j
public class EislUtil {


    private final MessageResourceUtil messageResourceUtil;


    public void checkException(RestClientException e, String domainName) throws DataNotFoundException, BadRequestException, EislTokendException, ForbiddenException, ServiceUnavailableException {
        if (e instanceof HttpStatusCodeException) {
            HttpStatusCodeException ex = (HttpStatusCodeException) e;
            if (HttpStatus.NOT_FOUND == ex.getStatusCode()) {
                log.error("No Data Found from {} Access Service: {} ", domainName, e);
                throw new DataNotFoundException(messageResourceUtil.getMessage("app.message.DATA_NOT_FOUND_MESSAGE", new Object[]{domainName}));
            } else if (HttpStatus.BAD_REQUEST == ex.getStatusCode()) {
                log.error("{} Access Service Url is not Correct : {} ", domainName, e);
                throw new BadRequestException(messageResourceUtil.getMessage("app.message.MALFORMED_URL", new Object[]{domainName}));
            } else if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                log.error("EISL Token Exception during {} access service: {} ", domainName, ex);
                throw new EislTokendException(messageResourceUtil.getMessage("app.message.EISL_INVALID", new Object[]{domainName}));
            } else if (HttpStatus.FORBIDDEN == ex.getStatusCode()) {
                log.error("{} access service Is Forbidden: {} ", domainName, ex);
                throw new ForbiddenException(messageResourceUtil.getMessage("app.message.EISL_FORBIDDEN", new Object[]{domainName}));
            } else if (HttpStatus.SERVICE_UNAVAILABLE == ex.getStatusCode()) {
                log.error("{} access service Not Available: {} ", domainName, ex);
                throw new ServiceUnavailableException(messageResourceUtil.getMessage("app.message.EISL_UNAVAILABLE", new Object[]{domainName}));
            }
        }
    }


}
