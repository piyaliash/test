package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnumResponseSO implements Serializable {

    private static final long serialVersionUID = -4604917493222983968L;

    private Long enumId;

    private String description;

    private String audit;

    private String enumName;

    private ArrayList<EnumDetailsResponseSO> enumDetailsResponseSOS;
}
