package com.ubs.wmap.eisl.mappingservice.excel;


import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@NoArgsConstructor
public class FormatDefination {

    private String formatType;
    private String formatString;
}
