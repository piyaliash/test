package com.ubs.wmap.eisl.mappingservice.excel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class EnumMappingDefinitionReader {

    private static final List<Integer> HEADER_ROWS = Arrays.asList(0);

    private static final int ENTITY_CELL_INDEX = 0;
    private static final int SOURCE_FORMAT_CELL_INDEX = 1;
    private static final int SOURCE_TYPE_CELL_INDEX = 2;
    private static final int SOURCE_VALUE_CELL_INDEX = 3;
    private static final int TARGET_FORMAT_CELL_INDEX = 4;
    private static final int TARGET_TYPE_CELL_INDEX = 5;
    private static final int TARGET_VALUE_CELL_INDEX = 6;

    public List<EnumMappingDefinition> readEnumMappingDefinitions(XSSFSheet sheet) {
        List<EnumMappingDefinition> enumMappingDefinitions = new ArrayList<>();

        for (Row row : sheet) {
            if (!HEADER_ROWS.contains(row.getRowNum())) {
                enumMappingDefinitions.add(mapCellsToEnumMappingDefinition(row));
            }
        }
        return enumMappingDefinitions;
    }

    private EnumMappingDefinition mapCellsToEnumMappingDefinition(Row row) {
        EnumMappingDefinition enumMappingDefinition = new EnumMappingDefinition();
        enumMappingDefinition.setEntity(getStringValue(row.getCell(ENTITY_CELL_INDEX)));
        enumMappingDefinition.setSourceFormat(getStringValue(row.getCell(SOURCE_FORMAT_CELL_INDEX)));
        enumMappingDefinition.setSourceType(getStringValue(row.getCell(SOURCE_TYPE_CELL_INDEX)));
        enumMappingDefinition.setSourceValue(getStringValue(row.getCell(SOURCE_VALUE_CELL_INDEX)));
        enumMappingDefinition.setTargetFormat(getStringValue(row.getCell(TARGET_FORMAT_CELL_INDEX)));
        enumMappingDefinition.setTargetType(getStringValue(row.getCell(TARGET_TYPE_CELL_INDEX)));
        enumMappingDefinition.setTargetValue(getStringValue(row.getCell(TARGET_VALUE_CELL_INDEX)));
        return enumMappingDefinition;
    }

    private String getStringValue(Cell cell) {
        return CellType.STRING.equals(cell.getCellTypeEnum()) ? cell.getStringCellValue() : null;
    }
}
