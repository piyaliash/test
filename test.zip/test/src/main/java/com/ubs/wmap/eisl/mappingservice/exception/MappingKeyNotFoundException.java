package com.ubs.wmap.eisl.mappingservice.exception;

public class MappingKeyNotFoundException extends Exception{

    public MappingKeyNotFoundException(String message) {
        super(message);
    }
}
