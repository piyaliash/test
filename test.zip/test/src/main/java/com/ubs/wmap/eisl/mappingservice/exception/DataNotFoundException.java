package com.ubs.wmap.eisl.mappingservice.exception;

public class DataNotFoundException extends Exception {

    public DataNotFoundException(String message) {
        super(message);
    }

}
