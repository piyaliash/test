package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Set;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormatResponseSO implements Serializable {

    private Long formatId;

    private String formatName;

    private String description;

    private Set<CopybookFileDetailsResponseVO> copybookFileDetailsResponseVO;

}
