package com.ubs.wmap.eisl.mappingservice.excel;

import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@NoArgsConstructor
public class MappingDefinition {

  private String entity;
  private String sourceSystem;
  private String sourceField;
  private String sourceType;
  private String sourceFieldFormat;
  private String targetSystem;
  private String targetField;
  private String targetType;
  private Integer size;
  private String defaultValue;
  private String targetFieldFormat;
  private String paddingDirection;
  private Integer orderNo;
  private Integer sequenceNo;
  private FormatDefination formatDefination;
}
