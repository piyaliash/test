package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class EnumMappingResponseSO implements Serializable {

    private Long enumMappingId;

    private Long enumUbsId;

    private String enumUbsValue;

    private Long enumOntologyId;

    private String enumOntologyValue;

    private Long formatId;

}
