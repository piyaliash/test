package com.ubs.wmap.eisl.mappingservice.exception;

public class InvalidEislTokenException extends Exception{


	public InvalidEislTokenException(String message) {
		super(message);
	}

}
