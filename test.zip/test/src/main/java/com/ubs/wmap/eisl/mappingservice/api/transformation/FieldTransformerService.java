package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo;
import java.math.BigDecimal;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class FieldTransformerService {

  /**
   * Return the source value based on source and target datatype. If source and target datatype is same then return the same source value
   * else transform the source value to target value based on target dataType
   * @param sourceTypeInfo
   * @param targetTypeInfo
   * @param sourceValue
   * @return
   */
  public Object convertType(
      FieldTypeInfo sourceTypeInfo, FieldTypeInfo targetTypeInfo, Object sourceValue) {
    if(sourceTypeInfo==null || targetTypeInfo==null){
      return null;
    }
    if (sourceTypeInfo.equals(targetTypeInfo)) {
      return sourceValue;
    }
    switch (targetTypeInfo.getType()) {
      case NUMBER:
        return new BigDecimal(sourceValue.toString());
      case STRING:
        return sourceValue.toString();
      default:
        return sourceValue;
    }
  }
}
