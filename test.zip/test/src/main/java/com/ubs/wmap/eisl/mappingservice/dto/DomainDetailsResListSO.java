package com.ubs.wmap.eisl.mappingservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DomainDetailsResListSO implements Serializable {

    private static final long serialVersionUID = -4604917493222983968L;
    @JsonProperty("result")
    private List<DomainDetailsResponseVO> domainDetailsResponseVOList;

}
