package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformationService;
import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.Map;


@Slf4j
@RestController
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TransformationController {

    private final TokenService tokenService;

    private final MessageSource messages;

    private final MappingInformationService mappingInformationService;

    private final TransformationEngine transformationEngine;


    /**
     * Execute a transformation.
     *
     * @param token   valid eisl token
     * @param request a transformation request
     * @return response transformation result
     */
    @ApiOperation("Executes a transfomration based on the Mapping file that was previously uploaded")
    @PostMapping("/transform")
    public ResponseEntity<TransformationResponse> transform(
            @NotNull @Valid @RequestBody TransformationRequest request,
            @NotBlank @RequestParam("token") String token) throws BadRequestException, UbsAttributeNotFoundException, MappingServiceException, ForbiddenException, MappingDataNotFoundException, OntologyAttributeNotFoundException, EislTokendException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException {

        log.trace("transform(request: {}, token: {})", request, token);

        servicePreconditions(token);

        MappingInformation mappingInfo =
                mappingInformationService.findMappingInformation(
                        request.getEntityName(),
                        request.getSourceFormatName(),
                        request.getDestinationFormatName(),token);

        JsonNode result = transformationEngine.transform(mappingInfo, request.getSource());

        return ResponseEntity.ok(TransformationResponse.builder().result(result).build());
    }

    /**
     * Upload the excel mapping file.
     *
     * @param file  an excel file to upload
     * @param token a valid EISL token
     * @return OK if it worked
     */
    @ApiOperation("Loads Excel spreadsheet into database")
    @PostMapping("/uploadmapping")
    public ResponseEntity uploadExcelFile(
            @NotNull @RequestParam("file") MultipartFile file,
            @NotBlank @RequestParam("token") String token) throws IOException, ForbiddenException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, EnumMappingDataFoundException, OntologyAttributeNotFoundException, EislTokendException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException {
        log.trace("uploadExcelFile(file: {}, token: {})", file, token);

         servicePreconditions(token);

        mappingInformationService.uploadMappings(file,token);

        return ResponseEntity.ok().build();
    }

    public Map<String, Object> servicePreconditions(String eislToken) throws EislTokendException, MappingServiceException {
        Map<String, Object> eislClaims;

        try {
            eislClaims = tokenService.init(eislToken);

        } catch (TokenExpireException | TokenUnwrapException ex) {
            log.error(messages.getMessage(MessageKeys.EISL_INVALID_TOKEN_MSG.getValue(),null, LocaleContextHolder.getLocale()), ex);
            throw new EislTokendException(messages.getMessage(MessageKeys.EISL_INVALID_TOKEN_MSG.getValue(),null, LocaleContextHolder.getLocale()));

        } catch (RuntimeException rx) {
            String errorMessage =
                    messages.getMessage(
                            MessageKeys.INTERNAL_SERVER_ERROR.getValue(), null, LocaleContextHolder.getLocale());
            log.error(errorMessage, rx);
            throw new MappingServiceException(errorMessage);
        }

        if (!eislClaims.containsKey(StaticDataAttributes.EISL_CLAIMS.getName())) {
            log.error(messages.getMessage(MessageKeys.EISL_INVALID_TOKEN_MSG.getValue(),null, LocaleContextHolder.getLocale()));
            throw new EislTokendException(messages.getMessage(MessageKeys.EISL_INVALID_TOKEN_MSG.getValue(),null, LocaleContextHolder.getLocale()));
        }

        return eislClaims;
    }
}
