package com.ubs.wmap.eisl.mappingservice;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MappingService {

  public static void main(String[] args) {
    SpringApplication.run(MappingService.class, args);
  }
}
