package com.ubs.wmap.eisl.mappingservice.api.mapping;

import com.ubs.wmap.eisl.mappingservice.excel.ExcelFlatMappingDataReader;
import com.ubs.wmap.eisl.mappingservice.excel.FlatMappingData;

import com.ubs.wmap.eisl.mappingservice.excel.MappingKey;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.service.MappingMetaDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


@RequiredArgsConstructor
@Service
@Slf4j
public class MappingInformationService {

    private final ExcelFlatMappingDataReader excelFlatMappingDataReader;
    private final MappingMetaDataService mappingMetaDataService;

    /**
     * Get all Mapping Information details related to attribute mappings, format details and enum mapping details from Mapping database
     * @param entityName
     * @param sourceFormatName
     * @param destinationFormatName
     * @param token
     * @return
     * @throws BadRequestException
     * @throws MappingFormatDataNotFoundException
     * @throws MappingDataFoundException
     * @throws ForbiddenException
     * @throws MappingServiceException
     * @throws ServiceUnavailableException
     * @throws DataNotFoundException
     * @throws EislTokendException
     * @throws OntologyAttributeNotFoundException
     * @throws UbsAttributeNotFoundException
     * @throws MappingDataNotFoundException
     */
    public MappingInformation findMappingInformation(
            String entityName, String sourceFormatName, String destinationFormatName, String token) throws BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException {
        MappingKey mappingKey = new MappingKey(entityName, sourceFormatName, destinationFormatName);
        log.debug("mappingKey:{}", mappingKey);
        MappingInformation mappingInformation = mappingMetaDataService.getMappingDetails(mappingKey,token);
        log.debug("mappingInformation:{}", mappingInformation);
        return mappingInformation;
    }

    /**
     * Upload mapping information to Mapping database reading the mapping details from an excel file
     * @param multipartFile
     * @param token
     * @throws IOException
     * @throws EnumMappingDataFoundException
     * @throws BadRequestException
     * @throws EnumMappingDataNotFoundException
     * @throws UbsAttributeNotFoundException
     * @throws MappingServiceException
     * @throws MappingFormatDataNotFoundException
     * @throws OntologyAttributeNotFoundException
     * @throws MappingDataFoundException
     * @throws ForbiddenException
     * @throws DataNotFoundException
     * @throws EislTokendException
     * @throws ServiceUnavailableException
     */

    public void uploadMappings(MultipartFile multipartFile, String token) throws IOException, EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {

        FlatMappingData flatMappingData =
                excelFlatMappingDataReader.readFlatMappingData(multipartFile.getInputStream());

        mappingMetaDataService.saveFlatMappingData(flatMappingData,token);
        log.debug("flatMappingData;{}", flatMappingData);

    }
}
