package com.ubs.wmap.eisl.mappingservice.excel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnumMappingDefinition {

    private String entity;
    private String sourceFormat;
    private String sourceType;
    private String sourceValue;
    private String targetFormat;
    private String targetType;
    private String targetValue;
}
