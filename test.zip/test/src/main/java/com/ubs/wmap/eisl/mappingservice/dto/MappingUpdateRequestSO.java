package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("squid:S1068")
@Data
public class MappingUpdateRequestSO implements Serializable {

    private static final long serialVersionUID = -2405172041950251807L;

    private Long formatId;
    private List<MappingCreateRequestSO> mappingCreateRequestSOS;

}
