package com.ubs.wmap.eisl.mappingservice.repository;


import com.ubs.wmap.eisl.mappingservice.model.MappingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MappingRepository extends JpaRepository<MappingDetails, Long> {

    List<MappingDetails> findAllByFormatId(@Param("formatId") Long formatId);

    List<MappingDetails> findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(@Param("formatId") Long formatId, @Param("ontologyAttributeId") Long ontologyAttributeId, @Param("ubsAttributeId") Long ubsAttributeId);

    List<MappingDetails> findByFormatIdAndOrderNumber(@Param("formatId") Long formatId, @Param("orderNumber") Integer orderNumber);
}