package com.ubs.wmap.eisl.mappingservice.excel;

public class FlatMappingDataReaderException extends RuntimeException {

  public FlatMappingDataReaderException(String message, Throwable cause) {
    super(message, cause);
  }

  public FlatMappingDataReaderException(Throwable cause) {
    super(cause);
  }
}
