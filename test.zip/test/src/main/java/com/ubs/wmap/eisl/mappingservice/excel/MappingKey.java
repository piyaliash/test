package com.ubs.wmap.eisl.mappingservice.excel;

import lombok.Data;

@SuppressWarnings("squid:S1068")
@Data
public class MappingKey {

  private final String entity;
  private final String sourceSystem;
  private final String targetSystem;
}
