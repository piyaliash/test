package com.ubs.wmap.eisl.mappingservice.dto;

import java.io.Serializable;
import lombok.Data;

@SuppressWarnings("squid:S1068")
@Data
public class MappingMetaDataVO implements Serializable {

    private String domain;

    private String subDomain;
}
