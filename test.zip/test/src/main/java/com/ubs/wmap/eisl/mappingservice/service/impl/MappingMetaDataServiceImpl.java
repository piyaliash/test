package com.ubs.wmap.eisl.mappingservice.service.impl;

import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.excel.EnumMappingDefinition;
import com.ubs.wmap.eisl.mappingservice.excel.FlatMappingData;
import com.ubs.wmap.eisl.mappingservice.excel.MappingDefinition;
import com.ubs.wmap.eisl.mappingservice.excel.MappingKey;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.model.EnumMappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingFormat;
import com.ubs.wmap.eisl.mappingservice.repository.*;
import com.ubs.wmap.eisl.mappingservice.service.MappingMetaDataService;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import java.util.*;
import java.util.function.Predicate;

@SuppressWarnings({"squid:S00117","squid:S3776"})
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Slf4j
public class MappingMetaDataServiceImpl implements MappingMetaDataService {

    private final MappingRepository mappingRepository;
    private final MappingFormatRepository mappingFormatRepository;
    private final EnumMappingRepository enumMappingRepository;
    private final MappingMetaDataTransformer mappingMetaDataTransformer;

    private final MessageResourceUtil messageResourceUtil;

    private final MappingStaticServiceRest mappingStaticServiceRest;


    @Value("${eisl.staticDomainDetailsEndPointUri}")
    private String staticDomainDetailsEndPointUri;

    @Value("${eisl.staticFormatDetailsEndPointUri}")
    private String staticFormatDetailsEndPointUri;

    @Value("${eisl.staticOntologyAttributeEndPointUri}")
    private String staticOntologyAttributeEndPointUri;

    @Value("${eisl.staticUbsAttributeEndPointUri}")
    private String staticUbsAttributeEndPointUri;

    @Value("${eisl.staticOntologyEnumEndPointUri}")
    private String staticOntologyEnumEndPointUri;

    @Value("${eisl.staticUbsEnumEndPointUri}")
    private String staticUbsEnumEndPointUri;

    /**
     * Save Mapping Information to database
     *
     * @param flatMappingData
     * @param token
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws DataNotFoundException
     * @throws ServiceUnavailableException
     * @throws MappingServiceException
     * @throws EislTokendException
     * @throws MappingFormatDataNotFoundException
     * @throws OntologyAttributeNotFoundException
     * @throws UbsAttributeNotFoundException
     * @throws EnumMappingDataNotFoundException
     * @throws EnumMappingDataFoundException
     * @throws MappingDataFoundException
     */
    @Override
    public void saveFlatMappingData(FlatMappingData flatMappingData, String token) throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException, EnumMappingDataFoundException, MappingDataFoundException {
        List<MappingDefinition> mappingDefinitions = flatMappingData.getMappingDefinitions();

        List<EnumMappingDefinition> enumMappingDefinitions = flatMappingData.getEnumMappingDefinitions();

        MappingDefinition mappingDefinition = mappingDefinitions.get(0);
        MappingMetaDataVO mappingMetaDataVO = new MappingMetaDataVO();
        mappingMetaDataVO.setDomain(mappingDefinition.getEntity());

        Map<String, DomainDetailsResponseVO> domainAttributtes = getDomainDetails(mappingMetaDataVO.getDomain(), token);
        log.info("domainAttributtes::{}", domainAttributtes.toString());

        Map<String, FormatResponseSO> formatAttributes = getFormatDetails(mappingMetaDataVO.getDomain(), mappingMetaDataVO.getSubDomain(), token);
        log.info("formatAttributes::{}", formatAttributes.toString());

        Map<String, AttributeResponseSO> ontologyAttributes = getOntologyAttributes(mappingMetaDataVO.getDomain(), mappingMetaDataVO.getSubDomain(), token);
        log.info("ontologyAttributes::{}", ontologyAttributes.toString());

        Map<String, AttributeResponseSO> ubsAttributes = getUbsAttributes(mappingMetaDataVO.getDomain(), mappingMetaDataVO.getSubDomain(), token);
        log.info("ubsAttributes", ubsAttributes.toString());

        for (MappingDefinition mappingDefinition1 : mappingDefinitions) {
            MappingDetails mappingData = new MappingDetails();

            List<MappingFormat> mappingFormatMap = setMappingFormatMap(mappingDefinition1);
            if (mappingFormatMap != null && !mappingFormatMap.isEmpty()) {
                mappingData.setMappingFormat(mappingFormatMap.get(0));
            } else {
                mappingData.setMappingFormat(null);
            }


            Long formatId = formatAttributes.get(mappingDefinition1.getTargetSystem()).getFormatId();
            mappingData.setFormatId(formatId);

            if(mappingDefinition1.getTargetSystem().equalsIgnoreCase(formatAttributes.get(mappingDefinition1.getTargetSystem()).getFormatName())){
                mappingData.setMappingId(formatId);
            }

            mappingData.setOrderNumber(mappingDefinition1.getOrderNo());

            mappingData.setSequence(mappingDefinition1.getSequenceNo());

            Map<String,Long> getAttributeId= getTargetAndOntologyAttribute( mappingDefinition1, ontologyAttributes,ubsAttributes,enumMappingDefinitions, formatId,formatAttributes);

            mappingData.setOntologyAttributeId(getAttributeId.get(StaticDataAttributes.ONTOLOGY_ATTRIBUTE_ID.getName()));
            mappingData.setUbsAttributeId(getAttributeId.get(StaticDataAttributes.TARGET_ATTRIBUTE_ID.getName()));

            if (mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(mappingData.getFormatId(), mappingData.getOntologyAttributeId(), mappingData.getUbsAttributeId()).isEmpty()) {
                mappingRepository.saveAndFlush(mappingData);
                log.debug("mappingData::{}", mappingData);
            } else {
                throw new MappingDataFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_DATA_FOUND_MSG.getValue(), new Long[]{mappingData.getFormatId(),mappingData.getOntologyAttributeId(),mappingData.getUbsAttributeId()}));
            }


        }

    }

    /**
     * Save Enum details to database if source is Ontology and target destination is CopyBook
     * @param mappingDefinition1
     * @param ontologyAttributes
     * @param ubsAttributes
     * @param enumMappingDefinitions
     * @param formatId
     * @param formatAttributes
     * @throws EnumMappingDataNotFoundException
     * @throws EnumMappingDataFoundException
     */

    private void saveOntologyToTargetEnumDetails(MappingDefinition mappingDefinition1, Map<String, AttributeResponseSO> ontologyAttributes,Map<String, AttributeResponseSO> ubsAttributes,List<EnumMappingDefinition> enumMappingDefinitions,Long formatId,Map<String, FormatResponseSO> formatAttributes) throws EnumMappingDataNotFoundException, EnumMappingDataFoundException {

        Map<String, EnumDetailsResponseSO> ontologyEnumDetailsResponseSOMap = new HashMap<>();
        Map<String, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap = new HashMap<>();

        boolean isOntologyEnumPresent = false;
        boolean isUbsEnumPresent = false;

        if (!StringUtils.isEmpty(mappingDefinition1.getSourceField()) && ontologyAttributes.get(mappingDefinition1.getSourceField()).getDataType().equalsIgnoreCase("Enum")) {
            ontologyEnumDetailsResponseSOMap = setOntologyEnumResponseMap(mappingDefinition1,ontologyAttributes,mappingDefinition1.getSourceSystem());
            isOntologyEnumPresent = true;
        }

        if (!StringUtils.isEmpty(mappingDefinition1.getTargetField()) && ubsAttributes.get(mappingDefinition1.getTargetField()).getDataType().equalsIgnoreCase("Enum")) {
            ubsEnumDetailsResponseSOMap=setUbsEnumResponseMap(mappingDefinition1,ubsAttributes,mappingDefinition1.getSourceSystem());
            isUbsEnumPresent = true;
        }

        if (isOntologyEnumPresent && isUbsEnumPresent) {

            saveEnumResponse(mappingDefinition1,ontologyEnumDetailsResponseSOMap,ubsEnumDetailsResponseSOMap,formatId,enumMappingDefinitions,formatAttributes);
        }
    }

    /**
     * Save Enum details to database if source is CopyBook and target destination is Ontology
     * @param mappingDefinition1
     * @param ontologyAttributes
     * @param ubsAttributes
     * @param enumMappingDefinitions
     * @param formatId
     * @param formatAttributes
     * @throws EnumMappingDataNotFoundException
     * @throws EnumMappingDataFoundException
     */

    private void saveTargetToOntologyEnumMappingDetails(MappingDefinition mappingDefinition1, Map<String, AttributeResponseSO> ontologyAttributes,Map<String, AttributeResponseSO> ubsAttributes,List<EnumMappingDefinition> enumMappingDefinitions,Long formatId,Map<String, FormatResponseSO> formatAttributes) throws EnumMappingDataNotFoundException, EnumMappingDataFoundException {

        Map<String, EnumDetailsResponseSO> ontologyEnumDetailsResponseSOMap = new HashMap<>();
        Map<String, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap = new HashMap<>();

        boolean isOntologyEnumPresent = false;
        boolean isUbsEnumPresent = false;

        if (!StringUtils.isEmpty(mappingDefinition1.getTargetField()) && ontologyAttributes.get(mappingDefinition1.getTargetField()).getDataType().equalsIgnoreCase("Enum")) {

            ontologyEnumDetailsResponseSOMap = setOntologyEnumResponseMap(mappingDefinition1,ontologyAttributes,mappingDefinition1.getSourceSystem());
            isOntologyEnumPresent = true;
        }
        if (!StringUtils.isEmpty(mappingDefinition1.getSourceField()) && ubsAttributes.get(mappingDefinition1.getSourceField()).getDataType().equalsIgnoreCase("Enum")) {

            ubsEnumDetailsResponseSOMap=setUbsEnumResponseMap(mappingDefinition1,ubsAttributes,mappingDefinition1.getSourceSystem());
            isUbsEnumPresent = true;
        }

        if (isOntologyEnumPresent && isUbsEnumPresent) {

            saveEnumResponse(mappingDefinition1,ontologyEnumDetailsResponseSOMap,ubsEnumDetailsResponseSOMap,formatId,enumMappingDefinitions,formatAttributes);
        }
    }

    /**
     * Save all enum details to database
     * @param mappingDefinition1
     * @param ontologyAttributes
     * @param ubsAttributes
     * @param enumMappingDefinitions
     * @param formatId
     * @param formatAttributes
     * @return
     * @throws EnumMappingDataNotFoundException
     * @throws EnumMappingDataFoundException
     */
    private Map<String,Long> getTargetAndOntologyAttribute(MappingDefinition mappingDefinition1, Map<String, AttributeResponseSO> ontologyAttributes,Map<String, AttributeResponseSO> ubsAttributes,List<EnumMappingDefinition> enumMappingDefinitions,Long formatId,Map<String, FormatResponseSO> formatAttributes) throws EnumMappingDataNotFoundException, EnumMappingDataFoundException {

        Map<String,Long> getAttributeId = new HashMap<>();

        if (mappingDefinition1.getSourceSystem().equals(StaticDataAttributes.SOURCE_ATTRIBUTE.getName())) {

            getAttributeId.put(StaticDataAttributes.ONTOLOGY_ATTRIBUTE_ID.getName(),mappingDefinition1.getSourceField() != null ? ontologyAttributes.get(mappingDefinition1.getSourceField()).getAttributeId() : null);
            getAttributeId.put(StaticDataAttributes.TARGET_ATTRIBUTE_ID.getName(),mappingDefinition1.getTargetField() != null ? ubsAttributes.get(mappingDefinition1.getTargetField()).getAttributeId() : null);
            saveOntologyToTargetEnumDetails(mappingDefinition1,ontologyAttributes,ubsAttributes,enumMappingDefinitions,formatId,formatAttributes);

        } else {

            getAttributeId.put(StaticDataAttributes.ONTOLOGY_ATTRIBUTE_ID.getName(),mappingDefinition1.getTargetField() != null ? ontologyAttributes.get(mappingDefinition1.getTargetField()).getAttributeId() : null);
            getAttributeId.put(StaticDataAttributes.TARGET_ATTRIBUTE_ID.getName(),mappingDefinition1.getSourceField() != null ? ubsAttributes.get(mappingDefinition1.getSourceField()).getAttributeId() : null);
            saveTargetToOntologyEnumMappingDetails(mappingDefinition1,ontologyAttributes,ubsAttributes,enumMappingDefinitions,formatId,formatAttributes);

        }
        return getAttributeId;
    }

    /**
     * Save all enum details to database
     * @param mappingDefinition1
     * @param ontologyEnumDetailsResponseSOMap
     * @param ubsEnumDetailsResponseSOMap
     * @param formatId
     * @param enumMappingDefinitions
     * @param formatAttributes
     * @throws EnumMappingDataFoundException
     */
    private void saveEnumResponse(MappingDefinition mappingDefinition1, Map<String, EnumDetailsResponseSO> ontologyEnumDetailsResponseSOMap, Map<String, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap, Long formatId, List<EnumMappingDefinition> enumMappingDefinitions, Map<String, FormatResponseSO> formatAttributes) throws EnumMappingDataFoundException {
        for (EnumMappingDefinition enumMappingDefinition1 : enumMappingDefinitions) {

            if (enumMappingDefinition1.getTargetFormat().equalsIgnoreCase(formatAttributes.get(mappingDefinition1.getTargetSystem()).getFormatName()) && enumMappingDefinition1.getEntity().equalsIgnoreCase(mappingDefinition1.getSourceField())) {

                Long ontologyEnumId = ontologyEnumDetailsResponseSOMap.get(enumMappingDefinition1.getSourceValue()) != null ? ontologyEnumDetailsResponseSOMap.get(enumMappingDefinition1.getSourceValue()).getEnumDetailsId() : null;
                Long ubsEnumId = ubsEnumDetailsResponseSOMap.get(enumMappingDefinition1.getTargetValue()) != null ? ubsEnumDetailsResponseSOMap.get(enumMappingDefinition1.getTargetValue()).getEnumDetailsId() : null;
                saveEnumDetails(ontologyEnumId, ubsEnumId, formatId);


            }

        }
    }

    /**
     * create Ontology EnumRsponse Map
     * @param mappingDefinition1
     * @param ontologyAttributes
     * @param sourceSystem
     * @return
     * @throws EnumMappingDataNotFoundException
     */
    private Map<String, EnumDetailsResponseSO> setOntologyEnumResponseMap(MappingDefinition mappingDefinition1, Map<String, AttributeResponseSO> ontologyAttributes, String sourceSystem) throws EnumMappingDataNotFoundException {
        Map<String, EnumDetailsResponseSO> ontologyEnumDetailsResponseSOMap = new HashMap<>();
        List<EnumDetailsResponseSO> ontologyEnumDetailsList;
        if (sourceSystem.equalsIgnoreCase(StaticDataAttributes.SOURCE_ATTRIBUTE.getName())) {
            ontologyEnumDetailsList = mappingDefinition1.getSourceField() != null ? ontologyAttributes.get(mappingDefinition1.getSourceField()).getEnumResponseSO().getEnumDetailsResponseSOS() : null;
        }else {
            ontologyEnumDetailsList = mappingDefinition1.getTargetField() != null ? ontologyAttributes.get(mappingDefinition1.getTargetField()).getEnumResponseSO().getEnumDetailsResponseSOS() : null;
        }

        if (CollectionUtils.isEmpty(ontologyEnumDetailsList))
            throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_MSG.getValue()));
        for (EnumDetailsResponseSO ontologyEnumDetails : ontologyEnumDetailsList) {
            ontologyEnumDetailsResponseSOMap.put(ontologyEnumDetails.getEnumKeyValue(), ontologyEnumDetails);
        }

        return ontologyEnumDetailsResponseSOMap;
    }

    /**
     * create Ubs EnumRsponse Map
     * @param mappingDefinition1
     * @param ubsAttributes
     * @param sourceSystem
     * @return
     * @throws EnumMappingDataNotFoundException
     */
    private Map<String, EnumDetailsResponseSO> setUbsEnumResponseMap(MappingDefinition mappingDefinition1, Map<String, AttributeResponseSO> ubsAttributes, String sourceSystem) throws EnumMappingDataNotFoundException {
        Map<String, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap = new HashMap<>();
        List<EnumDetailsResponseSO> ubsEnumDetailsList;
        if (sourceSystem.equalsIgnoreCase(StaticDataAttributes.SOURCE_ATTRIBUTE.getName())) {
            ubsEnumDetailsList = mappingDefinition1.getSourceField() != null ? ubsAttributes.get(mappingDefinition1.getTargetField()).getEnumResponseSO().getEnumDetailsResponseSOS() : null;
        }else {
            ubsEnumDetailsList =  mappingDefinition1.getTargetField() != null ? ubsAttributes.get(mappingDefinition1.getSourceField()).getEnumResponseSO().getEnumDetailsResponseSOS() : null;
        }

        if (CollectionUtils.isEmpty(ubsEnumDetailsList))
            throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_MSG.getValue()));
        for (EnumDetailsResponseSO ubsEnumDetails : ubsEnumDetailsList) {
            ubsEnumDetailsResponseSOMap.put(ubsEnumDetails.getEnumKeyValue(), ubsEnumDetails);
        }

        return ubsEnumDetailsResponseSOMap;
    }

    /**
     * create Mapping Format details
     * @param mappingDefinition1
     * @return
     */
    private  List<MappingFormat>  setMappingFormatMap(MappingDefinition mappingDefinition1 ){
        List<MappingFormat> mappingFormatMap = !StringUtils.isEmpty(mappingDefinition1.getFormatDefination().getFormatType()) && !StringUtils.isEmpty(mappingDefinition1.getFormatDefination().getFormatString()) ?
                mappingFormatRepository.findAllByFormatTypeAndFormatValue(mappingDefinition1.getFormatDefination().getFormatType(), mappingDefinition1.getFormatDefination().getFormatString()) : null;

        if (mappingFormatMap != null && mappingFormatMap.isEmpty()) {
            MappingFormat mappingFormat = new MappingFormat();
            mappingFormat.setFormatType(mappingDefinition1.getFormatDefination().getFormatType());
            mappingFormat.setFormatValue(mappingDefinition1.getFormatDefination().getFormatString());
            mappingFormatRepository.saveAndFlush(mappingFormat);
            log.debug("mappingFormat::{}", mappingFormat);
            mappingFormatMap = mappingFormatRepository.findAllByFormatTypeAndFormatValue(mappingDefinition1.getFormatDefination().getFormatType(), mappingDefinition1.getFormatDefination().getFormatString());
            log.debug("mappingFormatMap::{}", mappingFormatMap);
        }

        return mappingFormatMap;


    }

    /**
     * save enum details to database
     * @param ontologyEnumId
     * @param ubsEnumId
     * @param formatId
     * @throws EnumMappingDataFoundException
     */
    private void saveEnumDetails(Long ontologyEnumId, Long ubsEnumId, Long formatId) throws EnumMappingDataFoundException {
        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        if (ontologyEnumId != null && ubsEnumId != null) {
            if (enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ubsEnumId, ontologyEnumId, formatId).isEmpty()) {
                enumMappingDetails.setEnumOntologyId(ontologyEnumId);
                enumMappingDetails.setEnumUbsId(ubsEnumId);
                enumMappingDetails.setFormatId(formatId);
                enumMappingRepository.saveAndFlush(enumMappingDetails);
            } else {
                throw new EnumMappingDataFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_FOUND_MSG.getValue(), new Long[]{formatId,ontologyEnumId,ubsEnumId}));
            }
        }
    }

    /**
     * Get all mapping details for transforming source to target
     *
     * @param mappingKey
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws MappingFormatDataNotFoundException
     * @throws OntologyAttributeNotFoundException
     * @throws UbsAttributeNotFoundException
     * @throws MappingDataNotFoundException
     */
    @Override
    public MappingInformation getMappingDetails(MappingKey mappingKey, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException {

        Map<Long, FormatResponseSO> formatAttributes = getFormatDetailsById(mappingKey.getEntity(), "", token);
        log.info("formatAttributes::{}", formatAttributes.toString());

        Map<String, FormatResponseSO> formatName = getFormatDetails(mappingKey.getEntity(), "", token);
        log.info("formatName::{}", formatName);

        Map<String, AttributeResponseSO> allAttributes = getAllAttributes(mappingKey.getEntity(), "", token);
        log.info("allAttributes::{}", allAttributes.toString());

        Long formatId = formatName.get(mappingKey.getTargetSystem()).getFormatId();

        List<MappingDetails> mappingDataList = mappingRepository.findAllByFormatId(formatId);
        log.debug("mappingDataList::{}", mappingDataList);
        if (CollectionUtils.isEmpty(mappingDataList)) {
            throw new MappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FORMAT_MSG.getValue()));
        }
        List<Integer> orderList = new ArrayList<>();
        Set<Integer> orderListAccumulator = new HashSet<>();
        for (MappingDetails mappingDetails : mappingDataList) {
            orderList.add(mappingDetails.getOrderNumber());
        }

        for (Integer number : orderList) {
            if (Collections.frequency(orderList, number) > 1)
                orderListAccumulator.add(number);
        }
        List<MappingDetails> orderMappingDataList = new ArrayList<>();
        HashMap<Integer, List<MappingDetails>> orderListMap = new HashMap<>();

        if (!orderListAccumulator.isEmpty()) {
            for (Integer orderLst : orderListAccumulator) {
                orderMappingDataList = mappingRepository.findByFormatIdAndOrderNumber(formatId, orderLst);
                orderListMap.put(orderLst, orderMappingDataList);
            }
            log.debug("orderMappingDataList::{}", orderMappingDataList);
        }


        List<EnumMappingDetails> enumMappingDetailsList = enumMappingRepository.findByFormatId(formatId);

        if (!CollectionUtils.isEmpty(mappingDataList)) {
            return mappingMetaDataTransformer.transformFlatMappingDataToHierarchicalData(mappingDataList,
                    allAttributes,
                    enumMappingDetailsList, mappingKey, orderListMap);
        }

        return null;
    }

    /**
     * Get all mapping details
     * @param mappingRequestSO
     * @param token
     * @return
     * @throws MappingDataNotFoundException
     * @throws MappingKeyNotFoundException
     * @throws MappingDataFoundException
     * @throws MappingFormatDataNotFoundException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws OntologyAttributeNotFoundException
     * @throws UbsAttributeNotFoundException
     */
    @Override
    public List<MappingResponseSO> getMappings(MappingRequestSO mappingRequestSO, String token) throws MappingDataNotFoundException, MappingKeyNotFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException {
        log.debug("getMappings:: formatName ::{}", mappingRequestSO.getFormatName());
        Boolean filePresent=false;
        Map<String, FormatResponseSO> formatResponseSOMap = getFormatDetails(mappingRequestSO.getDomain(), "", token);
        log.info("formatResponseSOMap:: {}", formatResponseSOMap);
        validateKey(mappingRequestSO, formatResponseSOMap);
        List<MappingDetails> mappingDetailsList = mappingRepository.findAllByFormatId(formatResponseSOMap.get(mappingRequestSO.getFormatName()).getFormatId());
        if(!StringUtils.isEmpty(mappingRequestSO.getFileName())){
            Set<CopybookFileDetailsResponseVO> copyBookFileList= formatResponseSOMap.get(mappingRequestSO.getFormatName()).getCopybookFileDetailsResponseVO();
            copyBookFileList.forEach(filename->mappingRequestSO.getFileName().equalsIgnoreCase(filename.getFileName()));
            filePresent = copyBookFileList.stream()
                    .anyMatch(filename -> mappingRequestSO.getFileName().equalsIgnoreCase(filename.getFileName()));
        }
        log.info("mappingDetailsList:: {}", mappingDetailsList);
        if (CollectionUtils.isEmpty(mappingDetailsList)) {
            throw new MappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FORMAT_MSG.getValue(), new Long[]{formatResponseSOMap.get(mappingRequestSO.getFormatName()).getFormatId()}));
        }
        if(!filePresent && !formatResponseSOMap.get(mappingRequestSO.getFormatName()).getCopybookFileDetailsResponseVO().isEmpty()){
            throw new MappingFormatDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FOR_FILE_MSG.getValue(), new Object[]{mappingRequestSO.getFileName()}));
        }
        List<MappingResponseSO> mappingResponseSOS = new ArrayList<>();
        Map<Long, AttributeResponseSO> ontologyAttributeDetailsByIds= getOntologyAttributeDetailsByIds(mappingRequestSO.getDomain(), "", token);
        Map<Long, AttributeResponseSO> ubsAttributeDetailsByIds=getUbsAttributeDetailsById(mappingRequestSO.getDomain(), "", token);

        for(MappingDetails mappingdetails : mappingDetailsList){
            mappingResponseSOS.add(constructMappingResponseSO(mappingdetails,ontologyAttributeDetailsByIds , ubsAttributeDetailsByIds,token));
        }

        log.debug("mappingResponseSOS:: {}", mappingResponseSOS);
        return mappingResponseSOS;
    }

    /** Validate mapping key
     * Details
     * @param mappingRequestSO
     * @param formatResponseSOMap
     * @throws MappingKeyNotFoundException
     */
    private void validateKey(MappingRequestSO mappingRequestSO, Map<String, FormatResponseSO> formatResponseSOMap) throws MappingKeyNotFoundException {
        if (!formatResponseSOMap.containsKey(mappingRequestSO.getFormatName()))
            throw new MappingKeyNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_KEY_NOT_FOUND_MSG.getValue(), new Object[]{mappingRequestSO.getFormatName()}));

    }

    /**
     * construct mapping details response
     * @param mappingDetails
     * @param ontologyAttributes
     * @param ubsAttributes
     * @return
     */
    private MappingResponseSO constructMappingResponseSO(MappingDetails mappingDetails, Map<Long, AttributeResponseSO> ontologyAttributes, Map<Long, AttributeResponseSO> ubsAttributes, String token) throws BadRequestException, ForbiddenException, DataNotFoundException, EnumMappingDataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException{
       MappingResponseSO mappingResponseSO = new MappingResponseSO();
        BeanUtils.copyProperties(mappingDetails, mappingResponseSO);
        mappingResponseSO.setMappingFormatResponseSO(getFormatDetailsResponse(mappingDetails.getMappingFormat()));
        if (mappingDetails.getOntologyAttributeId() != null) {
            mappingResponseSO.setOntologyAtrributeName(ontologyAttributes.get(mappingDetails.getOntologyAttributeId()).getAttributeName());
        }

        if (mappingDetails.getUbsAttributeId() != null) {
            mappingResponseSO.setUbsAtrributeName(ubsAttributes.get(mappingDetails.getUbsAttributeId()).getAttributeName());
        }

       if( mappingDetails.getOntologyAttributeId()!= null && mappingDetails.getUbsAttributeId()!=null && ontologyAttributes.get(mappingDetails.getOntologyAttributeId()).getEnumResponseSO()!=null && ubsAttributes.get(mappingDetails.getUbsAttributeId()).getEnumResponseSO()!=null) {

           List<EnumMappingDetails> enumMappingDetailsList = enumMappingRepository.findByFormatId(mappingDetails.getFormatId());
           if (CollectionUtils.isEmpty(enumMappingDetailsList)) {
               throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_MSG.getValue(), new Object[]{mappingDetails.getFormatId()}));
           }

           List<EnumDetailsResponseSO> ontologyEnumAttributes= ontologyAttributes.get(mappingDetails.getOntologyAttributeId()).getEnumResponseSO().getEnumDetailsResponseSOS();
           List<EnumDetailsResponseSO> ubsEnumAttributes= ubsAttributes.get(mappingDetails.getUbsAttributeId()).getEnumResponseSO().getEnumDetailsResponseSOS();

           List<EnumMappingResponseSO> enumMappingResponseSOS = new ArrayList<>();
           StringBuilder ontologyEnumIds = new StringBuilder();
           StringBuilder ubsEnumIds = new StringBuilder();

           for (EnumMappingDetails enumMappingDetails : enumMappingDetailsList) {
               if (enumMappingDetails.getEnumOntologyId() != null && enumMappingDetails.getEnumUbsId() != null) {

                   Predicate<EnumDetailsResponseSO> ontologyEnumDetails = e -> e.getEnumDetailsId().equals(enumMappingDetails.getEnumOntologyId());
                   long noOfOntologyEnumIdPresent= ontologyEnumAttributes.stream().filter(ontologyEnumDetails).count();


                   if (noOfOntologyEnumIdPresent > 0) {
                       ontologyEnumIds.append(enumMappingDetails.getEnumOntologyId());
                       ontologyEnumIds.append(",");
                   }

                   Predicate<EnumDetailsResponseSO> ubsEnumDetails = e -> e.getEnumDetailsId().equals(enumMappingDetails.getEnumUbsId());
                   long noOfUbsEnumIdPresent= ubsEnumAttributes.stream().filter(ubsEnumDetails).count();

                   if (noOfUbsEnumIdPresent > 0){
                       ubsEnumIds.append(enumMappingDetails.getEnumUbsId());
                       ubsEnumIds.append(",");
                   }

               }else{
                   throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_MSG.getValue(), new Object[]{mappingDetails.getFormatId()}));
               }
               enumMappingResponseSOS.add(constructEnumMappingResponseSO(enumMappingDetails, getOntologyEnumDetailsByIds(ontologyEnumIds.toString(), token), getUbsEnumDetailsByIds(ubsEnumIds.toString(), token)));
           }
           mappingResponseSO.setEnumMappingResponseSOS(enumMappingResponseSOS);
       }

        return mappingResponseSO;
    }

    /**
     * construct enum mapping response
     * @param enumMappingDetails
     * @param enumDetailsResponseSOMap
     * @param ubsEnumDetailsResponseSOMap
     * @return
     */
    private EnumMappingResponseSO constructEnumMappingResponseSO(EnumMappingDetails enumMappingDetails, Map<Long, EnumDetailsResponseSO> enumDetailsResponseSOMap, Map<Long, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap) {
        EnumMappingResponseSO enumMappingResponseSO = new EnumMappingResponseSO();
        BeanUtils.copyProperties(enumMappingDetails, enumMappingResponseSO);
        enumMappingResponseSO.setEnumOntologyValue(enumDetailsResponseSOMap.get(enumMappingDetails.getEnumOntologyId()).getEnumKeyValue());
        enumMappingResponseSO.setEnumUbsValue(ubsEnumDetailsResponseSOMap.get(enumMappingDetails.getEnumUbsId()).getEnumKeyValue());
        return enumMappingResponseSO;
    }

    /**
     * get all ampping format details
     * @return
     * @throws MappingFormatDataNotFoundException
     */
    @Override
    public List<MappingFormatResponseSO> getAllMappingFormats() throws MappingFormatDataNotFoundException {
        List<MappingFormat> mappingFormatList = mappingFormatRepository.findAll();
        if (CollectionUtils.isEmpty(mappingFormatList)) {
            throw new MappingFormatDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_FORMAT_NOT_FOUND_MSG.getValue()));
        }
        List<MappingFormatResponseSO> mappingFormatResponseSOS = new ArrayList<>();
        for (MappingFormat mappingFormat : mappingFormatList) {
            mappingFormatResponseSOS.add(getFormatDetailsResponse(mappingFormat));
        }
        log.debug("mappingFormatResponseSOS:: {}", mappingFormatResponseSOS);
        return mappingFormatResponseSOS;
    }

    /**
     * Save mapping details
     * @param mappingUpdateRequestSO
     * @return
     */
    @Override
    public List<MappingResponseSO> saveMappings(MappingUpdateRequestSO mappingUpdateRequestSO) {
        log.debug("saveMappings::mappingUpdateRequestSO:{}", mappingUpdateRequestSO);
        List<MappingDetails> mappingDetails = constructMappingDetailsEntityFromSOList(mappingUpdateRequestSO);
        List<MappingDetails> mappingDetailsList = mappingRepository.saveAll(mappingDetails);
        log.debug("mappingDetailsList::{}", mappingDetailsList);
        List<MappingResponseSO> mappingResponseSOList = new ArrayList<>();

        for (MappingDetails mappingDetails1 : mappingDetailsList) {
            Optional<MappingDetails> getMappingDetails = mappingRepository.findById(mappingDetails1.getMappingId());
            if (getMappingDetails.isPresent())
                mappingResponseSOList.add(getMappingResponse(getMappingDetails.get()));
        }
        log.debug("mappingResponseSOList::{}", mappingResponseSOList);
        return mappingResponseSOList;
    }

    /**
     * set mapping format response details
     * @param getMappingDetails
     * @return
     */
    private MappingResponseSO getMappingResponse(MappingDetails getMappingDetails) {
        MappingResponseSO mappingResponseSO = new MappingResponseSO();
        BeanUtils.copyProperties(getMappingDetails, mappingResponseSO);
        mappingResponseSO.setMappingFormatResponseSO(getFormatDetailsResponse(getMappingDetails.getMappingFormat()));
        return mappingResponseSO;

    }

    /**
     * get mapping format response details
     * @param mappingFormat
     * @return
     */
    private MappingFormatResponseSO getFormatDetailsResponse(MappingFormat mappingFormat) {
        if (mappingFormat == null)
            return null;
        MappingFormatResponseSO mappingFormatResponseSO = new MappingFormatResponseSO();
        BeanUtils.copyProperties(mappingFormat, mappingFormatResponseSO);
        return mappingFormatResponseSO;
    }

    /**
     * construct Mapping Details Entity FromSO List
     * @param mappingUpdateRequestSO
     * @return
     */
    private List<MappingDetails> constructMappingDetailsEntityFromSOList(MappingUpdateRequestSO mappingUpdateRequestSO) {
        List<MappingDetails> mappingDetails = new ArrayList<>();
        for (MappingCreateRequestSO mappingResponseSO : mappingUpdateRequestSO.getMappingCreateRequestSOS()) {
            MappingDetails mappingDetails1 = constructMappingDetailsEntityFromSO(mappingResponseSO);
            if (mappingDetails1 != null) {
                mappingDetails1.setFormatId(mappingUpdateRequestSO.getFormatId());
                mappingDetails.add(mappingDetails1);
            }

        }

        return mappingDetails;
    }

    /**
     * construct Mapping Details Entity From SO
     * @param mappingResponseSO
     * @return
     */
    private MappingDetails constructMappingDetailsEntityFromSO(MappingCreateRequestSO mappingResponseSO) {
        if (mappingResponseSO == null)
            return null;
        MappingDetails mappingDetails = new MappingDetails();
        BeanUtils.copyProperties(mappingResponseSO, mappingDetails);
        mappingDetails.setMappingFormat(constructMappingFormatDetailsEntityFromSO(mappingResponseSO.getMappingFormatReferenceId()));
        return mappingDetails;
    }

    /**
     * construct Mapping Format Details Entity From SO
     * @param formatReferenceId
     * @return
     */
    private MappingFormat constructMappingFormatDetailsEntityFromSO(Long formatReferenceId) {
        if (formatReferenceId == null)
            return null;
        return mappingFormatRepository.findByMappingFormatReferenceId(formatReferenceId);

    }

    /**
     * Update Mapping details
     * @param mappingUpdateRequestSO
     * @return
     * @throws MappingDataNotFoundException
     */
    @Override
    public List<MappingResponseSO> updateMappings(MappingUpdateRequestSO mappingUpdateRequestSO) throws MappingDataNotFoundException {
        log.debug("updateMappings:mappingUpdateRequestSO:{}", mappingUpdateRequestSO);
        List<MappingDetails> mappingDetailsList = mappingRepository.findAllByFormatId(mappingUpdateRequestSO.getFormatId());
        if (CollectionUtils.isEmpty(mappingDetailsList)) {
            throw new MappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FORMAT_MSG.getValue(), new Object[]{mappingUpdateRequestSO.getFormatId()}));
        }
        mappingRepository.deleteInBatch(mappingDetailsList);
        List<MappingResponseSO> mappingResponseSOS = this.saveMappings(mappingUpdateRequestSO);
        log.debug("updateMappings:mappingResponseSOS:{}", mappingResponseSOS);
        return mappingResponseSOS;
    }

    /**
     *  Delete Mapping Details
     * @param mappingRequestSO
     * @param token
     * @throws MappingDataNotFoundException
     * @throws MappingKeyNotFoundException
     * @throws MappingDataFoundException
     * @throws MappingFormatDataNotFoundException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     */
    @Override
    public void deleteMapping(MappingRequestSO mappingRequestSO, String token) throws MappingDataNotFoundException, MappingKeyNotFoundException, MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException {
        log.debug("deleteMapping::mappingRequestSO:{}", mappingRequestSO.getFormatName());
        Map<String, FormatResponseSO> formatResponseSOMap = getFormatDetails(mappingRequestSO.getDomain(), "", token);

        if (!formatResponseSOMap.containsKey(mappingRequestSO.getFormatName()))
            throw new MappingKeyNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_KEY_NOT_FOUND_MSG.getValue()));
        List<MappingDetails> mappingDetails = mappingRepository.findAllByFormatId(formatResponseSOMap.get(mappingRequestSO.getFormatName()).getFormatId());

        if (CollectionUtils.isEmpty(mappingDetails)) {
            throw new MappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FORMAT_MSG.getValue(), new Object[]{formatResponseSOMap.get(mappingRequestSO.getFormatName()).getFormatId()}));
        }
        mappingRepository.deleteInBatch(mappingDetails);
    }

    /**
     * delete Mapping details By FormatName And Ontology And UbsAttribute Id
     * @param mappingRequestSO
     * @param token
     * @throws MappingKeyNotFoundException
     * @throws MappingDataNotFoundException
     * @throws MappingDataFoundException
     * @throws MappingFormatDataNotFoundException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     */
    @Override
    public void deleteMappingByFormatNameAndOntologyAndUbsAttributeId(MappingRequestSO mappingRequestSO, String token) throws MappingKeyNotFoundException, MappingDataNotFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException {
        log.debug("deleteMapping::formatNmae:{} :: OntologyAttributeId:{} :: UbsAttributeId:{}", mappingRequestSO.getFormatName(), mappingRequestSO.getOntologyAtrributeId(), mappingRequestSO.getUbsAtrributeId());
        Map<String, FormatResponseSO> formatResponseSOMap = getFormatDetails(mappingRequestSO.getDomain(), "", token);

        if (!formatResponseSOMap.containsKey(mappingRequestSO.getFormatName()))
            throw new MappingKeyNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_KEY_NOT_FOUND_MSG.getValue(), new Object[]{mappingRequestSO.getFormatName()}));
        List<MappingDetails> mappingDetails = mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(formatResponseSOMap.get(mappingRequestSO.getFormatName()).getFormatId(), mappingRequestSO.getOntologyAtrributeId(), mappingRequestSO.getUbsAtrributeId());
        log.debug("mappingDetails::{}", mappingDetails);
        if (CollectionUtils.isEmpty(mappingDetails)) {
            throw new MappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_MSG.getValue()));
        }
        mappingRepository.deleteInBatch(mappingDetails);
    }

    /**
     * Get Domain Details
     * @param domainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     */
    @Override
    public Map<String, DomainDetailsResponseVO> getDomainDetails(String domainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException {
        log.debug("getDomainDetails::domainName:{}", domainName);
        Map<String, DomainDetailsResponseVO> domainMap = new HashMap<>();
        try {
            ResponseEntity<DomainDetailsResListSO> getDomainResponse = mappingStaticServiceRest.getDomainDetails(staticDomainDetailsEndPointUri, token, domainName);
            log.info(getDomainResponse.toString());

            if (getDomainResponse.getStatusCode() == HttpStatus.OK && getDomainResponse.getBody() != null && !CollectionUtils.isEmpty(getDomainResponse.getBody().getDomainDetailsResponseVOList())) {

                for (DomainDetailsResponseVO domainDetailsResponseVO : getDomainResponse.getBody().getDomainDetailsResponseVOList()) {
                    domainMap.put(domainDetailsResponseVO.getDomainName(), domainDetailsResponseVO);
                }
                log.debug("domainMap:{}", domainMap);
                return domainMap;
            }

            log.error("Data not found for Domain");
            throw new DataNotFoundException(messageResourceUtil.getMessage(MessageKeys.DOMAIN_NOT_FOUND_MSG.getValue(), new String[]{domainName}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get all format Details
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws MappingFormatDataNotFoundException
     */
    @Override
    public Map<String, FormatResponseSO> getFormatDetails(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, MappingFormatDataNotFoundException {
        log.debug("getFormatDetails::domainName:{}:: subDomainName:{}", domainName, subDomainName);
        Map<String, FormatResponseSO> formatMap = new HashMap<>();
        try {
            ResponseEntity<FormatListResponseSO> getFormatResponse = mappingStaticServiceRest.getFormatDetails(staticFormatDetailsEndPointUri, token, domainName);
            log.info(getFormatResponse.toString());

            if (getFormatResponse.getStatusCode() == HttpStatus.OK && getFormatResponse.getBody() != null && !CollectionUtils.isEmpty(getFormatResponse.getBody().getFormatResponseSOList())) {

                for (FormatResponseSO formatResponseSO : getFormatResponse.getBody().getFormatResponseSOList()) {
                    formatMap.put(formatResponseSO.getFormatName(), formatResponseSO);
                }
                log.debug("formatMap:{}", formatMap);
                return formatMap;
            }

            log.error("Data not found for Format");
            throw new MappingFormatDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_FORMAT_NOT_FOUND_MSG.getValue(), new String[]{domainName}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get Ontology Attribute Details based on domain and Subdomain
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws OntologyAttributeNotFoundException
     */
    @Override
    public Map<String, AttributeResponseSO> getOntologyAttributes(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException {
        Map<String, AttributeResponseSO> ontologyAttributeMap = new HashMap<>();
        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(staticOntologyAttributeEndPointUri, token, domainName);
            log.debug(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null && !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO attributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    ontologyAttributeMap.put(attributeResponseSO.getAttributeName(), attributeResponseSO);
                }
                log.debug("ontologyAttributeMap::{}", ontologyAttributeMap);
                return ontologyAttributeMap;
            }
            log.error("Data not found for Ontology Attribute");
            throw new OntologyAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.ONTOLOGY_NOT_FOUND_MSG.getValue(), new String[]{domainName}));


        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }
    }

    /**
     * Get Ubs Attribute details based on domain and SubDomain
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws UbsAttributeNotFoundException
     * @throws MappingServiceException
     */
    @Override
    public Map<String, AttributeResponseSO> getUbsAttributes(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, UbsAttributeNotFoundException, MappingServiceException {
        Map<String, AttributeResponseSO> UbsAttributeMap = new HashMap<>();
        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(
                    staticUbsAttributeEndPointUri, token, domainName);
            log.debug(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null &&
                    !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO ubsAttributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    UbsAttributeMap.put(ubsAttributeResponseSO.getAttributeName(), ubsAttributeResponseSO);
                }
                log.debug("UbsAttributeMap::{}", UbsAttributeMap);
                return UbsAttributeMap;
            }

            log.error("Data not found for ubs Attribute");
            throw new UbsAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.UBS_ATTRIBUTE_NOT_FOUND_MSG.getValue(), new String[]{domainName}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get format details by formatId
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws MappingFormatDataNotFoundException
     */
    @Override
    public Map<Long, FormatResponseSO> getFormatDetailsById(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, MappingFormatDataNotFoundException {
        log.debug("getFormatDetailsById::domainName:{}:: subDomainName:{}", domainName, subDomainName);
        Map<Long, FormatResponseSO> formatMap = new HashMap<>();
        try {
            ResponseEntity<FormatListResponseSO> getFormatResponse = mappingStaticServiceRest.getFormatDetails(staticFormatDetailsEndPointUri, token, domainName);
            log.info(getFormatResponse.toString());


            if (getFormatResponse.getStatusCode() == HttpStatus.OK && getFormatResponse.getBody() != null && !CollectionUtils.isEmpty(getFormatResponse.getBody().getFormatResponseSOList())) {

                for (FormatResponseSO formatResponseSO : getFormatResponse.getBody().getFormatResponseSOList()) {
                    formatMap.put(formatResponseSO.getFormatId(), formatResponseSO);
                }
                log.debug("formatMap:: {}", formatMap);
                return formatMap;
            }
            log.error("Data not found for Format");
            throw new MappingFormatDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.MAPPING_FORMAT_NOT_FOUND_MSG.getValue(), new String[]{domainName}));


        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get Ontology Enum details by EnumId
     * @param attributeIds
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws EnumMappingDataNotFoundException
     * @throws MappingServiceException
     */
    @Override
    public Map<Long, EnumDetailsResponseSO> getOntologyEnumDetailsByIds(String attributeIds, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, EnumMappingDataNotFoundException, MappingServiceException {

        log.debug("getOntologyEnumDetailsByIds1::attributeIds:{}", attributeIds);
        Map<Long, EnumDetailsResponseSO> enumDetailsResponseSOMap = new HashMap<>();
        try {
            ResponseEntity<EnumDetailsListResponseSO> getOntologyEnumList = mappingStaticServiceRest.getEnumByIds(staticOntologyEnumEndPointUri, token, attributeIds);
            if (getOntologyEnumList.getStatusCode() == HttpStatus.OK && getOntologyEnumList.getBody() != null && !CollectionUtils.isEmpty(getOntologyEnumList.getBody().getEnumDetailsResponseSOS())) {
                for (EnumDetailsResponseSO enumDetailsResponseSO : getOntologyEnumList.getBody().getEnumDetailsResponseSOS()) {
                    enumDetailsResponseSOMap.put(enumDetailsResponseSO.getEnumDetailsId(), enumDetailsResponseSO);

                }
                log.debug("ontologyEnumDetailsResponseSOMap::{}", enumDetailsResponseSOMap);
                return enumDetailsResponseSOMap;
            }
            log.debug(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_IDS_MSG.getValue(), new String[]{attributeIds}));
            throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_IDS_MSG.getValue(), new String[]{attributeIds}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));

        }
    }

    /**
     * Get Target Enum details by EnumId
     * @param attributeIds
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws EnumMappingDataNotFoundException
     */
    @Override
    public Map<Long, EnumDetailsResponseSO> getUbsEnumDetailsByIds(String attributeIds, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, EnumMappingDataNotFoundException {
        log.debug("getUbsEnumDetailsByIds::attributeIds:{}", attributeIds);
        Map<Long, EnumDetailsResponseSO> ubsEnumDetailsResponseSOMap = new HashMap<>();
        try {
            ResponseEntity<EnumDetailsListResponseSO> getUbsEnumList = mappingStaticServiceRest.getEnumByIds(staticUbsEnumEndPointUri, token, attributeIds);
            if (getUbsEnumList.getStatusCode() == HttpStatus.OK && getUbsEnumList.getBody() != null && !CollectionUtils.isEmpty(getUbsEnumList.getBody().getEnumDetailsResponseSOS())) {
                for (EnumDetailsResponseSO ubsEnumDetailsResponseSO : getUbsEnumList.getBody().getEnumDetailsResponseSOS()) {
                    ubsEnumDetailsResponseSOMap.put(ubsEnumDetailsResponseSO.getEnumDetailsId(), ubsEnumDetailsResponseSO);
                }
                log.debug("ubsEnumDetailsResponseSOMap::{}", ubsEnumDetailsResponseSOMap);
                return ubsEnumDetailsResponseSOMap;
            }
            log.debug(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_IDS_MSG.getValue(), new String[]{attributeIds}));
            throw new EnumMappingDataNotFoundException(messageResourceUtil.getMessage(MessageKeys.ENUM_MAPPING_NOT_FOUND_IDS_MSG.getValue(), new String[]{attributeIds}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get Ontology Attribute details by Attribute Id
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws OntologyAttributeNotFoundException
     * @throws MappingServiceException
     */
    public Map<Long, AttributeResponseSO> getOntologyAttributeDetailsByIds(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, OntologyAttributeNotFoundException, MappingServiceException {
        log.debug("getOntologyAttributeDetailsByIds::domainName:{}:: subDomainName:{}", domainName, subDomainName);
        Map<Long, AttributeResponseSO> ontologyAttributeMap = new HashMap<>();
        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(staticOntologyAttributeEndPointUri, token, domainName);
            log.debug(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null && !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO ontologyAttributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    ontologyAttributeMap.put(ontologyAttributeResponseSO.getAttributeId(), ontologyAttributeResponseSO);
                }
                log.debug("ontologyAttributeMap::{}", ontologyAttributeMap);
                return ontologyAttributeMap;

            }
            log.debug(messageResourceUtil.getMessage(MessageKeys.ONTOLOGY_NOT_FOUND_MSG.getValue(), new String[]{domainName}));
            throw new OntologyAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.ONTOLOGY_NOT_FOUND_MSG.getValue(), new String[]{domainName}));
        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

    /**
     * Get Ontology Attribute and Target Attribute details
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws MappingServiceException
     * @throws OntologyAttributeNotFoundException
     * @throws UbsAttributeNotFoundException
     */
    public Map<String, AttributeResponseSO> getAllAttributes(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException {
        log.debug("getAllAttributes::domainName:{}:: subDomainName:{}", domainName, subDomainName);
        Map<String, AttributeResponseSO> attributesMap = new HashMap<>();
        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(staticOntologyAttributeEndPointUri, token, domainName);
            log.debug(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null && !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO ontologyAttributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    attributesMap.put(ontologyAttributeResponseSO.getAttributeId() + "-"+StaticDataAttributes.ONTOLOGY_ATTRIBUTE_NAME.getName(), ontologyAttributeResponseSO);
                }
                log.debug("Ontology attributesMap::{}", attributesMap);
            } else {

                log.debug(messageResourceUtil.getMessage(MessageKeys.ONTOLOGY_NOT_FOUND_MSG.getValue(), new String[]{domainName}));
                throw new OntologyAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.ONTOLOGY_NOT_FOUND_MSG.getValue(), new String[]{domainName}));
            }

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());

        }

        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(staticUbsAttributeEndPointUri, token, domainName);
            log.info(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null && !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO ubsAttributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    attributesMap.put(ubsAttributeResponseSO.getAttributeId() + "-"+StaticDataAttributes.UBS_ATTRIBUTE_NAME.getName(), ubsAttributeResponseSO);
                }
                log.debug("Ubs attributesMap::{}", attributesMap);
                return attributesMap;
            }
            log.error("Data not found for ubs Attribute");
            throw new UbsAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.UBS_ATTRIBUTE_NOT_FOUND_MSG.getValue(), new String[]{domainName}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));

        }
    }

    /**
     * Get Ubs Attribute details by Attribute Id
     * @param domainName
     * @param subDomainName
     * @param token
     * @return
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     * @throws UbsAttributeNotFoundException
     * @throws MappingServiceException
     */
    public Map<Long, AttributeResponseSO> getUbsAttributeDetailsById(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, UbsAttributeNotFoundException, MappingServiceException {
        log.debug("getUbsAttributeDetailsById::domainName:{}:: subDomainName:{}", domainName, subDomainName);
        Map<Long, AttributeResponseSO> UbsAttributeMap = new HashMap<>();
        try {
            ResponseEntity<AttributeListResponseSO> responseEntity = mappingStaticServiceRest.getAttribute(staticUbsAttributeEndPointUri, token, domainName);
            log.info(responseEntity.toString());

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null && !CollectionUtils.isEmpty(responseEntity.getBody().getAttributeResponseSOList())) {

                for (AttributeResponseSO ubsAttributeResponseSO : responseEntity.getBody().getAttributeResponseSOList()) {
                    UbsAttributeMap.put(ubsAttributeResponseSO.getAttributeId(), ubsAttributeResponseSO);
                }
                log.debug("UbsAttributeMap::{}", UbsAttributeMap);
                return UbsAttributeMap;
            }
            log.debug(messageResourceUtil.getMessage(MessageKeys.UBS_ATTRIBUTE_NOT_FOUND_MSG.getValue(), new String[]{domainName}));
            throw new UbsAttributeNotFoundException(messageResourceUtil.getMessage(MessageKeys.UBS_ATTRIBUTE_NOT_FOUND_MSG.getValue(), new String[]{domainName}));

        } catch (MappingServiceException ex) {
            log.error(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()), ex.getMessage());
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }

    }

}
