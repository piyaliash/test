package com.ubs.wmap.eisl.mappingservice.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Entity
@Table(name = "MAPPING_DETAILS" , schema = "mapping")
@EntityListeners(AuditingEntityListener.class)
@DynamicUpdate
public class MappingDetails implements Serializable {

    private static final long serialVersionUID = 3770085916847755446L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mapping_reference_id")
    private Long mappingReferenceId;

    @Column(name = "mapping_id")
    private Long mappingId;

    @Column(name = "order_number")
    private Integer orderNumber;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private String createdDate;

    @Column(name = "modified_by")
    private String modifieddBy;

    @Column(name = "modified_date")
    private String modifiedDate;

    @Column(name = "ubs_attribute_id")
    private Long ubsAttributeId;

    @Column(name = "ontology_attribute_id")
    private Long ontologyAttributeId;

    @Column(name = "format_id")
    private Long formatId;

    @Column(name = "sequence")
    private Integer sequence;


    @EqualsAndHashCode.Exclude
    @ManyToOne
    @JoinColumn(name = "mapping_format_reference_id", referencedColumnName = "format_reference_id")
    private MappingFormat mappingFormat;


}
