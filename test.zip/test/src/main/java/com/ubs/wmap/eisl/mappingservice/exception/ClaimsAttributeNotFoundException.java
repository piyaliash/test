package com.ubs.wmap.eisl.mappingservice.exception;

public class ClaimsAttributeNotFoundException extends Exception {

    public ClaimsAttributeNotFoundException(String message) {
        super(message);
    }
}
