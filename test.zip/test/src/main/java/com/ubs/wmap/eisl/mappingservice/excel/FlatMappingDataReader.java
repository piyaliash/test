package com.ubs.wmap.eisl.mappingservice.excel;

import java.io.InputStream;

/** Reader for getting flat representation of mapping data. */
public interface FlatMappingDataReader {

  /**
   * Reads flat representation of mapping data.
   *
   * @param inputStream input stream holding mapping data
   * @return data read from input stream
   * @throws FlatMappingDataReaderException if reading data fails
   */
  FlatMappingData readFlatMappingData(InputStream inputStream);
}
