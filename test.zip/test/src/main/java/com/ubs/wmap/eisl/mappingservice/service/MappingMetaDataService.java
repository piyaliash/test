package com.ubs.wmap.eisl.mappingservice.service;

import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.excel.FlatMappingData;
import com.ubs.wmap.eisl.mappingservice.excel.MappingKey;
import com.ubs.wmap.eisl.mappingservice.exception.*;

import java.util.List;
import java.util.Map;

public interface MappingMetaDataService {


    Map<String, DomainDetailsResponseVO> getDomainDetails(String domainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException;

    Map<String, FormatResponseSO> getFormatDetails(String domainName, String subDomainName, String token) throws MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException;

    Map<String, AttributeResponseSO> getOntologyAttributes(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException;

    Map<String, AttributeResponseSO> getUbsAttributes(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, UbsAttributeNotFoundException, MappingServiceException;

    void saveFlatMappingData(FlatMappingData flatMappingData, String token)throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException, EnumMappingDataFoundException, MappingDataFoundException;

    MappingInformation getMappingDetails(MappingKey mappingKey, String token) throws MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException;

    /**
     * This API is used for UI
     *
     * @param mappingRequestSO
     * @return List<MappingResponseSO>
     */
    List<MappingResponseSO> getMappings(MappingRequestSO mappingRequestSO, String token) throws MappingDataNotFoundException, MappingKeyNotFoundException, MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException;


    List<MappingFormatResponseSO> getAllMappingFormats() throws MappingFormatDataNotFoundException;

    /**
     * This API is used for UI
     *
     * @param mappingUpdateRequestSO
     * @return List<MappingResponseSO>
     */
    List<MappingResponseSO> saveMappings(MappingUpdateRequestSO mappingUpdateRequestSO);

    /**
     * This API is used for UI
     *
     * @param mappingUpdateRequestSO
     * @return List<MappingResponseSO>
     */
    List<MappingResponseSO> updateMappings(MappingUpdateRequestSO mappingUpdateRequestSO) throws MappingDataNotFoundException, MappingKeyNotFoundException;

    void deleteMapping(MappingRequestSO mappingRequestSO, String token) throws MappingDataNotFoundException, MappingKeyNotFoundException, MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException;

    void deleteMappingByFormatNameAndOntologyAndUbsAttributeId(MappingRequestSO mappingRequestSO, String token) throws MappingKeyNotFoundException, MappingDataNotFoundException, MappingDataFoundException, MappingFormatDataNotFoundException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException;

    Map<Long, AttributeResponseSO> getOntologyAttributeDetailsByIds(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, OntologyAttributeNotFoundException, MappingServiceException;

    Map<Long, AttributeResponseSO> getUbsAttributeDetailsById(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, UbsAttributeNotFoundException, MappingServiceException;

    Map<Long, FormatResponseSO> getFormatDetailsById(String domainName, String subDomainName, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, MappingFormatDataNotFoundException;

    Map<Long, EnumDetailsResponseSO> getOntologyEnumDetailsByIds(String attributeIds, String token) throws MappingServiceException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, EnumMappingDataNotFoundException;

    Map<Long, EnumDetailsResponseSO> getUbsEnumDetailsByIds(String attributeIds, String token) throws DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException, MappingServiceException, EnumMappingDataNotFoundException;
}
