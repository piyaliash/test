package com.ubs.wmap.eisl.mappingservice.repository;


import com.ubs.wmap.eisl.mappingservice.model.EnumMappingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnumMappingRepository  extends JpaRepository<EnumMappingDetails, Long> {

    List<EnumMappingDetails> findByFormatId(@Param("formatId") Long formatId);
    List<EnumMappingDetails> findByEnumUbsIdAndEnumOntologyIdAndFormatId(@Param("enumUbsId") Long enumUbsId, @Param("enumOntologyId") Long enumOntologyId, @Param("formatId") Long formatId);
}
