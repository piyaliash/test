package com.ubs.wmap.eisl.mappingservice.service.impl;


import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.constant.StaticDataAttributes;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.util.EislUtil;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MappingStaticServiceRest {

    private final RestTemplate restTemplate;

    private final EislUtil eislUtil;

    private final MessageResourceUtil messageResourceUtil;

    /**
     * Get Domain Details from Static Service Rest Api
     * @param baseUrl
     * @param eislToken
     * @param domainName
     * @return
     * @throws MappingServiceException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     */
    ResponseEntity<DomainDetailsResListSO> getDomainDetails(String baseUrl, String eislToken, String domainName) throws MappingServiceException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException {

        log.debug(MessageKeys.ENTER_DOMAIN_METHOD.getValue());

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam(StaticDataAttributes.DOMAIN_NAME.getName(), domainName).queryParam(StaticDataAttributes.EISL_TOKEN.getName(), eislToken);
        try {
            return restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<DomainDetailsResListSO>() {
                    });
        } catch (RestClientException e) {
            eislUtil.checkException(e, MessageKeys.STATIC_DATA.getValue());
            log.error("Internal Server occured while accessing Domain Service {}", e);
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }
    }

    /**
     * Get Format Details e:g CopyBook Name from Static Service Rest Api
     * @param baseUrl
     * @param eislToken
     * @param domainName
     * @return
     * @throws MappingServiceException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     */
    ResponseEntity<FormatListResponseSO> getFormatDetails(String baseUrl, String eislToken, String domainName) throws MappingServiceException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException {

        log.debug(MessageKeys.ENTER_FORMAT_METHOD.getValue());

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam(StaticDataAttributes.EISL_TOKEN.getName(), eislToken).queryParam(StaticDataAttributes.DOMAIN_NAME.getName(), domainName);
        try {
            return restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<FormatListResponseSO>() {
                    });
        } catch (RestClientException e) {
            eislUtil.checkException(e, domainName);
            log.error("Internal Server occured while accessing Format Details Service {}", e);
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }
    }

    /**
     * Get Attribute Details from Static Service Rest Api
     * @param baseUrl
     * @param eislToken
     * @param domainName
     * @return
     * @throws MappingServiceException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     */
    ResponseEntity<AttributeListResponseSO> getAttribute(String baseUrl, String eislToken, String domainName) throws MappingServiceException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException {

        log.debug(MessageKeys.ENTER_ATTRIBUTE_LIST_METHOD.getValue());

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam(StaticDataAttributes.EISL_TOKEN.getName(),eislToken).queryParam(StaticDataAttributes.DOMAIN_NAME.getName(),domainName);
        try {
            return restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<AttributeListResponseSO>() {
                    });
        } catch (RestClientException e) {
            eislUtil.checkException(e, MessageKeys.STATIC_DATA.getValue());
            log.error("Internal Server occured while accessing Attribute Details {} ", e);
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }
    }

    /**
     * Get Enum Details using EnumId from Static Service Rest Api
     * @param baseUrl
     * @param eislToken
     * @param attributeIds
     * @return
     * @throws MappingServiceException
     * @throws DataNotFoundException
     * @throws BadRequestException
     * @throws ForbiddenException
     * @throws ServiceUnavailableException
     * @throws EislTokendException
     */
     ResponseEntity<EnumDetailsListResponseSO> getEnumByIds(String baseUrl, String eislToken, String attributeIds) throws MappingServiceException, DataNotFoundException, BadRequestException, ForbiddenException, ServiceUnavailableException, EislTokendException {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam(StaticDataAttributes.EISL_TOKEN.getName(), eislToken).queryParam(StaticDataAttributes.ids.getName(), attributeIds);
        try {
            return restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<EnumDetailsListResponseSO>() {
                    });
        } catch (RestClientException e) {
            eislUtil.checkException(e, MessageKeys.STATIC_DATA.getValue());
            log.error("Internal Server occured while accessing Enum Details {} ", e);
            throw new MappingServiceException(messageResourceUtil.getMessage(MessageKeys.INTERNAL_SERVER_ERROR.getValue()));
        }
    }


}
