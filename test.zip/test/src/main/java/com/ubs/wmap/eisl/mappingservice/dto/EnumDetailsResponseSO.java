package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnumDetailsResponseSO implements Serializable {

    private static final long serialVersionUID = -2406425398189065029L;

    private Long enumDetailsId;

    private String enumKey;

    private String enumKeyValue;
}
