package com.ubs.wmap.eisl.mappingservice.api.mapping;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MappingInformation {
  private String entity;
  private String sourceSystem;
  private String targetSystem;
  private List<FieldMappingInformation> fieldMappingInformation;
}
