package com.ubs.wmap.eisl.mappingservice.model;


import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Entity
@Table(name = "MAPPING")
@EntityListeners(AuditingEntityListener.class)
@DynamicUpdate
public class MappingData implements Serializable {

        private static final long serialVersionUID = 3770085916847755446L;

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "MAPPING_ID")
        private Long mappingId;

        @Column(name = "ENTITY")
        private String entity;

        @Column(name = "SOURCE_FORMAT")
        private String sourceFormat;

        @Column(name = "SOURCE_FIELD")
        private Long sourceField;

        @Column(name = "TARGET_FORMAT")
        private String targetFormat;

        @Column(name = "TARGET_FIELD")
        private Long targetField;

}

