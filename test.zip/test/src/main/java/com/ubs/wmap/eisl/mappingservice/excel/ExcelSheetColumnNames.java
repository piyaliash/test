package com.ubs.wmap.eisl.mappingservice.excel;


public enum ExcelSheetColumnNames {

    ENTITY("Entity"),
    SOURCEFORMAT("SourceFormat"),
    SOURCEFIELD("SourceField"),
    TARGETFORMAT("TargetFormat"),
    TARGETFIELD("TargetField"),
    ORDERNO("OrderNo"),
    SEQUENCENO("SequenceNo"),
    FORMATTYPE("FormType"),
    FORMATSTRING("FormatString");

    private String name;

    ExcelSheetColumnNames(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
