package com.ubs.wmap.eisl.mappingservice.excel;

public class InvalidDataFormatException extends RuntimeException {
  public InvalidDataFormatException(String message) {
    super(message);
  }
}
