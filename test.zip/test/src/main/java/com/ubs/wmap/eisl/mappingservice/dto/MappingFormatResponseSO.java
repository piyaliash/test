package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class MappingFormatResponseSO implements Serializable {

    private Long mappingFormatReferenceId;

    private String formatType;
    private String formatValue;
    private String description;
}
