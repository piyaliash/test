package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CopybookFileDetailsResponseVO implements Serializable{

        private static final long serialVersionUID = -7091933776496679990L;
        private Long copybookFileId;
        private String fileName;
        private String rules;

    }

