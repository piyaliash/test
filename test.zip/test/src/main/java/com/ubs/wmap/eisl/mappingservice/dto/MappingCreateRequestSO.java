package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class MappingCreateRequestSO implements Serializable {
    private static final long serialVersionUID = -2405172041950251807L;

    private Long mappingId;

    private Integer orderNumber;

    private Integer sequence;

    private Long ubsAttributeId;

    private Long ontologyAttributeId;

    private Long mappingFormatReferenceId;
}
