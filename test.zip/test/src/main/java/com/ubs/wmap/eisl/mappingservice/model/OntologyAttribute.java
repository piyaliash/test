package com.ubs.wmap.eisl.mappingservice.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@SuppressWarnings("squid:S1068")
@Data
@Entity
@Table(name = "ONTOLOGY_ATTRIBUTE")
@EntityListeners(AuditingEntityListener.class)
@DynamicUpdate
public class OntologyAttribute implements Serializable {

  private static final long serialVersionUID = 3770085916847755446L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ONTOLOGY_ATTRIBUTE_ID")
  private Long ontologyAttributeId;

  @Column(name = "ATTRIBUTE_NAME")
  private String attributeName;

  @Column(name = "DOMAIN_NAME")
  private String domain;

  @Column(name = "SUBDOMAIN_NAME")
  private String subDomain;

  @Column(name = "DATA_TYPE")
  private String dataType;

  @Column(name = "DATA_FORMAT")
  private String dataFormat;

  @Column(name = "FIELD_LENGTH")
  private Integer fieldLength;

  @Column(name = "DESCRIPTION")
  private String description;
}
