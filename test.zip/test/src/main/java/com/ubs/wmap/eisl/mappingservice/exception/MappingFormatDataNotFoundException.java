package com.ubs.wmap.eisl.mappingservice.exception;

public class MappingFormatDataNotFoundException extends Exception{

    public MappingFormatDataNotFoundException(String message) {
        super(message);
    }

}
