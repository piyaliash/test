package com.ubs.wmap.eisl.mappingservice.dto;

import lombok.Data;

import java.io.Serializable;

@SuppressWarnings("squid:S1068")
@Data
public class OntologyAttributeResponseSO implements Serializable{

    private static final long serialVersionUID = -2405172041950251807L;

    private Long ontologyAttributeId;

    private String attributeName;

    private String dataType;

    private String description;

    private Integer targetSize;

    private String defaultValue;

    private transient OntologyEnumResponseSO ontologyEnumResponseSO;


}
