package com.ubs.wmap.eisl.mappingservice.api.mapping;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("squid:S1068")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BooleanValues {

    String sourceBooleanValue;
    String targetBooleanValue;
}
