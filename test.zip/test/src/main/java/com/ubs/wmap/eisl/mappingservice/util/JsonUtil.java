package com.ubs.wmap.eisl.mappingservice.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ValueNode;

public class JsonUtil {
  private JsonUtil() {
    throw new IllegalStateException("Utility class");
  }

  public static JsonNode getNode(JsonNode sourceRootNode, String fieldPath) {
    String jsonPointer = "/" + fieldPath.replace('.', '/');
    return sourceRootNode.at(jsonPointer);
  }

  // WS-OUT-REC.OUT-PX-CRTE-M.OUT-DATE
  public static ObjectNode setAt(ObjectNode rootNode, String fieldPath, ValueNode finalValue) {
    String[] fields = fieldPath.split("\\."); // [ "WS-OUT", "OUT-PX-CRTE-M", "OUT-DATE" ]
    ObjectNode parentNode = rootNode;
    for (int i = 0; i < fields.length - 1; i++) {
      parentNode = parentNode.with(fields[i]);
    }
    parentNode.set(fields[fields.length - 1], finalValue);
    return rootNode;
  }
}
