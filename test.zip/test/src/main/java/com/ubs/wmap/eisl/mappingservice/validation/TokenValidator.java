package com.ubs.wmap.eisl.mappingservice.validation;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.exception.ClaimsAttributeNotFoundException;
import com.ubs.wmap.eisl.mappingservice.exception.InvalidEislTokenException;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

import java.util.Map;

@SuppressWarnings("squid:S00116")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Slf4j
@Service
@Import(TokenServiceConfiguration.class)
public class TokenValidator {

    private final TokenService tokenService;

    private final MessageResourceUtil messageSourceUtil;

    @Value("${app.custom.eisl_attribute_name}")
    private String EISL_CLAIMS_ATTRIBUTE;

    public void validate(String eislToken) throws ClaimsAttributeNotFoundException, InvalidEislTokenException {
        if (!servicePreconditions(eislToken).containsKey(EISL_CLAIMS_ATTRIBUTE)) {
            throw new ClaimsAttributeNotFoundException(messageSourceUtil.getMessage(MessageKeys.CLAIMS_ATTRIBUTE_NOT_FOUND_MSG.getValue()));
        }
    }

    public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEislTokenException {
        Map<String, Object> eislClaims;
        try {
            eislClaims = tokenService.init(eislToken);
            log.debug("Eisl Claims:{}", eislClaims);
        }catch (TokenExpireException | TokenUnwrapException ex) {
            log.error(messageSourceUtil.getMessage(MessageKeys.TOKEN_EXPIRE_MSG.getValue()), ex);
            throw new InvalidEislTokenException((messageSourceUtil.getMessage(MessageKeys.EISL_INVALID_TOKEN_MSG.getValue())));
        }
        log.debug("servicePreConditions : eislClaims:{}", eislClaims);
        return eislClaims;
    }


}

