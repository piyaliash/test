package com.ubs.wmap.eisl.mappingservice.api.mapping;

public enum PaddingDirection {
    LEFT,
    RIGHT,
    UNKNOWN
}