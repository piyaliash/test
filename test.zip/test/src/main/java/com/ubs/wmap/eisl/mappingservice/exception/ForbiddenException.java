package com.ubs.wmap.eisl.mappingservice.exception;

public class ForbiddenException extends Exception {

    public ForbiddenException(String message) {
        super(message);
    }
}
