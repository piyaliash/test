package com.ubs.wmap.eisl.mappingservice.exception;

public class MappingDataNotFoundException extends Exception{

    public MappingDataNotFoundException(String message) {
        super(message);
    }
}
