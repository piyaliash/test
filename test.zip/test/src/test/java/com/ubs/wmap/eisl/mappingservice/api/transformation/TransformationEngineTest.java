package com.ubs.wmap.eisl.mappingservice.api.transformation;

import static org.mockito.BDDMockito.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.TextNode;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.SourceFieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.TargetFieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo.FieldType;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Collections;
import java.util.Optional;

import org.json.JSONException;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.test.web.client.ExpectedCount;

@RunWith(MockitoJUnitRunner.class)
public class TransformationEngineTest {
  @InjectMocks private TransformationEngine transformationEngine;

  @Mock private FieldTransformerService mockFieldTransformerService;

  @Mock private FormatterService mockFormatterService;

  @Spy private ObjectMapper objectMapper = new ObjectMapper();

  private InputStream instrumentInputStream =
      TransformationEngineTest.class.getResourceAsStream("/instrumentPayload.json");

  private JsonNode sourceRootNode = objectMapper.readValue(instrumentInputStream, JsonNode.class);

  public TransformationEngineTest() throws IOException {
    // needed for initializing sourceRootNode
  }

  @Test
  public void transformSingleNode() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .name("WS-OUT-REC.OUT-PROI")
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .build())
            .sourceFieldMappingInformation(
                Optional.of(
                    SourceFieldMappingInformation.builder()
                        .name("Instrument.productIdentifier")
                        .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                        .build()))
            .build();
    MappingInformation mappingInfo =
        MappingInformation.builder()
            .fieldMappingInformation(Collections.singletonList(fieldMapping))
            .build();

    given(
            mockFormatterService.fromJsonNode(
                fieldMapping.getSourceFieldMappingInformation().get(),
                sourceRootNode.at("/Instrument/productIdentifier")))
        .willReturn("foo");
    given(
            mockFieldTransformerService.convertType(
                fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                "foo"))
        .willReturn("foo");
    TextNode returnNode = JsonNodeFactory.instance.textNode("foo");
    given(
            mockFormatterService.toValueNode(
                fieldMapping.getTargetFieldMappingInformation(), Optional.of("foo")))
        .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-PROI\":\"foo\"}}";
    JSONAssert.assertEquals(
        expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }


  @Test
  public void transformSingleNodeManyToOneFields() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.ACCNT-NO")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.accountBranchCode")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                            .orderNo(21)
                                            .sequenceNo(1)
                                            .size(3)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/accountBranchCode")))
            .willReturn("01");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "01"))
            .willReturn("001");
    TextNode returnNode = JsonNodeFactory.instance.textNode("001");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("001")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"ACCNT-NO\":\"001\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }

    @Test
    public void transformSingleNodeWhenMappingNotFound() throws JsonProcessingException, ParseException, JSONException {
        // arrange
        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        SourceFieldMappingInformation.builder()
                                                .name("Instrument.productIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                                .build()))
                        .build();

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .fieldMappingInformation(Collections.singletonList(fieldMapping))
                        .build();

        given(
                mockFormatterService.fromJsonNode(
                        fieldMapping.getSourceFieldMappingInformation().get(),
                        sourceRootNode.at("/Instrument/productIdentifier")))
                .willReturn("foo");
        given(
                mockFieldTransformerService.convertType(
                        fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                        null,
                        "foo"))
                .willReturn(null);


        // act
        JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

        // assert
        String expectedJson = "{}";
        JSONAssert.assertEquals(
                expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
    }


    @Test
  public void transformSingleNodeManyToOneFieldsForNumbersAndPaddingUp() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.ACCNT-NO")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.NUMBER).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.accountBranchCode")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.NUMBER).build())
                                            .orderNo(21)
                                            .sequenceNo(1)
                                            .size(3)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/accountBranchCode")))
            .willReturn("01");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "01"))
            .willReturn("001");
    TextNode returnNode = JsonNodeFactory.instance.textNode("001");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("001")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"ACCNT-NO\":\"001\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }


  @Test
  public void transformSingleNodeManyToOneFieldsForTrimming() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.ACCNT-NO")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.securityNo")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                            .orderNo(21)
                                            .sequenceNo(1)
                                            .size(3)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/securityNo")))
            .willReturn("00N");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "00N"))
            .willReturn("00N");
    TextNode returnNode = JsonNodeFactory.instance.textNode("00N");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("00N")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"ACCNT-NO\":\"00N\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }


  @Test
  public void transformSingleNodeManyToOneFieldsForDate() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.OUT-ED-EFF-D")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("yyyy-MM-dd")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.changeDate")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .size(6)
                                            .orderNo(21)
                                            .sequenceNo(1)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/changeDate")))
            .willReturn("2019-12-15");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "2019-12-15"))
            .willReturn("2019-12-15");
    TextNode returnNode = JsonNodeFactory.instance.textNode("2019-12-15");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("2019-12-15 ")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-ED-EFF-D\":\"2019-12-15\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }

  @Test
  public void transformSingleNodeToManyToOneFieldsForMonth() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.OUT-ED-EFF-D")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("MM/dd/yyyy")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.month")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .size(6)
                                            .orderNo(21)
                                            .sequenceNo(1)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/month")))
            .willReturn("04");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "04"))
            .willReturn("04");
    TextNode returnNode = JsonNodeFactory.instance.textNode("04/");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("04/")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-ED-EFF-D\":\"04/\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }

  @Test
  public void transformSingleNodeToManyToOneFieldsForDay() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.OUT-ED-EFF-D")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("MM/dd/yyyy")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.day")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .size(6)
                                            .orderNo(21)
                                            .sequenceNo(2)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/day")))
            .willReturn("16");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "16"))
            .willReturn("16");
    TextNode returnNode = JsonNodeFactory.instance.textNode("16/");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("16/")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-ED-EFF-D\":\"16/\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }

  @Test
  public void transformSingleNodeToManyToOneFieldsForCentury() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.OUT-ED-EFF-D")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("MM/dd/yyyy")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.century")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .size(6)
                                            .orderNo(21)
                                            .sequenceNo(3)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/century")))
            .willReturn("20");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "20"))
            .willReturn("20");
    TextNode returnNode = JsonNodeFactory.instance.textNode("20");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("20")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-ED-EFF-D\":\"20\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }


  @Test
  public void transformSingleNodeManyToOneFieldsForHour() throws JsonProcessingException, ParseException, JSONException {
    // arrange
    FieldMappingInformation fieldMapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .name("WS-OUT-REC.OUT-ED-EFF-D")
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .orderNo(21)
                                    .maxSequenceNo(1)
                                    .sourceDateFormatter("yyyy-MM-dd")
                                    .build())
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .name("Instrument.hour")
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .size(6)
                                            .orderNo(21)
                                            .sequenceNo(2)
                                            .build()))
                    .build();

    MappingInformation mappingInfo =
            MappingInformation.builder()
                    .fieldMappingInformation(Collections.singletonList(fieldMapping))
                    .build();

    given(
            mockFormatterService.fromJsonNode(
                    fieldMapping.getSourceFieldMappingInformation().get(),
                    sourceRootNode.at("/Instrument/hour")))
            .willReturn("17");
    given(
            mockFieldTransformerService.convertType(
                    fieldMapping.getSourceFieldMappingInformation().get().getTypeInfo(),
                    fieldMapping.getTargetFieldMappingInformation().getTypeInfo(),
                    "17"))
            .willReturn("17");
    TextNode returnNode = JsonNodeFactory.instance.textNode("17:");
    given(
            mockFormatterService.toValueNode(
                    fieldMapping.getTargetFieldMappingInformation(), Optional.of("17")))
            .willReturn(returnNode);

    // act
    JsonNode result = transformationEngine.transform(mappingInfo, sourceRootNode);

    // assert
    String expectedJson = "{\"WS-OUT-REC\": {\"OUT-ED-EFF-D\":\"17:\"}}";
    JSONAssert.assertEquals(
            expectedJson, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }
}
