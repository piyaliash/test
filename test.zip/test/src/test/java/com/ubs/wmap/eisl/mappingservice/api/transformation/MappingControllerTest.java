package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.net.HttpHeaders;
import com.google.gson.Gson;
import com.ubs.wmap.eisl.mappingservice.dto.EnumMappingResponseSO;
import com.ubs.wmap.eisl.mappingservice.dto.MappingFormatResponseSO;
import com.ubs.wmap.eisl.mappingservice.dto.MappingResponseSO;
import com.ubs.wmap.eisl.mappingservice.dto.MappingUpdateRequestSO;
import com.ubs.wmap.eisl.mappingservice.exception.BadRequestException;
import com.ubs.wmap.eisl.mappingservice.service.MappingMetaDataService;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import com.ubs.wmap.eisl.mappingservice.validation.TokenValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.HttpClientErrorException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ComponentScan(basePackages = {"com.ubs.wmap.eisl.mappingservice"})
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MappingControllerTest {

    private MockMvc mockMvc;
    @Mock
    TokenValidator tokenValidator;

    @Mock
    MappingMetaDataService mappingMetaDataService;
    @Mock
    MessageResourceUtil messageSourceUtil;
    @InjectMocks
    MappingController mappingController;

    @Before
    public void init() {
        mockMvc = MockMvcBuilders
                .standaloneSetup(mappingController)
                .build();
    }


    @Test
    public void getMappingsTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
       Mockito.when(mappingMetaDataService.getMappings(ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(getMappingSO());
        mockMvc.perform(get("/mapping").param("token", "token").param("formatName", "FPMD").param("domain", "Instrument").param("subDomain", "subDomain").param("fileName","test")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.result").exists());
    }

    @Test (expected = BadRequestException.class)
    public void getMappingsTestMandatoryFieldsThrowExceptionIfFormatNotPresent() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.when(mappingMetaDataService.getMappings(ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(getMappingSO());
        mappingController.getMappings("","token","Instrument","","");
    }

    @Test (expected = BadRequestException.class)
    public void getMappingsTestMandatoryFieldsThrowExceptionIfDomainNotPresent() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.when(mappingMetaDataService.getMappings(ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(getMappingSO());
        mappingController.getMappings("test","token","","","");
    }

    @Test
    public void getMappingFormatDetailsTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.when(mappingMetaDataService.getAllMappingFormats()).thenReturn(getFormatSO());
        mockMvc.perform(get("/mappingformat").param("token", "token")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.result").exists());
    }


    @Test
    public void postMappingDetailsTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.when(mappingMetaDataService.saveMappings(ArgumentMatchers.any())).thenReturn(getMappingSO());
        mockMvc.perform(post("/mapping").header(HttpHeaders.AUTHORIZATION, "basic").param("token", "token").contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(constructPayload()))).andDo(print()).andExpect(status().isOk());
    }

    @Test
    public void updateMappingDetailsTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.when(mappingMetaDataService.updateMappings(ArgumentMatchers.any())).thenReturn(getMappingSO());
        mockMvc.perform(put("/mapping").header(HttpHeaders.AUTHORIZATION, "basic").param("token", "token").contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(constructPayload()))).andDo(print()).andExpect(status().isOk());
    }

    @Test
    public void deleteMappingDetailsTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.doNothing().when(mappingMetaDataService).deleteMapping(ArgumentMatchers.any(), ArgumentMatchers.anyString());
        Mockito.when(messageSourceUtil.getMessage("DELETE_SUCCESS_MSG")).thenReturn("success");
        mockMvc.perform(delete("/mapping").contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(asJsonString(constructPayload())).param("token", "token").param("formatName", "JSON").param("domain", "Instrument")).andDo(print()).andExpect(status().isOk());
    }

    @Test
    public void deleteMappingDetailsByFormatIdAndAttributeIdTest() throws Exception {
        Mockito.doNothing().when(tokenValidator).validate("token");
        Mockito.doNothing().when(mappingMetaDataService).deleteMappingByFormatNameAndOntologyAndUbsAttributeId(ArgumentMatchers.any(), ArgumentMatchers.anyString());
        Mockito.when(messageSourceUtil.getMessage("DELETE_SUCCESS_MSG")).thenReturn("success");
        mockMvc.perform(delete("/deletemapping").contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(asJsonString(constructPayload())).param("token", "token")
                .param("formatName", "JSON").param("ontologyAtrributeId", "1001").param("ubsAtrributeId", "2001")
                .param("domain", "Instrument")).andDo(print()).andExpect(status().isOk());
    }

    private MappingUpdateRequestSO constructPayload() throws IOException {
        File resource = new ClassPathResource("MappingPayload.json").getFile();
        Gson gson = new Gson();
        FileReader reader = new FileReader(resource);
        return gson.fromJson(reader, MappingUpdateRequestSO.class);
    }

    private String asJsonString(MappingUpdateRequestSO request) {
        String asJson = null;
        try {
            asJson = new ObjectMapper().writeValueAsString(request);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asJson;
    }

    private List<MappingFormatResponseSO> getFormatSO() {
        List<MappingFormatResponseSO> mappingFormatResponseSOS = new ArrayList<>();
        mappingFormatResponseSOS.add(getMappingFormatSO());
        return mappingFormatResponseSOS;
    }

    private List<EnumMappingResponseSO> getEnumMappingSO() {
        List<EnumMappingResponseSO> enumMappingResponseSOS = new ArrayList<>();
        EnumMappingResponseSO enumMappingResponseSO = new EnumMappingResponseSO();
        enumMappingResponseSO.setEnumMappingId(2L);
        enumMappingResponseSO.setEnumUbsId(1L);
        enumMappingResponseSO.setEnumOntologyId(1L);
        enumMappingResponseSO.setEnumUbsValue("$");
        enumMappingResponseSO.setEnumOntologyValue("dollar");
        enumMappingResponseSOS.add(enumMappingResponseSO);
        return enumMappingResponseSOS;
    }

    private List<MappingResponseSO> getMappingSO() {
        List<MappingResponseSO> mappingResponseSOS = new ArrayList<>();
        MappingResponseSO mappingResponseSO = new MappingResponseSO();
        mappingResponseSO.setOntologyAttributeId(1001L);
        mappingResponseSO.setOntologyAtrributeName("Product-Identifire");
        mappingResponseSO.setMappingId(1L);
        mappingResponseSO.setUbsAttributeId(2001L);
        mappingResponseSO.setUbsAtrributeName("WS-OUT_REC.OUT-PROI");
        mappingResponseSO.setMappingFormatResponseSO(getMappingFormatSO());
        mappingResponseSO.setEnumMappingResponseSOS(getEnumMappingSO());
        mappingResponseSOS.add(mappingResponseSO);
        return mappingResponseSOS;
    }

    private MappingFormatResponseSO getMappingFormatSO() {
        MappingFormatResponseSO mappingFormatResponseSO = new MappingFormatResponseSO();
        mappingFormatResponseSO.setFormatType("JSON");
        mappingFormatResponseSO.setMappingFormatReferenceId(21L);
        return mappingFormatResponseSO;
    }

}
