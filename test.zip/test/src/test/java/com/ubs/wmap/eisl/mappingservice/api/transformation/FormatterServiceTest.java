package com.ubs.wmap.eisl.mappingservice.api.transformation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ValueNode;
import com.ubs.wmap.eisl.mappingservice.api.mapping.*;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.SourceFieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldMappingInformation.TargetFieldMappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo.FieldType;

import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

import com.ubs.wmap.eisl.mappingservice.exception.MappingFormatDataNotFoundException;
import org.junit.Test;

public class FormatterServiceTest {
  private FormatterService formatterService = new FormatterService();

  @Test
  public void formatStringValueTrimmedWhenSizeIsNotSpecified() throws ParseException{
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .defaultValue(Optional.of("foo"))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of("string"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("string");
  }

  @Test
  public void testReturnBigDecimalIfFormatNotPresent() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.NUMBER).build())
                                    .format(Optional.empty())
                                    .build())
                    .build();

    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of(new BigDecimal("34.440")));

    // assert
    assertThat(result.toString()).isEqualTo("34.440");
  }

  @Test
  public void formatStringValuePaddingRight() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .size(OptionalInt.of(10))
                    .paddingDirection(Optional.of(PaddingDirection.RIGHT))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of("string"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("    string");
  }

  @Test
  public void formatStringValueDefaultPaddingLeft() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .size(OptionalInt.of(10))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of("string"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("    string");
  }


  @Test
  public void formatStringValueForTrimming() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("0,4"))
                                    .size(OptionalInt.of(4))
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("123456789"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("1234");
  }

  @Test
  public void formatStringValueForUppercase() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("S"))
                                    .size(OptionalInt.of(8))
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("test"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("    TEST");
  }

  @Test
  public void formatStringValuSizeSmallerThanValue() {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .name("foo")
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .size(OptionalInt.of(1))
                    .build())
            .build();

    // act & assert
    assertThatThrownBy(
            () ->
                formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("string")))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage(
            "The target field 'foo' is defined with a size of '1' but the value of the source field '6' which is larger than the target field size.");
  }

  @Test
  public void formatDefaultValueMissingValue() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                    .defaultValue(Optional.of("foo"))
                    .build())
            .build();
    // act
    ValueNode result =
        formatterService.toValueNode(mapping.getTargetFieldMappingInformation(), Optional.empty());

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("foo");
  }


  @Test
  public void formatDefaultValuetrim() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("0,1"))
                                    .defaultValue(Optional.of("00"))
                                    .build())
                    .build();
    // act
    ValueNode result =
            formatterService.toValueNode(mapping.getTargetFieldMappingInformation(), Optional.ofNullable("NTHGYRD"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("00N");
  }

  @Test
  public void formatDefaultValueCheckNoOfLinesIfLengthIsLessThanThirty() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("noOfLines"))
                                    .build())
                    .build();
    // act
    ValueNode result =
            formatterService.toValueNode(mapping.getTargetFieldMappingInformation(), Optional.ofNullable("trertfdgtfderfgvcfdrtyujhbgt"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("1");
  }

  @Test
  public void formatDefaultValueCheckNoOfLinesIfLengthIsEqualToThirty() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("noOfLines"))
                                    .build())
                    .build();
    // act
    ValueNode result =
            formatterService.toValueNode(mapping.getTargetFieldMappingInformation(), Optional.ofNullable("uytyujhnbgthloikjmnhyuikjnhytg"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("1");
  }

  @Test
  public void formatDefaultValueCheckNoOfLinesIfLengthIsGreaterThanThirty() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                                    .format(Optional.of("noOfLines"))
                                    .build())
                    .build();
    // act
    ValueNode result =
            formatterService.toValueNode(mapping.getTargetFieldMappingInformation(), Optional.ofNullable("trertfdgtfderfgvcfdrtyujhbgtnjhkhkjgkggj"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("2");
  }

  @Test
  public void formatDateTimeValue() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                    .format(Optional.of("yyyy-MM-dd HH:mm:ss.SSS"))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(),
            Optional.of(LocalDateTime.of(2019, 6, 13, 17, 00)));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("2019-06-13 17:00:00.000");
  }

  @Test
  public void formatDateTimeValueIfFormatNotPresent() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                    .format(Optional.of("MM/dd/yyy"))
                                    .sourceDateFormatter("yyyy-MM-dd")
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(),
                    Optional.of("2019-06-17"));

    // assert
    assertThat(result.textValue()).isEqualTo("06/17/2019");
  }

  @Test
  public void formatDateValue() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.DATE).build())
                    .format(Optional.of("yyyy-MM-dd"))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of(LocalDate.of(2019, 6, 13)));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("2019-06-13");
  }

  @Test
  public void formatTimeValue() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.TIME).build())
                    .format(Optional.of("HH:mm:ss.SSS"))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of(LocalTime.of(17, 00)));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("17:00:00.000");
  }

  @Test
  public void formatNumberValue() throws ParseException {
    // arrange
    FieldMappingInformation mapping =
        FieldMappingInformation.builder()
            .targetFieldMappingInformation(
                TargetFieldMappingInformation.builder()
                    .typeInfo(FieldTypeInfo.builder().type(FieldType.NUMBER).build())
                    .format(Optional.of("0000000.00000000"))
                    .build())
            .build();

    // act
    ValueNode result =
        formatterService.toValueNode(
            mapping.getTargetFieldMappingInformation(), Optional.of(new BigDecimal("34.440")));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("0000034.44000000");
  }

  @Test
  public void transformStringField() {
    // arrange
    FieldMappingInformation stringMapping =
        FieldMappingInformation.builder()
            .sourceFieldMappingInformation(
                Optional.of(
                    SourceFieldMappingInformation.builder()
                        .typeInfo(FieldTypeInfo.builder().type(FieldType.STRING).build())
                        .build()))
            .build();

    // act
    Object result =
        formatterService.fromJsonNode(
            stringMapping.getSourceFieldMappingInformation().get(),
            JsonNodeFactory.instance.textNode("foo"));

    // assert
    assertThat(result).isEqualTo("foo");
  }

  @Test
  public void transformDateTimeField() {
    // arrange
    FieldMappingInformation stringMapping =
        FieldMappingInformation.builder()
            .sourceFieldMappingInformation(
                Optional.of(
                    SourceFieldMappingInformation.builder()
                        .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                        .format(Optional.of("yyyy-MM-dd HH:mm:ss.S"))
                        .build()))
            .build();

    // act
    Object result =
        formatterService.fromJsonNode(
            stringMapping.getSourceFieldMappingInformation().get(),
            JsonNodeFactory.instance.textNode("2018-06-13 17:00:00.0"));

    // assert
    assertThat(result).isEqualTo(LocalDateTime.of(2018, 6, 13, 17, 0, 0, 0));
  }


  @Test
  public void testcorrectMappingFormatNotPresenttransformDateTimeField() {
    // arrange
    FieldMappingInformation stringMapping =
            FieldMappingInformation.builder()
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .format(Optional.of(""))
                                            .build()))
                    .build();

    // act
    Object result =
            formatterService.fromJsonNode(
                    stringMapping.getSourceFieldMappingInformation().get(),
                    JsonNodeFactory.instance.textNode("2018-06-13"));

    // assert
    assertThat(result).isEqualTo("2018-06-13");
  }

  @Test
  public void testMappingFormatNotPresenttransformDateTimeField() {
    // arrange
    FieldMappingInformation stringMapping =
            FieldMappingInformation.builder()
                    .sourceFieldMappingInformation(
                            Optional.of(
                                    SourceFieldMappingInformation.builder()
                                            .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                            .format(Optional.empty())
                                            .build()))
                    .build();

    // act
    Object result =
            formatterService.fromJsonNode(
                    stringMapping.getSourceFieldMappingInformation().get(),
                    JsonNodeFactory.instance.textNode("2018-06-13"));

    // assert
    assertThat(result).isEqualTo("2018-06-13");
  }

  @Test
  public void transformDateField() {
    // arrange
    FieldMappingInformation stringMapping =
        FieldMappingInformation.builder()
            .sourceFieldMappingInformation(
                Optional.of(
                    SourceFieldMappingInformation.builder()
                        .typeInfo(FieldTypeInfo.builder().type(FieldType.DATE).build())
                        .format(Optional.of("yyyy-MM-dd"))
                        .build()))
            .build();

    // act
    Object result =
        formatterService.fromJsonNode(
            stringMapping.getSourceFieldMappingInformation().get(),
            JsonNodeFactory.instance.textNode("2018-06-13"));

    // assert
    assertThat(result).isEqualTo(LocalDate.of(2018, 6, 13));
  }

  @Test
  public void transformTimeField() {
    // arrange
    FieldMappingInformation stringMapping =
        FieldMappingInformation.builder()
            .sourceFieldMappingInformation(
                Optional.of(
                    SourceFieldMappingInformation.builder()
                        .typeInfo(FieldTypeInfo.builder().type(FieldType.TIME).build())
                        .format(Optional.of("HH:mm:ss.S"))
                        .build()))
            .build();

    // act
    Object result =
        formatterService.fromJsonNode(
            stringMapping.getSourceFieldMappingInformation().get(),
            JsonNodeFactory.instance.textNode("17:00:00.0"));

    // assert
    assertThat(result).isEqualTo(LocalTime.of(17, 0, 0, 0));
  }


  @Test
  public void transformDateFieldForCentury() throws ParseException {

      // arrange
      FieldMappingInformation mapping =
              FieldMappingInformation.builder()
                      .targetFieldMappingInformation(
                              TargetFieldMappingInformation.builder()
                                      .typeInfo(FieldTypeInfo.builder().type(FieldType.DATETIME).build())
                                      .format(Optional.of("yyyy"))
                                      .sourceDateFormatter("yyyy-MM-dd")
                                      .build())
                      .build();

      // act
      ValueNode result =
              formatterService.toValueNode(
                      mapping.getTargetFieldMappingInformation(), Optional.of(LocalDate.of(2019, 6, 13)));

      // assert
      assertThat(result.isTextual()).isTrue();
      assertThat(result.textValue()).isEqualTo("20");

  }

  @Test
  public void formatStringValueForEnum() throws ParseException {

    // arrange

    List<EnumDetails> enumDetailsList = new ArrayList<>();

    EnumDetails enumDetails = new EnumDetails();
    enumDetails.setTargetEnumValue("USD");
    enumDetails.setSourceEnumValue("$");
    enumDetailsList.add(enumDetails);
    EnumDetails enumDetails2 = new EnumDetails();
    enumDetails2.setTargetEnumValue("Rs");
    enumDetails2.setSourceEnumValue("Rupees");

    enumDetailsList.add(enumDetails2);

    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.ENUM).build())
                                    .format(Optional.empty())
                                    .enumDetails(enumDetailsList)
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("$"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("USD");
  }

  @Test (expected=IllegalArgumentException.class)
  public void expectExceptionIfMappingDetailsNotFoundformatStringValueForEnum() throws ParseException {

    // arrange

    List<EnumDetails> enumDetailsList = new ArrayList<>();

    EnumDetails enumDetails = new EnumDetails();
    enumDetails.setTargetEnumValue("USD");
    enumDetails.setSourceEnumValue("$");
    enumDetailsList.add(enumDetails);
    EnumDetails enumDetails2 = new EnumDetails();
    enumDetails2.setTargetEnumValue("Rs");
    enumDetails2.setSourceEnumValue("Rupees");

    enumDetailsList.add(enumDetails2);

    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.ENUM).build())
                                    .format(Optional.empty())
                                    .enumDetails(null)
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("$"));


  }


  @Test
  public void formatStringValueForBoolean() throws ParseException {
    List<BooleanValues> booleanValuesList = new ArrayList<>();

    BooleanValues booleanValues2 = new BooleanValues();
    booleanValues2.setTargetBooleanValue("1");
    booleanValues2.setSourceBooleanValue("true");
    booleanValuesList.add(booleanValues2);
    BooleanValues booleanValues1 = new BooleanValues();
    booleanValues1.setTargetBooleanValue("0");
    booleanValues1.setSourceBooleanValue("false");

    booleanValuesList.add(booleanValues1);


    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.BOOLEAN).build())
                                    .format(Optional.empty())
                                    .booleanDetails(booleanValuesList)
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("true"));

    // assert
    assertThat(result.isTextual()).isTrue();
    assertThat(result.textValue()).isEqualTo("1");
  }

  @Test (expected=IllegalArgumentException.class)
  public void expectExceptionIfMappingDetailsNotFoundStringValueForBoolean() throws ParseException {
    List<BooleanValues> booleanValuesList = new ArrayList<>();

    BooleanValues booleanValues2 = new BooleanValues();
    booleanValues2.setTargetBooleanValue("1");
    booleanValues2.setSourceBooleanValue("true");
    booleanValuesList.add(booleanValues2);
    BooleanValues booleanValues1 = new BooleanValues();
    booleanValues1.setTargetBooleanValue("0");
    booleanValues1.setSourceBooleanValue("false");

    booleanValuesList.add(booleanValues1);


    // arrange
    FieldMappingInformation mapping =
            FieldMappingInformation.builder()
                    .targetFieldMappingInformation(
                            TargetFieldMappingInformation.builder()
                                    .typeInfo(FieldTypeInfo.builder().type(FieldType.BOOLEAN).build())
                                    .format(Optional.empty())
                                    .booleanDetails(null)
                                    .build())
                    .build();

    // act
    ValueNode result =
            formatterService.toValueNode(
                    mapping.getTargetFieldMappingInformation(), Optional.of("true"));

  }
}
