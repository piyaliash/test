package com.ubs.wmap.eisl.mappingservice.excel;

import com.ubs.wmap.eisl.mappingservice.model.FormatAttribute;


import com.ubs.wmap.eisl.mappingservice.repository.MappingRepository;

import com.ubs.wmap.eisl.mappingservice.service.impl.MappingMetaDataServiceImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MappingMetadataTest {
  @InjectMocks MappingMetaDataServiceImpl mappingMetaDataService1;

  @Mock MappingRepository mappingRepository;



  @Test
  public void testgetMappingDetailswithoutdata() {

  }

  private List<FormatAttribute> constructFormatAttributeList() {
    List<FormatAttribute> formatAttributes = new ArrayList<>();
    FormatAttribute formatAttribute = new FormatAttribute();
    formatAttribute.setDescription("");
    formatAttributes.add(formatAttribute);
    return formatAttributes;
  }
}
