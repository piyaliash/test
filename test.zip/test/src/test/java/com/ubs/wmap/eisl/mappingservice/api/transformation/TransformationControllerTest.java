package com.ubs.wmap.eisl.mappingservice.api.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.ImmutableMap;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformationService;
import com.ubs.wmap.eisl.mappingservice.exception.EislTokendException;
import com.ubs.wmap.eisl.mappingservice.exception.MappingServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

@RunWith(MockitoJUnitRunner.Silent.class)
public class TransformationControllerTest {

    private static final String INVALID_MESSAGE = "invalidEisl";
    private static final String INTERNAL_SERVER_ERROR = "internalError";
    private static final String SYSTEM_NAME = "DataHub Test";
    private static final String CORRELATION_ID_CLAIM_KEY_NAME = "correlationId";
    private static final ObjectNode SOURCE_NODE = JsonNodeFactory.instance.objectNode();
    public static final String APP_MESSAGE_EISL_INVALID_TOKEN_MSG =
            "app.message.EISL_INVALID_TOKEN_MSG";
    private String token = "token";
    private TransformationRequest transformationRequest =
            TransformationRequest.builder()
                    .entityName("entity")
                    .sourceFormatName("sourceFormat")
                    .destinationFormatName("destinationFormat")
                    .source(SOURCE_NODE)
                    .build();

    @InjectMocks
    private TransformationController controller;

    @Mock
    private TokenService tokenService;

    @Mock
    private MessageSource mockMessageSource;

    @Mock
    private MappingInformationService mockMappingInformationService;

    @Mock
    private TransformationEngine mockTransformationEngine;


    @Test
    public void transformCallsMappingServiceAndTransformationEngine() throws Exception {
        // arrange
        given(tokenService.init(token))
                .willReturn(ImmutableMap.of("claims", ImmutableMap.of(CORRELATION_ID_CLAIM_KEY_NAME, "1234567890")));

        MappingInformation mappingInfo = MappingInformation.builder().build();
        given(mockMappingInformationService.findMappingInformation(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(),ArgumentMatchers.any())).willReturn(mappingInfo);

        JsonNode responseNode = JsonNodeFactory.instance.objectNode();
        given(mockTransformationEngine.transform(mappingInfo, SOURCE_NODE)).willReturn(responseNode);

        // act
        ResponseEntity<TransformationResponse> response =
                controller.transform(transformationRequest, token);

        // assert
         assertThat(response.getBody().getResult()).isEqualTo(responseNode);
    }

    @Test
    public void transformInvalidToken() {
        // arrange
        String badToken = "badToken";
        given(tokenService.init(badToken)).willThrow(new TokenUnwrapException(new Throwable()));
        given(mockMessageSource.getMessage(eq(APP_MESSAGE_EISL_INVALID_TOKEN_MSG), any(), any()))
                .willReturn(INVALID_MESSAGE);

        // act
        assertThatThrownBy(() -> controller.transform(transformationRequest, badToken))
                .isInstanceOf(EislTokendException.class)
                .hasMessage(INVALID_MESSAGE);
    }

    @Test
    public void transformExpiredToken() {
        // arrange
        String expire = "expiredToken";
        given(tokenService.init(expire)).willThrow(new TokenExpireException("foobar", new Throwable()));
        given(mockMessageSource.getMessage(eq(APP_MESSAGE_EISL_INVALID_TOKEN_MSG), any(), any()))
                .willReturn(INVALID_MESSAGE);

        // act
        assertThatThrownBy(() -> controller.transform(transformationRequest, expire))
                .isInstanceOf(EislTokendException.class)
                .hasMessage(INVALID_MESSAGE);
    }

    @Test
    public void transformRuntimeError() {
        // arrange
        String otherErrorToken = "otherError";
        given(tokenService.init(otherErrorToken)).willThrow(new RuntimeException());
        given(mockMessageSource.getMessage(eq("app.message.INTERNAL_SERVER_ERROR_MSG"), any(), any()))
                .willReturn(INTERNAL_SERVER_ERROR);

        // act
        assertThatThrownBy(() -> controller.transform(transformationRequest, otherErrorToken))
                .isInstanceOf(MappingServiceException.class)
                .hasMessage(INTERNAL_SERVER_ERROR);
    }

    @Test
    public void transformNoClaimsAttribute() {
        // arrange
        String noClaimsAttribute = "noClaimsAttribute";
        given(tokenService.init(noClaimsAttribute)).willReturn(ImmutableMap.of());
        given(mockMessageSource.getMessage(eq(APP_MESSAGE_EISL_INVALID_TOKEN_MSG), any(), any()))
                .willReturn(INVALID_MESSAGE);

        // act
        assertThatThrownBy(() -> controller.transform(transformationRequest, noClaimsAttribute))
                .isInstanceOf(EislTokendException.class)
                .hasMessage(INVALID_MESSAGE);
    }

    @Test
    public void uploadExcelFileTest() throws Exception {
        given(tokenService.init(token))
                .willReturn(ImmutableMap.of("claims", ImmutableMap.of(CORRELATION_ID_CLAIM_KEY_NAME, "1234567890")));

        File file =
                new File(Objects.requireNonNull(getClass().getClassLoader().getResource("MappingServiceExample.xlsx")).getFile());
        FileInputStream inputStream = new FileInputStream(file);
        MockMultipartFile mockMultipartFile =
                new MockMultipartFile("file", "NameOfTheFile", "multipart/form-data", inputStream);
        doNothing().when(mockMappingInformationService).uploadMappings(mockMultipartFile, token);
        ResponseEntity response =
                controller.uploadExcelFile(mockMultipartFile, token);
    }

}
