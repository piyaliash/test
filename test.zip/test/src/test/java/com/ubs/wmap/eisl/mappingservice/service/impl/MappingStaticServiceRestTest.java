package com.ubs.wmap.eisl.mappingservice.service.impl;

import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.util.EislUtil;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;

@SuppressWarnings("deprecation")
@Slf4j
@RunWith(MockitoJUnitRunner.class)
public class MappingStaticServiceRestTest {

    @Mock
    RestTemplate restTemplate;
    @Mock
    EislUtil eislUtil;

    @Mock
    MessageResourceUtil messages;

    @InjectMocks
    MappingStaticServiceRest mappingStaticServiceRest;

    @Test
    public void getDomainDetails() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        List<DomainDetailsResponseVO> domainDetailsResponseVOS = new ArrayList<>();
        domainDetailsResponseVOS.add(DomainDetailsResponseVO.builder()
                .domainId(1L)
                .domainName("Instrument")
                .subDomainName("")
                .build());
        DomainDetailsResListSO dto = DomainDetailsResListSO.builder().domainDetailsResponseVOList(domainDetailsResponseVOS).build();
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/domain?token=eisl-token&domainName=test-domain-name";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        ResponseEntity<DomainDetailsResListSO> resp = new ResponseEntity<>(dto, HttpStatus.OK);
        log.info("Response Body: {}", resp.getBody());
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        ResponseEntity<DomainDetailsResListSO> domainDetails = mappingStaticServiceRest.getDomainDetails(serviceUrl, "token", "Instrument");
        assertEquals(Long.valueOf(1), domainDetails.getBody().getDomainDetailsResponseVOList().get(0).getDomainId());
    }

    @Test(expected = MappingServiceException.class)
    public void getDomainDetailsExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        List<DomainDetailsResponseVO> domainDetailsResponseVOS = new ArrayList<>();
        domainDetailsResponseVOS.add(DomainDetailsResponseVO.builder()
                .domainId(1L)
                .domainName("Instrument")
                .subDomainName("")
                .build());
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/domain?token=eisl-token&domainName=test-domain-name";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(RestClientException.class);
        mappingStaticServiceRest.getDomainDetails(serviceUrl, "token", "Instrument");

    }

    @Test
    public void getFormatDetails() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        List<FormatResponseSO> formatResponseSOS = new ArrayList<>();
        formatResponseSOS.add(FormatResponseSO.builder()
                .formatId(21L)
                .formatName("JSON")
                .description("")
                .build());
        FormatListResponseSO dto = FormatListResponseSO.builder().formatResponseSOList(formatResponseSOS).build();
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/format?token=eisl-token&domainName=test-domain-name&subDomainName=''";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        ResponseEntity<FormatListResponseSO> resp = new ResponseEntity<>(dto, HttpStatus.OK);
        log.info("Response Body: {}", resp.getBody());
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        ResponseEntity<FormatListResponseSO> formatDetails = mappingStaticServiceRest.getFormatDetails(serviceUrl, "token", "Instrument");
        assertEquals("JSON", formatDetails.getBody().getFormatResponseSOList().get(0).getFormatName());

    }

    @Test(expected = MappingServiceException.class)
    public void getFormatDetailsExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        List<FormatResponseSO> formatResponseSOS = new ArrayList<>();
        formatResponseSOS.add(FormatResponseSO.builder()
                .formatId(21L)
                .formatName("JSON")
                .description("")
                .build());
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/format?token=eisl-token&domainName=test-domain-name&subDomainName=''";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(RestClientException.class);
        mappingStaticServiceRest.getFormatDetails(serviceUrl, "token", "Instrument");


    }

    @Test
    public void getAttribute() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        List<AttributeResponseSO> attributeResponseSOS = new ArrayList<>();
        attributeResponseSOS.add(AttributeResponseSO.builder()
                .attributeId(1001L)
                .attributeName("Attribute-Name")
                .description("")
                .build());
        AttributeListResponseSO dto = AttributeListResponseSO.builder().attributeResponseSOList(attributeResponseSOS).build();
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/format?token=eisl-token&domainName=test-domain-name&subDomainName=''";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        ResponseEntity<AttributeListResponseSO> resp = new ResponseEntity<>(dto, HttpStatus.OK);
        log.info("Response Body: {}", resp.getBody());
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        ResponseEntity<AttributeListResponseSO> attribute = mappingStaticServiceRest.getAttribute(serviceUrl, "token", "Instrument");
        assertEquals("Attribute-Name", attribute.getBody().getAttributeResponseSOList().get(0).getAttributeName());

    }

    @Test(expected = MappingServiceException.class)
    public void getAttributeExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        List<AttributeResponseSO> attributeResponseSOS = new ArrayList<>();
        attributeResponseSOS.add(AttributeResponseSO.builder()
                .attributeId(1001L)
                .attributeName("Attribute-Name")
                .description("")
                .build());
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/ubsattributes?token=eisl-token&domainName=test-domain-name&subDomainName=''";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(RestClientException.class);
        mappingStaticServiceRest.getAttribute(serviceUrl, "token", "Instrument");


    }

    @Test
    public void getEnumByIds() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        List<EnumDetailsResponseSO> enumDetailsResponseSOS = new ArrayList<>();
        enumDetailsResponseSOS.add(EnumDetailsResponseSO.builder()
                .enumDetailsId(1L)
                .enumKeyValue("key-value")
                .enumKey("key-name")
                .build());
        EnumDetailsListResponseSO dto = EnumDetailsListResponseSO.builder().enumDetailsResponseSOS(enumDetailsResponseSOS).build();
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/ontologyenums/ids?token=eisl-token&attributeIds=attribute-id";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        ResponseEntity<EnumDetailsListResponseSO> resp = new ResponseEntity<>(dto, HttpStatus.OK);
        log.info("Response Body: {}", resp.getBody());
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        ResponseEntity<EnumDetailsListResponseSO> attribute = mappingStaticServiceRest.getEnumByIds(serviceUrl, "token", "2");
        assertEquals("key-value", attribute.getBody().getEnumDetailsResponseSOS().get(0).getEnumKeyValue());

    }

    @Test(expected = MappingServiceException.class)
    public void getEnumByIdsExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        List<EnumDetailsResponseSO> enumDetailsResponseSOS = new ArrayList<>();
        enumDetailsResponseSOS.add(EnumDetailsResponseSO.builder()
                .enumDetailsId(1L)
                .enumKeyValue("key-value")
                .enumKey("key-name")
                .build());
        String serviceUrl = "http://localhost:9090/eisl/static-data/v1/ontologyenums/ids?token=eisl-token&attributeIds=attribute-id";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", "Test");
        Mockito.when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(RestClientException.class);
        mappingStaticServiceRest.getEnumByIds(serviceUrl, "token", "2");


    }
}