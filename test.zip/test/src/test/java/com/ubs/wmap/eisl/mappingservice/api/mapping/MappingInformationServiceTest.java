package com.ubs.wmap.eisl.mappingservice.api.mapping;

import com.ubs.wmap.eisl.mappingservice.excel.EnumMappingDefinition;
import com.ubs.wmap.eisl.mappingservice.excel.ExcelFlatMappingDataReader;
import com.ubs.wmap.eisl.mappingservice.excel.FlatMappingData;
import com.ubs.wmap.eisl.mappingservice.excel.MappingDefinition;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.service.MappingMetaDataService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;

@ComponentScan(basePackages = {"com.ubs.wmap.eisl.mappingservice"})
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MappingInformationServiceTest {

    @Mock
    MappingMetaDataService mappingMetaDataService;

    @Mock
    ExcelFlatMappingDataReader excelFlatMappingDataReader;

    @InjectMocks
    MappingInformationService mappingInformationService;

    @Test
    public void findMappingInformationTest() throws BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException {
        Mockito.when(mappingMetaDataService.getMappingDetails(ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(getMappingDetails());
        MappingInformation mappingInformation = mappingInformationService.findMappingInformation("Instrument", "Ontology", "JSON", "token");
        assertEquals("DateTime", mappingInformation.getFieldMappingInformation().get(0).getTargetFieldMappingInformation().getSourceDateFormatter());
        assertEquals(Integer.valueOf(1), mappingInformation.getFieldMappingInformation().get(0).getSourceFieldMappingInformation().get().getOrderNo());
    }

    @Test
    public void uploadMappingsTest() throws IOException, ForbiddenException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, EnumMappingDataFoundException, OntologyAttributeNotFoundException, EislTokendException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException {
        Mockito.when(excelFlatMappingDataReader.readFlatMappingData(ArgumentMatchers.any())).thenReturn(getFlatMapping());
        Mockito.doNothing().when(mappingMetaDataService).saveFlatMappingData(ArgumentMatchers.any(), ArgumentMatchers.anyString());
        File file =
                new File(Objects.requireNonNull(getClass().getClassLoader().getResource("MappingServiceExample.xlsx")).getFile());

        FileInputStream inputStream = new FileInputStream(file);
        MockMultipartFile mockMultipartFile =
                new MockMultipartFile("file", "NameOfTheFile", "multipart/form-data", inputStream);
        mappingInformationService.uploadMappings(mockMultipartFile, "token");
    }


    private FlatMappingData getFlatMapping() {
        FlatMappingData flatMappingData = new FlatMappingData();
        flatMappingData.setMappingDefinitions(getMappingDefinition());
        flatMappingData.setEnumMappingDefinitions(getEnumMappingDefinition());
        return flatMappingData;
    }

    private List<EnumMappingDefinition> getEnumMappingDefinition() {
        List<EnumMappingDefinition> enumMappingDefinitions = new ArrayList<>();
        EnumMappingDefinition enumMappingDefinition = new EnumMappingDefinition();
        enumMappingDefinition.setEntity("Instrument");
        enumMappingDefinition.setSourceFormat("Ontology");
        enumMappingDefinition.setTargetFormat("JSON");
        enumMappingDefinition.setSourceValue("Dollar");
        enumMappingDefinition.setTargetValue("$");
        enumMappingDefinitions.add(enumMappingDefinition);
        return enumMappingDefinitions;
    }

    private List<MappingDefinition> getMappingDefinition() {
        List<MappingDefinition> mappingDefinitions = new ArrayList<>();
        MappingDefinition mappingDefinition = new MappingDefinition();
        mappingDefinition.setSourceSystem("Ontology");
        mappingDefinition.setTargetSystem("JSON");
        mappingDefinition.setEntity("Instrument");
        mappingDefinition.setSourceField("Product-Identifire");
        mappingDefinition.setTargetField("WS-OUT_REC.OUT-PROI");
        mappingDefinitions.add(mappingDefinition);
        return mappingDefinitions;
    }

    private MappingInformation getMappingDetails() {
        MappingInformation mappingInformation = new MappingInformation();
        mappingInformation.setSourceSystem("Ontology");
        mappingInformation.setTargetSystem("JSON");
        mappingInformation.setEntity("Instrument");
        mappingInformation.setFieldMappingInformation(getFieldMappingInformation());
        return mappingInformation;
    }

    private List<FieldMappingInformation> getFieldMappingInformation() {
        List<FieldMappingInformation> fieldMappingInformations = new ArrayList<>();
        FieldMappingInformation fieldMappingInformation = new FieldMappingInformation();
        fieldMappingInformation.setSourceFieldMappingInformation(getSourceFiledInfo());
        fieldMappingInformation.setTargetFieldMappingInformation(gettargerFieldinfo());
        fieldMappingInformations.add(fieldMappingInformation);
        return fieldMappingInformations;
    }

    private FieldMappingInformation.TargetFieldMappingInformation gettargerFieldinfo() {
        FieldMappingInformation.TargetFieldMappingInformation fieldMappingInformation = new FieldMappingInformation.TargetFieldMappingInformation();
        fieldMappingInformation.setOrderNo(1);
        fieldMappingInformation.setMaxSequenceNo(2);
        fieldMappingInformation.setName("WS-OUT_REC.OUT-PROI");
        fieldMappingInformation.setSourceDateFormatter("DateTime");
        fieldMappingInformation.setSize(OptionalInt.of(10));
        return fieldMappingInformation;
    }

    private Optional<FieldMappingInformation.SourceFieldMappingInformation> getSourceFiledInfo() {

        FieldMappingInformation.SourceFieldMappingInformation sourceFieldMappingInformation = new FieldMappingInformation.SourceFieldMappingInformation();
        sourceFieldMappingInformation.setName("Product-Identifire");
        sourceFieldMappingInformation.setOrderNo(1);
        sourceFieldMappingInformation.setSequenceNo(2);
        return Optional.of(sourceFieldMappingInformation);
    }
}
