package com.ubs.wmap.eisl.mappingservice.api.transformation;

import static org.assertj.core.api.Assertions.assertThat;

import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo;
import com.ubs.wmap.eisl.mappingservice.api.mapping.FieldTypeInfo.FieldType;
import java.math.BigDecimal;
import org.junit.Test;

public class FieldTransformerServiceTest {
  private FieldTransformerService fieldTransformerService = new FieldTransformerService();

  @Test
  public void convertSameType() {
    // arrange
    FieldTypeInfo sourceTypeInfo = FieldTypeInfo.builder().type(FieldType.STRING).build();
    Object source = new Object();

    // act
    Object result = fieldTransformerService.convertType(sourceTypeInfo, sourceTypeInfo, source);

    // assert
    assertThat(result).isSameAs(source);
  }

  @Test
  public void convertToString() {
    // arrange
    FieldTypeInfo sourceTypeInfo = FieldTypeInfo.builder().type(FieldType.NUMBER).build();
    FieldTypeInfo targetTypeInfo = FieldTypeInfo.builder().type(FieldType.STRING).build();

    // act
    Object result =
        fieldTransformerService.convertType(sourceTypeInfo, targetTypeInfo, new BigDecimal("34.4"));

    // assert
    assertThat(result).isEqualTo("34.4");
  }

  @Test
  public void convertToNumber() {
    // arrange
    FieldTypeInfo sourceTypeInfo = FieldTypeInfo.builder().type(FieldType.STRING).build();
    FieldTypeInfo targetTypeInfo = FieldTypeInfo.builder().type(FieldType.NUMBER).build();

    // act
    Object result = fieldTransformerService.convertType(sourceTypeInfo, targetTypeInfo, "34.4");

    // assert
    assertThat(result).isEqualTo(new BigDecimal("34.4"));
  }

  @Test
  public void validateNull() {
    // arrange
    FieldTypeInfo sourceTypeInfo = null;
    FieldTypeInfo targetTypeInfo = null;

    // act
    Object result = fieldTransformerService.convertType(sourceTypeInfo, targetTypeInfo, "34.4");

    // assert
    assertThat(result).isEqualTo(null);
  }

  @Test
  public void returnDefaultValueIfTargetTypeInfoDosentMatch() {
    // arrange
    FieldTypeInfo sourceTypeInfo = FieldTypeInfo.builder().type(FieldType.STRING).build();
    FieldTypeInfo targetTypeInfo = FieldTypeInfo.builder().type(FieldType.BOOLEAN).build();

    // act
    Object result = fieldTransformerService.convertType(sourceTypeInfo, targetTypeInfo, "true");

    // assert
    assertThat(result).isEqualTo("true");
  }
}
