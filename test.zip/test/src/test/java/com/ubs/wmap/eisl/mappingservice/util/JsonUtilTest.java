package com.ubs.wmap.eisl.mappingservice.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ubs.wmap.eisl.mappingservice.TransformationServiceTest;
import java.io.IOException;
import java.io.InputStream;
import org.junit.Test;

public class JsonUtilTest {
  private InputStream instrumentInputStream =
      TransformationServiceTest.class.getResourceAsStream("/instrumentPayload.json");

  private ObjectMapper objectMapper = new ObjectMapper();
  private JsonNode sourceRootNode = objectMapper.readValue(instrumentInputStream, JsonNode.class);

  public JsonUtilTest() throws IOException {
    // for sourceRootNode
  }

  @Test
  public void getNode() {
    // arrange
    // act
    JsonNode result = JsonUtil.getNode(sourceRootNode, "Instrument.effectiveDate");

    // assert
    assertThat(result.textValue()).isEqualTo("6/13/18 17:00");
  }

  @Test
  public void getNodeDoesntExist() {
    // arrange
    // act
    JsonNode result = JsonUtil.getNode(sourceRootNode, "Instrument.foo");

    // assert
    assertThat(result.isMissingNode()).isTrue();
  }

  @Test
  public void setAt() {
    // arrange
    // act
    ObjectNode result =
        JsonUtil.setAt(
            JsonNodeFactory.instance.objectNode(),
            "WS-OUT-REC.OUT-PROI",
            JsonNodeFactory.instance.textNode("foo"));

    // assert
    assertThat(result.at("/WS-OUT-REC/OUT-PROI").textValue()).isEqualTo("foo");
  }

  @Test
  public void setAtMultiple() {
    // arrange
    // act
    ObjectNode result =
        JsonUtil.setAt(
            JsonNodeFactory.instance.objectNode(),
            "WS-OUT-REC.OUT-PX-CRTE-M.OUT-DATE",
            JsonNodeFactory.instance.textNode("foo"));

    // assert
    assertThat(result.at("/WS-OUT-REC/OUT-PX-CRTE-M/OUT-DATE").textValue()).isEqualTo("foo");
  }
}
