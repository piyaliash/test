package com.ubs.wmap.eisl.mappingservice;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.mappingservice.api.transformation.TransformationRequest;
import com.ubs.wmap.eisl.mappingservice.api.transformation.TransformationResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureJsonTesters
@ActiveProfiles("test")
public class TransformationServiceTest {

  @LocalServerPort private int port;

  @Autowired private TokenService tokenService;

  @Autowired private ObjectMapper objectMapper;

  @Autowired private JacksonTester<TransformationResponse> json;

  private InputStream instrumentInputStream =
      TransformationServiceTest.class.getResourceAsStream("/instrumentPayload.json");

  private TestRestTemplate restTemplate = new TestRestTemplate();

  @Test
  public void transformEndToEnd() throws IOException {
    // arrange
    String uri = "http://localhost:" + port + "/eisl/mapping/v1/";
    Map<String, String> uriVariables =
        ImmutableMap.of("token", tokenService.createEILSToken("test", "test", "publish"));

    // act - upload mapping
    HttpEntity<MultiValueMap<String, Object>> requestEntity =
        createUploadFileRequestEntity("TransformationServiceExample.xlsx");
    ResponseEntity<String> mappingResponse =
        restTemplate.postForEntity(
            uri + "mapping?token={token}", requestEntity, String.class, uriVariables);

    // assert - upload mapping
    //assertThat(mappingResponse.getStatusCode().value()).isBetween(200, 299);

    // act - transform
    TransformationRequest request =
        TransformationRequest.builder()
            .entityName("Instrument")
            .sourceFormatName("Ontology")
            .destinationFormatName("FPMD5502")
            .source(objectMapper.readValue(instrumentInputStream, JsonNode.class))
            .build();
    ResponseEntity<TransformationResponse> transformationResponse =
        restTemplate.postForEntity(
            uri + "transform?token={token}", request, TransformationResponse.class, uriVariables);

    // assert - transformation
//    assertThat(transformationResponse.getStatusCode().value()).isBetween(200, 299);
//    assertThat(json.write(transformationResponse.getBody())).isEqualToJson("temp_exprsected.json");
  }

  private HttpEntity<MultiValueMap<String, Object>> createUploadFileRequestEntity(
      String mappingFile) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.MULTIPART_FORM_DATA);
    MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
    body.add("file", new ClassPathResource(mappingFile));
    return new HttpEntity<>(body, headers);
  }
}
