package com.ubs.wmap.eisl.mappingservice.service;

import com.ubs.wmap.eisl.mappingservice.api.mapping.*;
import com.ubs.wmap.eisl.mappingservice.api.transformation.FieldTransformerService;
import com.ubs.wmap.eisl.mappingservice.dto.AttributeResponseSO;
import com.ubs.wmap.eisl.mappingservice.dto.EnumDetailsResponseSO;
import com.ubs.wmap.eisl.mappingservice.dto.EnumResponseSO;
import com.ubs.wmap.eisl.mappingservice.excel.MappingKey;
import com.ubs.wmap.eisl.mappingservice.model.EnumMappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingFormat;
import com.ubs.wmap.eisl.mappingservice.service.impl.MappingMetaDataTransformer;
import org.junit.Assert;
import org.junit.Test;

import java.util.*;

public class MappingMetaDataTransformerTest {

    private MappingMetaDataTransformer mappingMetaDataTransformerTest = new MappingMetaDataTransformer();


    @Test
    public void testtransformFlatMappingDataToHierarchicalData() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();
        MappingDetails mappingDetails2 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);

        mappingDetails2.setMappingId(382L);
        mappingDetails2.setOrderNumber(6);
        mappingDetails2.setUbsAttributeId(2002L);
        mappingDetails2.setOntologyAttributeId(1002L);
        mappingDetails2.setFormatId(21L);
        mappingDetails2.setSequence(2);
        mappingDetails2.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails2);

        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2001L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("String");
        attributeResponseSOTarget.setTargetSize(10);

        attributes.put("2001-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOTarget2 = new AttributeResponseSO();
        attributeResponseSOTarget2.setAttributeId(2002L);
        attributeResponseSOTarget2.setAttributeName("WS-OUT-REC.OUT-PW-SEC-NUM");
        attributeResponseSOTarget2.setDataType("String");
        attributeResponseSOTarget2.setTargetSize(10);

        attributes.put("2002-UBS",attributeResponseSOTarget2);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1001L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("String");
        attributeResponseSOOntology.setTargetSize(10);

        attributes.put("1001-ONTOLOGY",attributeResponseSOOntology);

        AttributeResponseSO attributeResponseSOOntology2 = new AttributeResponseSO();
        attributeResponseSOOntology2.setAttributeId(1002L);
        attributeResponseSOOntology2.setAttributeName("productIdentifier");
        attributeResponseSOOntology2.setDataType("String");
        attributeResponseSOOntology2.setTargetSize(10);

        attributes.put("1002-ONTOLOGY",attributeResponseSOOntology2);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "Ontology", "FPMD5502");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();
        List<MappingDetails> mappingDataListOrder= new ArrayList<>();

        MappingDetails mappingDetailsOrder1 = new MappingDetails();
        MappingDetails mappingDetailsOrder2 = new MappingDetails();

        MappingFormat mappingFormatOrder = new MappingFormat();
        mappingFormatOrder.setMappingFormatReferenceId(120L);
        mappingFormatOrder.setFormatType("StringFormatter");
        mappingFormatOrder.setFormatValue("S");

        mappingDetailsOrder1.setMappingId(381L);
        mappingDetailsOrder1.setOrderNumber(6);
        mappingDetailsOrder1.setUbsAttributeId(2001L);
        mappingDetailsOrder1.setOntologyAttributeId(1001L);
        mappingDetailsOrder1.setFormatId(21L);
        mappingDetailsOrder1.setSequence(1);
        mappingDetailsOrder1.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder1);

        mappingDetailsOrder2.setMappingId(382L);
        mappingDetailsOrder2.setOrderNumber(6);
        mappingDetailsOrder2.setUbsAttributeId(2002L);
        mappingDetailsOrder2.setOntologyAttributeId(1002L);
        mappingDetailsOrder2.setFormatId(21L);
        mappingDetailsOrder2.setSequence(2);
        mappingDetailsOrder2.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder2);

        orderListMap.put(6,mappingDataListOrder);

        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert

        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PROI")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.newSGSSecurityIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(1)
                                                .size(10)
                                                .build()))
                        .build();

        FieldMappingInformation fieldMapping2 =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PW-SEC-NUM")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.productIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(2)
                                                .size(10)
                                                .build()))
                        .build();

        List<FieldMappingInformation> fieldMappingInformationArrayList = new ArrayList<>();
        fieldMappingInformationArrayList.add(fieldMapping);
        fieldMappingInformationArrayList.add(fieldMapping2);

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("Ontology")
                        .fieldMappingInformation(Collections.synchronizedList(fieldMappingInformationArrayList))
                        .build();

        Object targetresult=mappingInfo;

        Assert.assertEquals("Hierarchial Transformation for Soure and Target Attribute are present",result,targetresult);;
    }

    @Test
    public void testtransformFlatMappingDataToHierarchicalDataForBooleanAndEnum() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();
        MappingDetails mappingDetails2 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);

        mappingDetails2.setMappingId(382L);
        mappingDetails2.setOrderNumber(7);
        mappingDetails2.setUbsAttributeId(2002L);
        mappingDetails2.setOntologyAttributeId(1002L);
        mappingDetails2.setFormatId(21L);
        mappingDetails2.setSequence(1);
        mappingDetails2.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails2);

        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2001L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("Boolean");
        attributeResponseSOTarget.setTargetSize(1);
        attributeResponseSOTarget.setDefaultValue("1/0");

        attributes.put("2001-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOTarget2 = new AttributeResponseSO();
        attributeResponseSOTarget2.setAttributeId(2002L);
        attributeResponseSOTarget2.setAttributeName("WS-OUT-REC.OUT-PW-SEC-NUM");
        attributeResponseSOTarget2.setDataType("Enum");
        attributeResponseSOTarget2.setTargetSize(10);
        EnumResponseSO enumResponseSO = new EnumResponseSO();
        enumResponseSO.setEnumId(60L);
        enumResponseSO.setEnumName("currency");
        List<EnumDetailsResponseSO> enumDetailsResponseSOList=new ArrayList<>();
        EnumDetailsResponseSO enumDetailsResponseSO = new EnumDetailsResponseSO();
        enumDetailsResponseSO.setEnumDetailsId(2L);
        enumDetailsResponseSO.setEnumKey("usa");
        enumDetailsResponseSO.setEnumKeyValue("USD");
        enumDetailsResponseSOList.add(enumDetailsResponseSO);
        enumResponseSO.setEnumDetailsResponseSOS((ArrayList<EnumDetailsResponseSO>) enumDetailsResponseSOList);
        attributeResponseSOTarget2.setEnumResponseSO(enumResponseSO);

        attributes.put("2002-UBS",attributeResponseSOTarget2);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1001L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("Boolean");
        attributeResponseSOOntology.setTargetSize(1);
        attributeResponseSOOntology.setDefaultValue("true/false");

        attributes.put("1001-ONTOLOGY",attributeResponseSOOntology);

        AttributeResponseSO attributeResponseSOOntology2 = new AttributeResponseSO();
        attributeResponseSOOntology2.setAttributeId(1002L);
        attributeResponseSOOntology2.setAttributeName("productIdentifier");
        attributeResponseSOOntology2.setDataType("Enum");
        attributeResponseSOOntology2.setTargetSize(10);
        EnumResponseSO enumResponseSOOntology = new EnumResponseSO();
        enumResponseSOOntology.setEnumId(61L);
        enumResponseSOOntology.setEnumName("currency");
        List<EnumDetailsResponseSO> enumDetailsResponseSOOntologyList=new ArrayList<>();
        EnumDetailsResponseSO enumDetailsResponseSOOntology = new EnumDetailsResponseSO();
        enumDetailsResponseSOOntology.setEnumDetailsId(2L);
        enumDetailsResponseSOOntology.setEnumKey("usa");
        enumDetailsResponseSOOntology.setEnumKeyValue("$");
        enumDetailsResponseSOOntologyList.add(enumDetailsResponseSOOntology);
        enumResponseSOOntology.setEnumDetailsResponseSOS((ArrayList<EnumDetailsResponseSO>) enumDetailsResponseSOOntologyList);
        attributeResponseSOOntology2.setEnumResponseSO(enumResponseSOOntology);


        attributes.put("1002-ONTOLOGY",attributeResponseSOOntology2);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "Ontology", "FPMD5502");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();
        List<MappingDetails> mappingDataListOrder= new ArrayList<>();

        MappingDetails mappingDetailsOrder1 = new MappingDetails();
        MappingDetails mappingDetailsOrder2 = new MappingDetails();

        MappingFormat mappingFormatOrder = new MappingFormat();
        mappingFormatOrder.setMappingFormatReferenceId(120L);
        mappingFormatOrder.setFormatType("StringFormatter");
        mappingFormatOrder.setFormatValue("S");

        mappingDetailsOrder1.setMappingId(381L);
        mappingDetailsOrder1.setOrderNumber(9);
        mappingDetailsOrder1.setUbsAttributeId(2003L);
        mappingDetailsOrder1.setOntologyAttributeId(1003L);
        mappingDetailsOrder1.setFormatId(21L);
        mappingDetailsOrder1.setSequence(1);
        mappingDetailsOrder1.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder1);

        mappingDetailsOrder2.setMappingId(382L);
        mappingDetailsOrder2.setOrderNumber(9);
        mappingDetailsOrder2.setUbsAttributeId(2004L);
        mappingDetailsOrder2.setOntologyAttributeId(1004L);
        mappingDetailsOrder2.setFormatId(21L);
        mappingDetailsOrder2.setSequence(1);
        mappingDetailsOrder2.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder2);

        orderListMap.put(9,mappingDataListOrder);

        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert

        List<BooleanValues> booleanDetails=new ArrayList<>();
        BooleanValues booleanValues = new BooleanValues();
        booleanValues.setSourceBooleanValue("true");
        booleanValues.setTargetBooleanValue("1");
        booleanDetails.add(booleanValues);
        BooleanValues booleanValues1 = new BooleanValues();
        booleanValues1.setSourceBooleanValue("false");
        booleanValues1.setTargetBooleanValue("0");
        booleanDetails.add(booleanValues1);

        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PROI")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.BOOLEAN).typeName(Optional.of("Boolean")).build())
                                        .maxSequenceNo(0)
                                        .size(OptionalInt.of(1))
                                        .format(Optional.of("S"))
                                        .booleanDetails(booleanDetails)
                                        .sourceDateFormatter("true/false")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.newSGSSecurityIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.BOOLEAN).typeName(Optional.of("Boolean")).build())
                                                .format(Optional.of("true/false"))
                                                .orderNo(6)
                                                .sequenceNo(1)
                                                .size(1)
                                                .build()))
                        .build();

        List<EnumDetails> enumDetailsList = new ArrayList<>();

        EnumDetails enumDetails = new EnumDetails();
        enumDetails.setTargetEnumValue("USD");
        enumDetails.setSourceEnumValue("$");
        enumDetailsList.add(enumDetails);

        FieldMappingInformation fieldMapping2 =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PW-SEC-NUM")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.ENUM).typeName(Optional.of("Enum")).build())
                                        .maxSequenceNo(0)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .enumDetails(enumDetailsList)
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.productIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.ENUM).typeName(Optional.of("Enum")).build())
                                                .format(Optional.empty())
                                                .orderNo(7)
                                                .sequenceNo(1)
                                                .size(10)
                                                .build()))
                        .build();

        List<FieldMappingInformation> fieldMappingInformationArrayList = new ArrayList<>();
        fieldMappingInformationArrayList.add(fieldMapping);
        fieldMappingInformationArrayList.add(fieldMapping2);

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("Ontology")
                        .fieldMappingInformation(Collections.synchronizedList(fieldMappingInformationArrayList))
                        .build();

        Object targetresult=mappingInfo;

        Assert.assertEquals("Hierarchial Transformation for Boolean and Enum Source and Target Attribute are present",result,targetresult);;
    }

    @Test
    public void testtransformFlatMappingDataToHierarchicalDataForDateAndNumber() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();
        MappingDetails mappingDetails2 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);

        mappingDetails2.setMappingId(382L);
        mappingDetails2.setOrderNumber(6);
        mappingDetails2.setUbsAttributeId(2002L);
        mappingDetails2.setOntologyAttributeId(1002L);
        mappingDetails2.setFormatId(21L);
        mappingDetails2.setSequence(2);
        mappingDetails2.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails2);

        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2001L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("Number");
        attributeResponseSOTarget.setTargetSize(10);

        attributes.put("2001-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOTarget2 = new AttributeResponseSO();
        attributeResponseSOTarget2.setAttributeId(2002L);
        attributeResponseSOTarget2.setAttributeName("WS-OUT-REC.OUT-PW-SEC-NUM");
        attributeResponseSOTarget2.setDataType("DateTime");
        attributeResponseSOTarget2.setTargetSize(10);

        attributes.put("2002-UBS",attributeResponseSOTarget2);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1001L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("Number");
        attributeResponseSOOntology.setTargetSize(10);

        attributes.put("1001-ONTOLOGY",attributeResponseSOOntology);

        AttributeResponseSO attributeResponseSOOntology2 = new AttributeResponseSO();
        attributeResponseSOOntology2.setAttributeId(1002L);
        attributeResponseSOOntology2.setAttributeName("productIdentifier");
        attributeResponseSOOntology2.setDataType("DateTime");
        attributeResponseSOOntology2.setTargetSize(10);

        attributes.put("1002-ONTOLOGY",attributeResponseSOOntology2);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "Ontology", "FPMD5502");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();
        List<MappingDetails> mappingDataListOrder= new ArrayList<>();

        MappingDetails mappingDetailsOrder1 = new MappingDetails();
        MappingDetails mappingDetailsOrder2 = new MappingDetails();

        MappingFormat mappingFormatOrder = new MappingFormat();
        mappingFormatOrder.setMappingFormatReferenceId(120L);
        mappingFormatOrder.setFormatType("StringFormatter");
        mappingFormatOrder.setFormatValue("S");

        mappingDetailsOrder1.setMappingId(381L);
        mappingDetailsOrder1.setOrderNumber(6);
        mappingDetailsOrder1.setUbsAttributeId(2001L);
        mappingDetailsOrder1.setOntologyAttributeId(1001L);
        mappingDetailsOrder1.setFormatId(21L);
        mappingDetailsOrder1.setSequence(1);
        mappingDetailsOrder1.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder1);

        mappingDetailsOrder2.setMappingId(382L);
        mappingDetailsOrder2.setOrderNumber(6);
        mappingDetailsOrder2.setUbsAttributeId(2002L);
        mappingDetailsOrder2.setOntologyAttributeId(1002L);
        mappingDetailsOrder2.setFormatId(21L);
        mappingDetailsOrder2.setSequence(2);
        mappingDetailsOrder2.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder2);

        orderListMap.put(6,mappingDataListOrder);

        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert
        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PROI")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.NUMBER).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.newSGSSecurityIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.NUMBER).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(1)
                                                .size(10)
                                                .build()))
                        .build();

        FieldMappingInformation fieldMapping2 =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PW-SEC-NUM")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.DATETIME).typeName(Optional.of("S")).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.productIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.DATETIME).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(2)
                                                .size(10)
                                                .build()))
                        .build();

        List<FieldMappingInformation> fieldMappingInformationArrayList = new ArrayList<>();
        fieldMappingInformationArrayList.add(fieldMapping);
        fieldMappingInformationArrayList.add(fieldMapping2);

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("Ontology")
                        .fieldMappingInformation(Collections.synchronizedList(fieldMappingInformationArrayList))
                        .build();

        Object targetresult=mappingInfo;

        Assert.assertEquals("Hierarchial Transformation for Soure and Target Attribute are present",result,targetresult);;
    }

    @Test
    public void testtransformFlatMappingDataToHierarchicalDataForObject() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();
        MappingDetails mappingDetails2 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);

        mappingDetails2.setMappingId(382L);
        mappingDetails2.setOrderNumber(6);
        mappingDetails2.setUbsAttributeId(2002L);
        mappingDetails2.setOntologyAttributeId(1002L);
        mappingDetails2.setFormatId(21L);
        mappingDetails2.setSequence(2);
        mappingDetails2.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails2);

        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2001L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("Object");
        attributeResponseSOTarget.setTargetSize(10);

        attributes.put("2001-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOTarget2 = new AttributeResponseSO();
        attributeResponseSOTarget2.setAttributeId(2002L);
        attributeResponseSOTarget2.setAttributeName("WS-OUT-REC.OUT-PW-SEC-NUM");
        attributeResponseSOTarget2.setDataType("DateTime");
        attributeResponseSOTarget2.setTargetSize(10);

        attributes.put("2002-UBS",attributeResponseSOTarget2);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1001L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("Object");
        attributeResponseSOOntology.setTargetSize(10);

        attributes.put("1001-ONTOLOGY",attributeResponseSOOntology);

        AttributeResponseSO attributeResponseSOOntology2 = new AttributeResponseSO();
        attributeResponseSOOntology2.setAttributeId(1002L);
        attributeResponseSOOntology2.setAttributeName("productIdentifier");
        attributeResponseSOOntology2.setDataType("DateTime");
        attributeResponseSOOntology2.setTargetSize(10);

        attributes.put("1002-ONTOLOGY",attributeResponseSOOntology2);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "Ontology", "FPMD5502");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();
        List<MappingDetails> mappingDataListOrder= new ArrayList<>();

        MappingDetails mappingDetailsOrder1 = new MappingDetails();
        MappingDetails mappingDetailsOrder2 = new MappingDetails();

        MappingFormat mappingFormatOrder = new MappingFormat();
        mappingFormatOrder.setMappingFormatReferenceId(120L);
        mappingFormatOrder.setFormatType("StringFormatter");
        mappingFormatOrder.setFormatValue("S");

        mappingDetailsOrder1.setMappingId(381L);
        mappingDetailsOrder1.setOrderNumber(6);
        mappingDetailsOrder1.setUbsAttributeId(2001L);
        mappingDetailsOrder1.setOntologyAttributeId(1001L);
        mappingDetailsOrder1.setFormatId(21L);
        mappingDetailsOrder1.setSequence(1);
        mappingDetailsOrder1.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder1);

        mappingDetailsOrder2.setMappingId(382L);
        mappingDetailsOrder2.setOrderNumber(6);
        mappingDetailsOrder2.setUbsAttributeId(2002L);
        mappingDetailsOrder2.setOntologyAttributeId(1002L);
        mappingDetailsOrder2.setFormatId(21L);
        mappingDetailsOrder2.setSequence(2);
        mappingDetailsOrder2.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder2);

        orderListMap.put(6,mappingDataListOrder);

        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert
        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PROI")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.OBJECT).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.newSGSSecurityIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.OBJECT).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(1)
                                                .size(10)
                                                .build()))
                        .build();

        FieldMappingInformation fieldMapping2 =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("WS-OUT-REC.OUT-PW-SEC-NUM")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.DATETIME).typeName(Optional.of("S")).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.productIdentifier")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.DATETIME).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(2)
                                                .size(10)
                                                .build()))
                        .build();

        List<FieldMappingInformation> fieldMappingInformationArrayList = new ArrayList<>();
        fieldMappingInformationArrayList.add(fieldMapping);
        fieldMappingInformationArrayList.add(fieldMapping2);

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("Ontology")
                        .fieldMappingInformation(Collections.synchronizedList(fieldMappingInformationArrayList))
                        .build();

        Object targetresult=mappingInfo;

        Assert.assertEquals("Hierarchial Transformation for Soure and Target Attribute are present",result,targetresult);;
    }

    @Test
    public void testtransformFlatMappingDataIfTargetandSourceDataNotPresent() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);


        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2003L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("Object");
        attributeResponseSOTarget.setTargetSize(10);

        attributes.put("2003-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1003L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("Object");
        attributeResponseSOOntology.setTargetSize(10);

        attributes.put("1003-ONTOLOGY",attributeResponseSOOntology);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "Ontology", "FPMD5502");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();


        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert
        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(null)
                        .sourceFieldMappingInformation(
                                Optional.empty())
                        .build();


        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("Ontology")
                        .fieldMappingInformation(Collections.singletonList(fieldMapping))
                        .build();


        Assert.assertEquals("Hierarchial Transformation for Soure and Target Attribute are present",result,mappingInfo);
    }

    @Test
    public void testtransformFlatMappingDataToHierarchicalDataForCopyBookToOntology() {
        // arrange
        List<MappingDetails> mappingDataList= new ArrayList<>();

        MappingDetails mappingDetails1 = new MappingDetails();
        MappingDetails mappingDetails2 = new MappingDetails();

        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setMappingFormatReferenceId(120L);
        mappingFormat.setFormatType("StringFormatter");
        mappingFormat.setFormatValue("S");

        mappingDetails1.setMappingId(381L);
        mappingDetails1.setOrderNumber(6);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setSequence(1);
        mappingDetails1.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails1);

        mappingDetails2.setMappingId(382L);
        mappingDetails2.setOrderNumber(6);
        mappingDetails2.setUbsAttributeId(2002L);
        mappingDetails2.setOntologyAttributeId(1002L);
        mappingDetails2.setFormatId(21L);
        mappingDetails2.setSequence(2);
        mappingDetails2.setMappingFormat(mappingFormat);

        mappingDataList.add(mappingDetails2);

        Map<String, AttributeResponseSO> attributes = new HashMap<>();

        AttributeResponseSO attributeResponseSOTarget = new AttributeResponseSO();
        attributeResponseSOTarget.setAttributeId(2001L);
        attributeResponseSOTarget.setAttributeName("WS-OUT-REC.OUT-PROI");
        attributeResponseSOTarget.setDataType("String");
        attributeResponseSOTarget.setTargetSize(10);

        attributes.put("2001-UBS",attributeResponseSOTarget);

        AttributeResponseSO attributeResponseSOTarget2 = new AttributeResponseSO();
        attributeResponseSOTarget2.setAttributeId(2002L);
        attributeResponseSOTarget2.setAttributeName("WS-OUT-REC.OUT-PW-SEC-NUM");
        attributeResponseSOTarget2.setDataType("String");
        attributeResponseSOTarget2.setTargetSize(10);

        attributes.put("2002-UBS",attributeResponseSOTarget2);

        AttributeResponseSO attributeResponseSOOntology = new AttributeResponseSO();
        attributeResponseSOOntology.setAttributeId(1001L);
        attributeResponseSOOntology.setAttributeName("newSGSSecurityIdentifier");
        attributeResponseSOOntology.setDataType("String");
        attributeResponseSOOntology.setTargetSize(10);

        attributes.put("1001-ONTOLOGY",attributeResponseSOOntology);

        AttributeResponseSO attributeResponseSOOntology2 = new AttributeResponseSO();
        attributeResponseSOOntology2.setAttributeId(1002L);
        attributeResponseSOOntology2.setAttributeName("productIdentifier");
        attributeResponseSOOntology2.setDataType("String");
        attributeResponseSOOntology2.setTargetSize(10);

        attributes.put("1002-ONTOLOGY",attributeResponseSOOntology2);

        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();

        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(8L);
        enumMappingDetails.setEnumOntologyId(2L);
        enumMappingDetails.setEnumUbsId(2L);
        enumMappingDetails.setFormatId(21L);

        enumMappingDetailsList.add(enumMappingDetails);

        MappingKey inputMappingKey =new MappingKey("Instrument", "FPMD5502", "Ontology");


        HashMap<Integer, List<MappingDetails>> orderListMap=new HashMap<>();
        List<MappingDetails> mappingDataListOrder= new ArrayList<>();

        MappingDetails mappingDetailsOrder1 = new MappingDetails();
        MappingDetails mappingDetailsOrder2 = new MappingDetails();

        MappingFormat mappingFormatOrder = new MappingFormat();
        mappingFormatOrder.setMappingFormatReferenceId(120L);
        mappingFormatOrder.setFormatType("StringFormatter");
        mappingFormatOrder.setFormatValue("S");

        mappingDetailsOrder1.setMappingId(381L);
        mappingDetailsOrder1.setOrderNumber(6);
        mappingDetailsOrder1.setUbsAttributeId(2001L);
        mappingDetailsOrder1.setOntologyAttributeId(1001L);
        mappingDetailsOrder1.setFormatId(21L);
        mappingDetailsOrder1.setSequence(1);
        mappingDetailsOrder1.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder1);

        mappingDetailsOrder2.setMappingId(382L);
        mappingDetailsOrder2.setOrderNumber(6);
        mappingDetailsOrder2.setUbsAttributeId(2002L);
        mappingDetailsOrder2.setOntologyAttributeId(1002L);
        mappingDetailsOrder2.setFormatId(21L);
        mappingDetailsOrder2.setSequence(2);
        mappingDetailsOrder2.setMappingFormat(mappingFormatOrder);

        mappingDataListOrder.add(mappingDetailsOrder2);

        orderListMap.put(6,mappingDataListOrder);

        // act
        Object result = mappingMetaDataTransformerTest.transformFlatMappingDataToHierarchicalData(mappingDataList,attributes,enumMappingDetailsList,inputMappingKey,orderListMap);

        // assert
        FieldMappingInformation fieldMapping =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("newSGSSecurityIdentifier")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.WS-OUT-REC.OUT-PROI")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(1)
                                                .size(10)
                                                .build()))
                        .build();

        FieldMappingInformation fieldMapping2 =
                FieldMappingInformation.builder()
                        .targetFieldMappingInformation(
                                FieldMappingInformation.TargetFieldMappingInformation.builder()
                                        .name("productIdentifier")
                                        .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                        .orderNo(6)
                                        .maxSequenceNo(2)
                                        .size(OptionalInt.of(10))
                                        .format(Optional.of("S"))
                                        .sourceDateFormatter("")
                                        .build())
                        .sourceFieldMappingInformation(
                                Optional.of(
                                        FieldMappingInformation.SourceFieldMappingInformation.builder()
                                                .name("Instrument.WS-OUT-REC.OUT-PW-SEC-NUM")
                                                .typeInfo(FieldTypeInfo.builder().type(FieldTypeInfo.FieldType.STRING).build())
                                                .format(Optional.empty())
                                                .orderNo(6)
                                                .sequenceNo(2)
                                                .size(10)
                                                .build()))
                        .build();

        List<FieldMappingInformation> fieldMappingInformationArrayList = new ArrayList<>();
        fieldMappingInformationArrayList.add(fieldMapping);
        fieldMappingInformationArrayList.add(fieldMapping2);

        MappingInformation mappingInfo =
                MappingInformation.builder()
                        .entity("Instrument")
                        .targetSystem("21")
                        .sourceSystem("FPMD5502")
                        .fieldMappingInformation(Collections.synchronizedList(fieldMappingInformationArrayList))
                        .build();

        Object targetresult=mappingInfo;

        Assert.assertEquals("Hierarchial Transformation for Source and Target Attribute are present for CopyBook to Ontology",result,targetresult);;
    }

}
