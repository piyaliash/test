package com.ubs.wmap.eisl.mappingservice.service.impl;

import com.ubs.wmap.eisl.mappingservice.api.mapping.MappingInformation;
import com.ubs.wmap.eisl.mappingservice.constant.MessageKeys;
import com.ubs.wmap.eisl.mappingservice.dto.*;
import com.ubs.wmap.eisl.mappingservice.excel.*;
import com.ubs.wmap.eisl.mappingservice.exception.*;
import com.ubs.wmap.eisl.mappingservice.model.EnumMappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingDetails;
import com.ubs.wmap.eisl.mappingservice.model.MappingFormat;
import com.ubs.wmap.eisl.mappingservice.repository.EnumMappingRepository;
import com.ubs.wmap.eisl.mappingservice.repository.MappingFormatRepository;
import com.ubs.wmap.eisl.mappingservice.repository.MappingRepository;
import com.ubs.wmap.eisl.mappingservice.util.MessageResourceUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.Assert.*;

@ComponentScan(basePackages = {"com.ubs.wmap.eisl.mappingservice"})
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MappingMetaDataServiceImplTest {

    @Mock
    MappingRepository mappingRepository;

    @Mock
    EnumMappingRepository enumMappingRepository;

    @Mock
    MappingFormatRepository mappingFormatRepository;

    @Mock
    MappingStaticServiceRest mappingStaticServiceRest;

    @Mock
    MessageResourceUtil messageResourceUtil;

    @Mock
    MappingMetaDataTransformer mappingMetaDataTransformer;

    @InjectMocks
    MappingMetaDataServiceImpl mappingMetaDataService;

    String formatUrl="http://localhost:9090/eisl/static-data/v1/format";
    String ontologyUrl="http://localhost:9090/eisl/static-data/v1/ontologyattributes";
    String ubsUrl="http://localhost:9090/eisl/static-data/v1/ubsattributes";
    String ontologyEnumId="http://localhost:9090/eisl/static-data/v1/ontologyenums/ids";
    String ubsEnumId="http://localhost:9090/eisl/static-data/v1/ubsenums/ids";
    @Before
    public void setUp() {
        ReflectionTestUtils.setField(mappingMetaDataService, "staticFormatDetailsEndPointUri", formatUrl);
        ReflectionTestUtils.setField(mappingMetaDataService, "staticOntologyAttributeEndPointUri", ontologyUrl);
        ReflectionTestUtils.setField(mappingMetaDataService, "staticUbsAttributeEndPointUri", ubsUrl);
        ReflectionTestUtils.setField(mappingMetaDataService, "staticOntologyEnumEndPointUri", ontologyEnumId);
        ReflectionTestUtils.setField(mappingMetaDataService, "staticUbsEnumEndPointUri", ubsEnumId);
    }

    @Test
    public void saveFlatMappingDataTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getFormat());
        Mockito.when(enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        Mockito.when(enumMappingRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(new EnumMappingDetails());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void saveFlatMappingDataEnumExceptionTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObjectEnumNull());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void saveFlatMappingDataUbsEnumExceptionTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObjectEnumNull());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test
    public void saveFlatMappingDataReverseTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {

        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getFormat());
        Mockito.when(enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        Mockito.when(enumMappingRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(new EnumMappingDetails());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingDataReverse(), "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void saveFlatMappingDataReverseEnumMappingDataNotFoundExceptionTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {

        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObjectEnumNull());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingDataReverse(), "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void saveFlatMappingDataReverseUbsEnumMappingDataNotFoundExceptionTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {

        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObjectEnumNull());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingDataReverse(), "token");
    }

    @Test(expected = MappingDataFoundException.class)
    public void saveFlatMappingDataMappingDataFoundExceptionTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getFormat());
        Mockito.when(enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        Mockito.when(enumMappingRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(new EnumMappingDetails());
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test
    public void saveFlatMappingDataTestmappingFormatMapNull() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue("Enum", "String")).thenReturn(getListMapppingNull());
        Mockito.when(mappingFormatRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(null);
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test
    public void saveFlatMappingDataTestmappingFormatMapNullTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue("Enum", "String")).thenReturn(getListMapppingNull());
        Mockito.when(mappingFormatRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(null);
        Mockito.when(enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        Mockito.when(enumMappingRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(new EnumMappingDetails());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingData(), "token");
    }

    @Test
    public void saveFlatMappingDataReverseEnumTest() throws EnumMappingDataFoundException, BadRequestException, EnumMappingDataNotFoundException, UbsAttributeNotFoundException, MappingServiceException, MappingFormatDataNotFoundException, OntologyAttributeNotFoundException, MappingDataFoundException, ForbiddenException, DataNotFoundException, EislTokendException, ServiceUnavailableException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getDomainObject());
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject1());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getListMappping());
        Mockito.when(mappingFormatRepository.findAllByFormatTypeAndFormatValue(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(getFormat());
        Mockito.when(enumMappingRepository.findByEnumUbsIdAndEnumOntologyIdAndFormatId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject1());
        Mockito.when(enumMappingRepository.saveAndFlush(ArgumentMatchers.any())).thenReturn(new EnumMappingDetails());
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(mappingDetailsList);
        mappingMetaDataService.saveFlatMappingData(getFlatMappingDataReverse(), "token");
    }

    @Test
    public void getMappingDetailsTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingFormatDataNotFoundException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException {

        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject());
        Mockito.when(mappingMetaDataTransformer.transformFlatMappingDataToHierarchicalData(ArgumentMatchers.anyList(),
                ArgumentMatchers.anyMap(),
                ArgumentMatchers.anyList(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getMappinginformationObject());
        Mockito.when(mappingRepository.findByFormatIdAndOrderNumber(ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt())).thenReturn(getMappingDetailsObject());
        MappingKey mappingKey = new MappingKey("Instrument", "Ontology", "JSON");
        MappingInformation mappingDetails = mappingMetaDataService.getMappingDetails(mappingKey, "token");
        assertNotNull("Mapping Details should be present",mappingDetails);
    }

    @Test(expected = MappingDataNotFoundException.class)
    public void getMappingDetailsNullTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingFormatDataNotFoundException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, MappingDataNotFoundException {

        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(null);
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject());
        Mockito.when(mappingMetaDataTransformer.transformFlatMappingDataToHierarchicalData(ArgumentMatchers.anyList(),
                ArgumentMatchers.anyMap(),
                ArgumentMatchers.anyList(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getMappinginformationObject());
        Mockito.when(mappingRepository.findByFormatIdAndOrderNumber(ArgumentMatchers.anyLong(), ArgumentMatchers.anyInt())).thenReturn(getMappingDetailsObject());
        MappingKey mappingKey = new MappingKey("Instrument", "Ontology", "JSON");
        MappingInformation mappingDetails = mappingMetaDataService.getMappingDetails(mappingKey, "token");
        assertNull(mappingDetails);
    }

    private MappingInformation getMappinginformationObject() {
        MappingInformation mappingInformation = new MappingInformation();
        mappingInformation.setEntity("Instrument");
        mappingInformation.setSourceSystem("Ontology");
        mappingInformation.setTargetSystem("JSON");
        return mappingInformation;
    }

    @Test
    public void getMappings() throws BadRequestException, OntologyAttributeNotFoundException, MappingKeyNotFoundException, MappingServiceException, ForbiddenException, UbsAttributeNotFoundException, EislTokendException, MappingDataNotFoundException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException, EnumMappingDataNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ontologyEnumId, "token", "1001,")).thenReturn(getOntologyEnumResponseObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ubsEnumId, "token", "2001,")).thenReturn(getUbsEnumResponseObject());
        List<MappingResponseSO> mappingResponse = mappingMetaDataService.getMappings(mappingRequestSO(), "token");
        assertNotNull("Mapping Response should not be null",mappingResponse);
        assertEquals("Ontology id should be 1001",Long.valueOf(1001),mappingResponse.get(0).getOntologyAttributeId());

    }

    @Test
    public void testMappingswithEnumdetails() throws BadRequestException, OntologyAttributeNotFoundException, MappingKeyNotFoundException, MappingServiceException, ForbiddenException, UbsAttributeNotFoundException, EislTokendException, MappingDataNotFoundException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException, EnumMappingDataNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ontologyEnumId, "token", "1001,")).thenReturn(getOntologyEnumResponseObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ubsEnumId, "token", "2001,")).thenReturn(getUbsEnumResponseObject());
        List<MappingResponseSO> mappingResponse = mappingMetaDataService.getMappings(mappingRequestSO(), "token");
        assertNotNull("Response should not be null",mappingResponse);
        assertEquals("Enumeration Mapping details present",Long.valueOf(1001), mappingResponse.get(0).getEnumMappingResponseSOS().get(0).getEnumOntologyId());

    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void testEnumMappingsDataNotFoundException() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, MappingKeyNotFoundException, MappingFormatDataNotFoundException, EnumMappingDataNotFoundException, MappingDataNotFoundException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject1());
        mappingMetaDataService.getMappings(mappingRequestSO(), "token");
    }


    @Test(expected = EnumMappingDataNotFoundException.class)
    public void testEnumMappingDataNotFoundExceptionWhenEnumMappingIsNull() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, MappingKeyNotFoundException, MappingFormatDataNotFoundException, EnumMappingDataNotFoundException, MappingDataNotFoundException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(null);
        mappingMetaDataService.getMappings(mappingRequestSO(), "token");

    }

    private MappingRequestSO mappingRequestSO() {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setFormatName("JSON");
        mappingRequestSO.setDomain("Instrument");
        mappingRequestSO.setOntologyAtrributeId(1001L);
        mappingRequestSO.setUbsAtrributeId(2001L);
        return mappingRequestSO;
    }

    private MappingRequestSO mappingRequestSOForInvalidFile() {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setFormatName("FPMD");
        mappingRequestSO.setDomain("Instrument");
        mappingRequestSO.setFileName("tetInvalidFile1");
        mappingRequestSO.setOntologyAtrributeId(1001L);
        mappingRequestSO.setUbsAtrributeId(2001L);
        return mappingRequestSO;
    }
    private MappingRequestSO mappingRequestSOForFile(){
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setFormatName("FPMD");
        mappingRequestSO.setDomain("Instrument");
        mappingRequestSO.setFileName("tetFile1");
        mappingRequestSO.setOntologyAtrributeId(1001L);
        mappingRequestSO.setUbsAtrributeId(2001L);
        return mappingRequestSO;
    }


    private List<EnumMappingDetails> getEnumMappingObject() {
        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();
        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumUbsId(2001L);
        enumMappingDetails.setEnumOntologyId(1001L);
        enumMappingDetails.setEnumMappingId(9L);
        enumMappingDetails.setFormatId(23L);
        enumMappingDetailsList.add(enumMappingDetails);
        return enumMappingDetailsList;
    }

    private List<EnumMappingDetails> getEnumMappingObject1() {
        List<EnumMappingDetails> enumMappingDetailsList = new ArrayList<>();
        EnumMappingDetails enumMappingDetails = new EnumMappingDetails();
        enumMappingDetails.setEnumMappingId(9L);
        enumMappingDetailsList.add(enumMappingDetails);
        return enumMappingDetailsList;
    }

    private MappingRequestSO getmapppingRequestSO() {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setFormatId(9L);
        mappingRequestSO.setFormatName("JSON");
        mappingRequestSO.setDomain("Instrument");
        mappingRequestSO.setToken("token");
        return mappingRequestSO;
    }

    private ResponseEntity<EnumDetailsListResponseSO> getUbsEnumResponseObject() {
        EnumDetailsListResponseSO ubsEnumDetailsListResponseSO = new EnumDetailsListResponseSO();
        ubsEnumDetailsListResponseSO.setEnumDetailsResponseSOS(getUbsEnumDetailsObject());
        return ResponseEntity.ok().body(ubsEnumDetailsListResponseSO);
    }

    private ResponseEntity<EnumDetailsListResponseSO> getOntologyEnumResponseObjectNull() {

        return ResponseEntity.ok().body(null);
    }

    private ResponseEntity<EnumDetailsListResponseSO> getOntologyEnumResponseObject() {
        EnumDetailsListResponseSO ontologyEnumListDetailsResponseSO = new EnumDetailsListResponseSO();
        ontologyEnumListDetailsResponseSO.setEnumDetailsResponseSOS(getOntologyEnumObject());
        return ResponseEntity.ok().body(ontologyEnumListDetailsResponseSO);
    }

    @Test
    public void getAllMappingFormats() throws MappingFormatDataNotFoundException {
        Mockito.when(mappingFormatRepository.findAll()).thenReturn(getFormat());
        List<MappingFormatResponseSO> mappingFormatResponseSOS = mappingMetaDataService.getAllMappingFormats();
        assertNotNull(mappingFormatResponseSOS);
        assertEquals("%/", mappingFormatResponseSOS.get(1).getFormatValue());
    }

    @Test(expected = MappingFormatDataNotFoundException.class)
    public void getAllMappingFormatsException() throws MappingFormatDataNotFoundException {
        Mockito.when(mappingFormatRepository.findAll()).thenReturn(null);
        mappingMetaDataService.getAllMappingFormats();
    }

    @Test
    public void getAllMappingFormatsNullTest() throws MappingFormatDataNotFoundException {
        Mockito.when(mappingFormatRepository.findAll()).thenReturn(getFormatNull());
        List<MappingFormatResponseSO> mappingFormatResponseSOS = mappingMetaDataService.getAllMappingFormats();
        assertNotNull(mappingFormatResponseSOS);

    }

    @Test(expected = MappingKeyNotFoundException.class)
    public void getMappingsTestMappingKeyException() throws MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException, OntologyAttributeNotFoundException, UbsAttributeNotFoundException, EnumMappingDataNotFoundException {

        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());

        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        mappingMetaDataService.getMappings(getmapppingRequestSOFormatNull(), "token");

    }

    private List<MappingFormat> getFormatNull() {
        List<MappingFormat> mappingFormatList = new ArrayList<>();
        mappingFormatList.add(null);
        return mappingFormatList;
    }

    private List<MappingFormat> getFormat() {
        List<MappingFormat> mappingFormatList = new ArrayList<>();
        mappingFormatList.add(getMappingFormat());
        mappingFormatList.add(getMappingFormat1());
        return mappingFormatList;
    }

    @Test
    public void saveMappingsFormat() {
        Mockito.when(mappingRepository.saveAll(ArgumentMatchers.anyIterable())).thenReturn(getMappingDetailsObject());
        Mockito.when(mappingRepository.findById(ArgumentMatchers.anyLong())).thenReturn(getMappingDetails());
        List<MappingResponseSO> mappingResponseSOList = mappingMetaDataService.saveMappings(getMappingUpdateRequestSO());
        assertNotNull(mappingResponseSOList);
        assertEquals(Long.valueOf(1), mappingResponseSOList.get(0).getMappingId());
        assertEquals("MM/DD/YYYY", mappingResponseSOList.get(0).getMappingFormatResponseSO().getFormatValue());
    }

    @Test
    public void saveMappingsformatReferenceIdNull() {
        Mockito.when(mappingRepository.saveAll(ArgumentMatchers.anyIterable())).thenReturn(getMappingDetailsObject());
        Mockito.when(mappingRepository.findById(ArgumentMatchers.anyLong())).thenReturn(getMappingDetails());
        List<MappingResponseSO> mappingResponseSOList = mappingMetaDataService.saveMappings(getMappingUpdateRequestSO1());
        assertNotNull(mappingResponseSOList);
        assertEquals(Long.valueOf(1), mappingResponseSOList.get(0).getMappingId());
        assertEquals("MM/DD/YYYY", mappingResponseSOList.get(0).getMappingFormatResponseSO().getFormatValue());
    }

    @Test
    public void saveMappingsMappingResponseSOTest() {
        Mockito.when(mappingRepository.saveAll(ArgumentMatchers.anyIterable())).thenReturn(getMappingDetailsObject());
        Mockito.when(mappingRepository.findById(ArgumentMatchers.anyLong())).thenReturn(getMappingDetails());
        List<MappingResponseSO> mappingResponseSOList = mappingMetaDataService.saveMappings(getMappingUpdateRequestSOCreateRequestNull());
        assertNotNull(mappingResponseSOList);
        assertEquals(Long.valueOf(1), mappingResponseSOList.get(0).getMappingId());
        assertEquals("MM/DD/YYYY", mappingResponseSOList.get(0).getMappingFormatResponseSO().getFormatValue());
    }

    @Test
    public void saveMappingsFormatNullTest() {
        Mockito.when(mappingRepository.saveAll(ArgumentMatchers.anyIterable())).thenReturn(getMappingDetailsObject());
        Mockito.when(mappingRepository.findById(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsFormatNull());
        List<MappingResponseSO> mappingResponseSOList = mappingMetaDataService.saveMappings(getMappingUpdateRequestSO());
        assertNotNull(mappingResponseSOList);
        assertNull(mappingResponseSOList.get(0).getMappingFormatResponseSO());
    }

    @Test
    public void updateMappingsTest() throws MappingDataNotFoundException {

        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(mappingRepository.saveAll(ArgumentMatchers.any())).thenReturn(getMappingDetailsObject());
        mappingMetaDataService.updateMappings(getMappingUpdateRequestSO());
    }

    @Test(expected = MappingDataNotFoundException.class)
    public void updateMappingsMappingDataNotFoundExceptionTest() throws MappingDataNotFoundException {
        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        Mockito.when(messageResourceUtil.getMessage(MessageKeys.MAPPING_NOT_FOUND_FORMAT_MSG.getValue())).thenReturn("mapping data not found");
        mappingMetaDataService.updateMappings(getMappingUpdateRequestSO());
    }


    @Test
    public void deleteMappingTest() throws MappingKeyNotFoundException, MappingDataNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        mappingMetaDataService.deleteMapping(mappingRequestSO(), "token");

    }

    @Test(expected = MappingKeyNotFoundException.class)
    public void deleteMappingMappingKeyExceptionTest() throws MappingKeyNotFoundException, MappingDataNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        mappingMetaDataService.deleteMapping(getmapppingRequestSOFormatNull(), "token");

    }

    @Test(expected = MappingFormatDataNotFoundException.class)
    public void deleteMappingMappingKeyNotFoundExceptionTest() throws MappingKeyNotFoundException, MappingDataNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getFormatObject1());
        mappingMetaDataService.deleteMapping(mappingRequestSO(), "token");

    }

    @Test(expected = MappingDataNotFoundException.class)
    public void deleteMappingMappingDataNotFoundExceptionTest() throws MappingKeyNotFoundException, MappingDataNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        mappingMetaDataService.deleteMapping(mappingRequestSO(), "token");

    }

    @Test
    public void deleteMappingByFormatNameAndOntologyAndUbsAttributeIdTest() throws MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        mappingMetaDataService.deleteMappingByFormatNameAndOntologyAndUbsAttributeId(mappingRequestSO(), "token");

    }

    @Test(expected = MappingKeyNotFoundException.class)
    public void deleteMappingByFormatNameAndOntologyAndUbsAttributeIdExceptionTest() throws MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.doNothing().when(mappingRepository).deleteInBatch(ArgumentMatchers.any());
        mappingMetaDataService.deleteMappingByFormatNameAndOntologyAndUbsAttributeId(getmapppingRequestSOFormatNull(), "token");

    }

    @Test(expected = MappingFormatDataNotFoundException.class)
    public void deleteMappingByFormatNameAndOntologyAndUbsAttributeIdMappingKeyNotFoundExceptionTest() throws MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getFormatObject1());
        mappingMetaDataService.deleteMappingByFormatNameAndOntologyAndUbsAttributeId(mappingRequestSO(), "token");

    }

    @Test(expected = MappingDataNotFoundException.class)
    public void deleteMappingByFormatNameAndOntologyAndUbsAttributeIMappingDataNotFoundExceptionTest() throws MappingDataNotFoundException, MappingKeyNotFoundException, BadRequestException, MappingFormatDataNotFoundException, MappingDataFoundException, ForbiddenException, MappingServiceException, ServiceUnavailableException, DataNotFoundException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getObject());
        Mockito.when(mappingRepository.findAllByFormatIdAndOntologyAttributeIdAndUbsAttributeId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong())).thenReturn(new ArrayList<>());
        mappingMetaDataService.deleteMappingByFormatNameAndOntologyAndUbsAttributeId(mappingRequestSO(), "token");

    }

    @Test(expected = MappingServiceException.class)
    public void getDomainDetails() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getDomainDetails("Instrument", "token");
    }

    @Test(expected = DataNotFoundException.class)
    public void getDomainExceptionTest() throws DataNotFoundException, EislTokendException, BadRequestException, ForbiddenException, ServiceUnavailableException, MappingServiceException {

        List<DomainDetailsResponseVO> domainDetailsResponseVOS = new ArrayList<>();
        domainDetailsResponseVOS.add(DomainDetailsResponseVO.builder()
                .domainId(Long.valueOf(101))
                .domainName("Instrument")
                .build());
        DomainDetailsResListSO domainDetailsResListSO = DomainDetailsResListSO.builder()
                .domainDetailsResponseVOList(domainDetailsResponseVOS)
                .build();
        ResponseEntity<DomainDetailsResListSO> domainDetailsResListSOResponseEntity = new ResponseEntity<>(domainDetailsResListSO, HttpStatus.NOT_FOUND);
        Mockito.when(mappingStaticServiceRest.getDomainDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(domainDetailsResListSOResponseEntity);
        mappingMetaDataService.getDomainDetails("Instrument", "token");

    }

    @Test(expected = MappingServiceException.class)
    public void getFormatDetails() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, MappingFormatDataNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getFormatDetails("Instrument", "", "token");
    }

    @Test(expected = OntologyAttributeNotFoundException.class)
    public void getOntologyAttributes() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObjectNull());
        mappingMetaDataService.getOntologyAttributes("Instrument", "", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getOntologyAttributesExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getOntologyAttributes("Instrument", "", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getUbsAttributes() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getUbsAttributes("Instrument", "", "token");
    }

    @Test(expected = UbsAttributeNotFoundException.class)
    public void getUbsAttributesException() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject1());
        mappingMetaDataService.getUbsAttributes("Instrument", "", "token");
    }

    @Test(expected = MappingFormatDataNotFoundException.class)
    public void getFormatDetailsById() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingFormatDataNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(getFormatObject1());
        mappingMetaDataService.getFormatDetailsById("Instrument", "", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getOntologyEnumDetailsByIds() throws BadRequestException, ForbiddenException, DataNotFoundException, EnumMappingDataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ontologyEnumId, "token", "1001")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getOntologyEnumDetailsByIds("1001", "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void getOntologyEnumDetailsByIdsExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, EnumMappingDataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        Mockito.when(mappingStaticServiceRest.getEnumByIds(ontologyEnumId, "token", "1001")).thenReturn(getOntologyEnumResponseObjectNull());
        mappingMetaDataService.getOntologyEnumDetailsByIds("1001", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getUbsEnumDetailsByIds() throws BadRequestException, ForbiddenException, DataNotFoundException, EnumMappingDataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ubsEnumId, "token", "2001")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getUbsEnumDetailsByIds("2001", "token");
    }

    @Test(expected = EnumMappingDataNotFoundException.class)
    public void getUbsEnumDetailsByIdsExceptionTest() throws BadRequestException, ForbiddenException, DataNotFoundException, EnumMappingDataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException {

        Mockito.when(mappingStaticServiceRest.getEnumByIds(ubsEnumId, "token", "2001")).thenReturn(getOntologyEnumResponseObjectNull());
        mappingMetaDataService.getUbsEnumDetailsByIds("2001", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getOntologyAttributeDetailsByIdstest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getOntologyAttributeDetailsByIds("Instrument", "", "token");
    }

    @Test(expected = MappingServiceException.class)
    public void getUbsAttributeDetailsByIdTest() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getUbsAttributeDetailsById("Instrument", "", "token");
    }

    @Test(expected = OntologyAttributeNotFoundException.class)
    public void getOntologyAttributeDetailsByIds() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, OntologyAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObjectNull());
        mappingMetaDataService.getOntologyAttributeDetailsByIds("Instrument", "", "token");

    }

    @Test(expected = MappingServiceException.class)
    public void getAllAttributes() throws BadRequestException, ForbiddenException, DataNotFoundException, UbsAttributeNotFoundException, ServiceUnavailableException, OntologyAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenThrow(MappingServiceException.class);
        mappingMetaDataService.getAllAttributes("Instrument", "", "token");
    }

    @Test(expected = OntologyAttributeNotFoundException.class)
    public void getAllAttributesOntologyException() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, OntologyAttributeNotFoundException, MappingServiceException, EislTokendException, UbsAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObjectNull());
        mappingMetaDataService.getAllAttributes("Instrument", "", "token");

    }

    @Test(expected = UbsAttributeNotFoundException.class)
    public void getUbsAttributeDetailsById() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getOntologyObjectNull());
        mappingMetaDataService.getUbsAttributeDetailsById("Instrument", "", "token");

    }

    @Test(expected = UbsAttributeNotFoundException.class)
    public void getAllAttributesUbsException() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException {
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getOntologyObjectNull());
        mappingMetaDataService.getAllAttributes("Instrument", "", "token");

    }

    @Test
    public void getMappingsWhenFileNameIsPresent() throws BadRequestException, OntologyAttributeNotFoundException, MappingKeyNotFoundException, MappingServiceException, ForbiddenException, UbsAttributeNotFoundException, EislTokendException, MappingDataNotFoundException, MappingFormatDataNotFoundException, DataNotFoundException, MappingDataFoundException, ServiceUnavailableException, EnumMappingDataNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObjectwithFileList());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        Mockito.when(enumMappingRepository.findByFormatId(ArgumentMatchers.anyLong())).thenReturn(getEnumMappingObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ontologyEnumId, "token", "1001,")).thenReturn(getOntologyEnumResponseObject());
        Mockito.when(mappingStaticServiceRest.getEnumByIds(ubsEnumId, "token", "2001,")).thenReturn(getUbsEnumResponseObject());
        Assert.assertEquals("Mapping Present for the respective copyBookFileName",false,mappingMetaDataService.getMappings(mappingRequestSOForFile(), "token").isEmpty());
    }

    @Test(expected = MappingFormatDataNotFoundException.class)
    public void getMappingsExcpetionWhenFileNameIsNotvalidForCopyBookFormat() throws BadRequestException, ForbiddenException, DataNotFoundException, ServiceUnavailableException, UbsAttributeNotFoundException, MappingServiceException, EislTokendException, OntologyAttributeNotFoundException, MappingKeyNotFoundException, MappingDataNotFoundException, MappingFormatDataNotFoundException, MappingDataFoundException, EnumMappingDataNotFoundException {
        Mockito.when(mappingStaticServiceRest.getFormatDetails(formatUrl, "token", "Instrument")).thenReturn(getObjectwithFileList());
        Mockito.when(mappingStaticServiceRest.getAttribute(ontologyUrl, "token", "Instrument")).thenReturn(getOntologyObject());
        Mockito.when(mappingStaticServiceRest.getAttribute(ubsUrl, "token", "Instrument")).thenReturn(getUbsObject());
        Mockito.when(mappingRepository.findAllByFormatId(ArgumentMatchers.anyLong())).thenReturn(getMappingDetailsObject());
        mappingMetaDataService.getMappings(mappingRequestSOForInvalidFile(), "token");

    }

    private MappingRequestSO getmapppingRequestSOFormatNull() {
        MappingRequestSO mappingRequestSO = new MappingRequestSO();
        mappingRequestSO.setFormatId(9L);
        mappingRequestSO.setDomain("Instrument");
        mappingRequestSO.setToken("token");
        return mappingRequestSO;
    }

    private ResponseEntity<FormatListResponseSO> getFormatObject1() {
        FormatListResponseSO formatListResponseSO = new FormatListResponseSO();
        return ResponseEntity.ok().body(formatListResponseSO);
    }

    private ResponseEntity<AttributeListResponseSO> getUbsObject1() {

        return ResponseEntity.noContent().build();
    }

    private ResponseEntity<AttributeListResponseSO> getUbsObject() {
        AttributeListResponseSO ubsAttributeListResponseSO = new AttributeListResponseSO();
        AttributeResponseSO ubsAttributeResponseSO = new AttributeResponseSO();
        ubsAttributeResponseSO.setAttributeName("WS-OUT_REC.OUT-PROI");
        ubsAttributeResponseSO.setAttributeId(2001L);
        ubsAttributeResponseSO.setDefaultValue(".");
        ubsAttributeResponseSO.setDataType("Enum");
        ubsAttributeResponseSO.setEnumResponseSO(getUbsEnumObject());
        List<AttributeResponseSO> ubsAttributeResponseSOS = new ArrayList<>();
        ubsAttributeResponseSOS.add(ubsAttributeResponseSO);
        ubsAttributeListResponseSO.setAttributeResponseSOList(ubsAttributeResponseSOS);
        return ResponseEntity.ok().body(ubsAttributeListResponseSO);
    }

    private ResponseEntity<AttributeListResponseSO> getUbsObjectEnumNull() {
        AttributeListResponseSO ubsAttributeListResponseSO = new AttributeListResponseSO();
        AttributeResponseSO ubsAttributeResponseSO = new AttributeResponseSO();
        ubsAttributeResponseSO.setAttributeName("WS-OUT_REC.OUT-PROI");
        ubsAttributeResponseSO.setAttributeId(2001L);
        ubsAttributeResponseSO.setDefaultValue(".");
        ubsAttributeResponseSO.setDataType("Enum");
        ubsAttributeResponseSO.setEnumResponseSO(getUbsEnumNullObject());
        List<AttributeResponseSO> ubsAttributeResponseSOS = new ArrayList<>();
        ubsAttributeResponseSOS.add(ubsAttributeResponseSO);
        ubsAttributeListResponseSO.setAttributeResponseSOList(ubsAttributeResponseSOS);
        return ResponseEntity.ok().body(ubsAttributeListResponseSO);
    }

    private EnumResponseSO getUbsEnumNullObject() {
        EnumResponseSO ubsEnumResponseSO = new EnumResponseSO();
        ubsEnumResponseSO.setDescription("desc-test");
        return ubsEnumResponseSO;
    }

    private EnumResponseSO getUbsEnumObject() {
        EnumResponseSO ubsEnumResponseSO = new EnumResponseSO();
        ubsEnumResponseSO.setEnumId(2001L);
        ubsEnumResponseSO.setDescription("desc-test");
        ubsEnumResponseSO.setEnumDetailsResponseSOS((ArrayList<EnumDetailsResponseSO>) getUbsEnumDetailsObject());
        return ubsEnumResponseSO;
    }

    private List<EnumDetailsResponseSO> getUbsEnumDetailsObject() {
        List<EnumDetailsResponseSO> ubsEnumDetailsResponseSOS = new ArrayList<>();
        EnumDetailsResponseSO ubsAttributeResponseSO = new EnumDetailsResponseSO();
        ubsAttributeResponseSO.setEnumKey("test-key");
        ubsAttributeResponseSO.setEnumKeyValue("test-key-value");
        ubsAttributeResponseSO.setEnumDetailsId(2001L);
        ubsEnumDetailsResponseSOS.add(ubsAttributeResponseSO);
        return ubsEnumDetailsResponseSOS;
    }

    private ResponseEntity<AttributeListResponseSO> getOntologyObjectNull() {

        return ResponseEntity.notFound().build();

    }

    private ResponseEntity<AttributeListResponseSO> getOntologyObject() {
        AttributeListResponseSO ontologyAttributeListResponseSO = new AttributeListResponseSO();
        AttributeResponseSO ontologyAttributeResponseSO = new AttributeResponseSO();
        ontologyAttributeResponseSO.setAttributeName("product-identifire");
        ontologyAttributeResponseSO.setDataType("Enum");
        ontologyAttributeResponseSO.setAttributeId(1001L);
        EnumResponseSO ontologyEnumResponseSO = new EnumResponseSO();
        ontologyEnumResponseSO.setEnumId(1001L);
        ontologyEnumResponseSO.setEnumName("Currency");
        ontologyEnumResponseSO.setEnumDetailsResponseSOS((ArrayList<EnumDetailsResponseSO>) getOntologyEnumObject());
        ontologyAttributeResponseSO.setEnumResponseSO(ontologyEnumResponseSO);
        List<AttributeResponseSO> ontologyAttributeResponseSOS = new ArrayList<>();
        ontologyAttributeResponseSOS.add(ontologyAttributeResponseSO);
        ontologyAttributeListResponseSO.setAttributeResponseSOList(ontologyAttributeResponseSOS);
        return ResponseEntity.ok().body(ontologyAttributeListResponseSO);

    }

    private ResponseEntity<AttributeListResponseSO> getOntologyObject1() {
        AttributeListResponseSO ontologyAttributeListResponseSO = new AttributeListResponseSO();
        AttributeResponseSO ontologyAttributeResponseSO = new AttributeResponseSO();
        ontologyAttributeResponseSO.setAttributeName("product-identifire");
        ontologyAttributeResponseSO.setDataType("Enum");
        ontologyAttributeResponseSO.setAttributeId(1001L);
        EnumResponseSO ontologyEnumResponseSO = new EnumResponseSO();
        ontologyEnumResponseSO.setEnumName("Currency");
        ontologyEnumResponseSO.setEnumDetailsResponseSOS((ArrayList<EnumDetailsResponseSO>) getOntologyEnumObject1());
        ontologyAttributeResponseSO.setEnumResponseSO(ontologyEnumResponseSO);
        List<AttributeResponseSO> ontologyAttributeResponseSOS = new ArrayList<>();
        ontologyAttributeResponseSOS.add(ontologyAttributeResponseSO);
        ontologyAttributeListResponseSO.setAttributeResponseSOList(ontologyAttributeResponseSOS);
        return ResponseEntity.ok().body(ontologyAttributeListResponseSO);

    }

    private ResponseEntity<AttributeListResponseSO> getOntologyObjectEnumNull() {
        AttributeListResponseSO ontologyAttributeListResponseSO = new AttributeListResponseSO();
        AttributeResponseSO ontologyAttributeResponseSO = new AttributeResponseSO();
        ontologyAttributeResponseSO.setAttributeName("product-identifire");
        ontologyAttributeResponseSO.setDataType("Enum");
        ontologyAttributeResponseSO.setAttributeId(1001L);
        EnumResponseSO ontologyEnumResponseSO = new EnumResponseSO();
        ontologyEnumResponseSO.setEnumName("Currency");
        ontologyAttributeResponseSO.setEnumResponseSO(ontologyEnumResponseSO);
        List<AttributeResponseSO> ontologyAttributeResponseSOS = new ArrayList<>();
        ontologyAttributeResponseSOS.add(ontologyAttributeResponseSO);
        ontologyAttributeListResponseSO.setAttributeResponseSOList(ontologyAttributeResponseSOS);
        return ResponseEntity.ok().body(ontologyAttributeListResponseSO);

    }

    private FlatMappingData getFlatMappingDataReverse() {
        FlatMappingData flatMappingData = new FlatMappingData();
        flatMappingData.setMappingDefinitions(getMappingDefinitionReverse());
        flatMappingData.setEnumMappingDefinitions(getEnumMappingDefinitionReverse());
        return flatMappingData;
    }

    private List<EnumMappingDefinition> getEnumMappingDefinitionReverse() {
        List<EnumMappingDefinition> enumMappingDefinitions = new ArrayList<>();
        EnumMappingDefinition enumMappingDefinition = new EnumMappingDefinition();
        enumMappingDefinition.setEntity("WS-OUT_REC.OUT-PROI");
        enumMappingDefinition.setSourceFormat("JSON");
        enumMappingDefinition.setTargetFormat("Ontology");
        enumMappingDefinition.setTargetValue("test-value");
        enumMappingDefinition.setSourceValue("test-key-value");
        enumMappingDefinitions.add(enumMappingDefinition);
        return enumMappingDefinitions;
    }

    private List<MappingDefinition> getMappingDefinitionReverse() {
        List<MappingDefinition> mappingDefinitions = new ArrayList<>();
        MappingDefinition mappingDefinition = new MappingDefinition();
        mappingDefinition.setEntity("Instrument");
        mappingDefinition.setSourceSystem("JSON");
        mappingDefinition.setTargetSystem("Ontology");
        mappingDefinition.setSourceField("WS-OUT_REC.OUT-PROI");
        mappingDefinition.setTargetField("product-identifire");
        mappingDefinitions.add(mappingDefinition);
        mappingDefinition.setFormatDefination(getFormatDefination());
        return mappingDefinitions;
    }

    private List<MappingFormat> getListMapppingNull() {
        return new ArrayList<>();
    }

    private List<MappingFormat> getListMappping() {
        List<MappingFormat> mappingFormatList = new ArrayList<>();
        mappingFormatList.add(getMappingFormat());
        return mappingFormatList;
    }


    private ResponseEntity<DomainDetailsResListSO> getDomainObject() {
        DomainDetailsResListSO domainDetailsResListSO = new DomainDetailsResListSO();
        DomainDetailsResponseVO domainDetailsResponseVO = new DomainDetailsResponseVO();
        domainDetailsResponseVO.setDomainId(1L);
        domainDetailsResponseVO.setDomainName("instrument");
        domainDetailsResponseVO.setSubDomainName("");
        List<DomainDetailsResponseVO> domainDetailsResponseVOList = new ArrayList<>();
        domainDetailsResponseVOList.add(domainDetailsResponseVO);
        domainDetailsResListSO.setDomainDetailsResponseVOList(domainDetailsResponseVOList);
        return ResponseEntity.ok().body(domainDetailsResListSO);
    }

    private FlatMappingData getFlatMappingData() {
        FlatMappingData flatMappingData = new FlatMappingData();
        flatMappingData.setMappingDefinitions(getMappingDefinition());
        flatMappingData.setEnumMappingDefinitions(getEnumMappingDefinition());
        return flatMappingData;
    }

    private List<EnumMappingDefinition> getEnumMappingDefinition() {
        List<EnumMappingDefinition> enumMappingDefinitions = new ArrayList<>();
        EnumMappingDefinition enumMappingDefinition = new EnumMappingDefinition();
        enumMappingDefinition.setEntity("product-identifire");
        enumMappingDefinition.setSourceFormat("Ontology");
        enumMappingDefinition.setTargetFormat("JSON");
        enumMappingDefinition.setTargetValue("test-key-value");
        enumMappingDefinition.setSourceValue("test-value");
        enumMappingDefinitions.add(enumMappingDefinition);
        return enumMappingDefinitions;
    }

    private List<MappingDefinition> getMappingDefinition() {
        List<MappingDefinition> mappingDefinitions = new ArrayList<>();
        MappingDefinition mappingDefinition = new MappingDefinition();
        mappingDefinition.setEntity("Instrument");
        mappingDefinition.setSourceSystem("Ontology");
        mappingDefinition.setTargetSystem("JSON");
        mappingDefinition.setSourceField("product-identifire");
        mappingDefinition.setTargetField("WS-OUT_REC.OUT-PROI");
        mappingDefinitions.add(mappingDefinition);
        mappingDefinition.setFormatDefination(getFormatDefination());
        return mappingDefinitions;
    }

    private FormatDefination getFormatDefination() {
        FormatDefination formatDefination = new FormatDefination();
        formatDefination.setFormatString("String");
        formatDefination.setFormatType("Enum");
        return formatDefination;
    }

    private List<EnumDetailsResponseSO> getOntologyEnumObject1() {
        List<EnumDetailsResponseSO> ontologyEnumDetailsResponseSOS = new ArrayList<>();
        EnumDetailsResponseSO ontologyEnumDetailsResponseSO = new EnumDetailsResponseSO();
        ontologyEnumDetailsResponseSO.setEnumKey("test-key");
        ontologyEnumDetailsResponseSO.setEnumKeyValue("test-value");
        ontologyEnumDetailsResponseSOS.add(ontologyEnumDetailsResponseSO);
        return ontologyEnumDetailsResponseSOS;
    }

    private List<EnumDetailsResponseSO> getOntologyEnumObject() {
        List<EnumDetailsResponseSO> ontologyEnumDetailsResponseSOS = new ArrayList<>();
        EnumDetailsResponseSO ontologyEnumDetailsResponseSO = new EnumDetailsResponseSO();
        ontologyEnumDetailsResponseSO.setEnumKey("test-key");
        ontologyEnumDetailsResponseSO.setEnumKeyValue("test-value");
        ontologyEnumDetailsResponseSO.setEnumDetailsId(1001L);
        ontologyEnumDetailsResponseSOS.add(ontologyEnumDetailsResponseSO);
        return ontologyEnumDetailsResponseSOS;
    }

    private ResponseEntity<FormatListResponseSO> getObject() {
        FormatListResponseSO formatListResponseSO = new FormatListResponseSO();
        FormatResponseSO formatResponseSO = new FormatResponseSO();
        Set<CopybookFileDetailsResponseVO> copybookFileDetailsResponseVO = Collections.emptySet();
        formatResponseSO.setFormatId(101L);
        formatResponseSO.setFormatName("JSON");
        formatResponseSO.setCopybookFileDetailsResponseVO(copybookFileDetailsResponseVO);
        FormatResponseSO formatResponseSO1 = new FormatResponseSO();
        formatResponseSO1.setFormatId(21L);
        formatResponseSO1.setFormatName("Ontology");
        formatResponseSO1.setCopybookFileDetailsResponseVO(copybookFileDetailsResponseVO);
        List<FormatResponseSO> formatResponseSOS = new ArrayList<>();
        formatResponseSOS.add(formatResponseSO);
        formatResponseSOS.add(formatResponseSO1);
        formatListResponseSO.setFormatResponseSOList(formatResponseSOS);
        return ResponseEntity.ok().body(formatListResponseSO);
    }
    private ResponseEntity<FormatListResponseSO> getObjectwithFileList() {
        FormatListResponseSO formatListResponseSO = new FormatListResponseSO();
        FormatResponseSO formatResponseSO = new FormatResponseSO();
        CopybookFileDetailsResponseVO copybookFileDetailsResponseVO = new CopybookFileDetailsResponseVO();
        copybookFileDetailsResponseVO.setCopybookFileId(18L);
        copybookFileDetailsResponseVO.setFileName("tetFile1");
        copybookFileDetailsResponseVO.setRules("testRule");
        formatResponseSO.setFormatId(101L);
        formatResponseSO.setFormatName("FPMD");
        formatResponseSO.setCopybookFileDetailsResponseVO(Collections.singleton(copybookFileDetailsResponseVO));
        FormatResponseSO formatResponseSO1 = new FormatResponseSO();
        formatResponseSO1.setFormatId(21L);
        formatResponseSO1.setFormatName("Ontology");
        formatResponseSO1.setCopybookFileDetailsResponseVO(Collections.emptySet());
        List<FormatResponseSO> formatResponseSOS = new ArrayList<>();
        formatResponseSOS.add(formatResponseSO);
        formatResponseSOS.add(formatResponseSO1);
        formatListResponseSO.setFormatResponseSOList(formatResponseSOS);
        return ResponseEntity.ok().body(formatListResponseSO);
    }


    private List<MappingDetails> getMappingDetailsObject() {
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        MappingDetails mappingDetails = new MappingDetails();
        mappingDetails.setOrderNumber(1);
        mappingDetails.setFormatId(21L);
        mappingDetails.setOntologyAttributeId(1001L);
        mappingDetails.setUbsAttributeId(2001L);
        mappingDetails.setMappingId(1L);
        mappingDetails.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails);
        MappingDetails mappingDetails1 = new MappingDetails();
        mappingDetails1.setOrderNumber(1);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setOntologyAttributeId(1001L);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setMappingId(1L);
        mappingDetails1.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails1);
        return mappingDetailsList;
    }

    private List<MappingDetails> getMappingDetailsObjectOntologyAttributeNull() {
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        MappingDetails mappingDetails = new MappingDetails();
        mappingDetails.setOrderNumber(1);
        mappingDetails.setFormatId(21L);
        mappingDetails.setMappingId(1L);
        mappingDetails.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails);
        MappingDetails mappingDetails1 = new MappingDetails();
        mappingDetails1.setOrderNumber(1);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setUbsAttributeId(2001L);
        mappingDetails1.setMappingId(1L);
        mappingDetails1.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails1);
        return mappingDetailsList;
    }

    private List<MappingDetails> getMappingDetailsObjectUbsAttributeNull() {
        List<MappingDetails> mappingDetailsList = new ArrayList<>();
        MappingDetails mappingDetails = new MappingDetails();
        mappingDetails.setOntologyAttributeId(1001L);
        mappingDetails.setOrderNumber(1);
        mappingDetails.setFormatId(21L);
        mappingDetails.setMappingId(1L);
        mappingDetails.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails);
        MappingDetails mappingDetails1 = new MappingDetails();
        mappingDetails1.setOrderNumber(1);
        mappingDetails1.setFormatId(21L);
        mappingDetails1.setMappingId(1L);
        mappingDetails1.setMappingFormat(getMappingFormat());
        mappingDetailsList.add(mappingDetails1);
        return mappingDetailsList;
    }

    private MappingFormat getMappingFormat() {
        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setFormatType("Date");
        mappingFormat.setMappingFormatReferenceId(1L);
        mappingFormat.setFormatValue("MM/DD/YYYY");
        return mappingFormat;
    }

    private MappingFormat getMappingFormat1() {
        MappingFormat mappingFormat = new MappingFormat();
        mappingFormat.setFormatType("String");
        mappingFormat.setMappingFormatReferenceId(1L);
        mappingFormat.setFormatValue("%/");
        return mappingFormat;
    }

    private Optional<MappingDetails> getMappingDetailsFormatNull() {
        MappingDetails mappingDetails1 = new MappingDetails();
        mappingDetails1.setMappingId(1L);
        mappingDetails1.setFormatId(21L);
        return Optional.of(mappingDetails1);
    }

    private Optional<MappingDetails> getMappingDetails() {
        MappingDetails mappingDetails1 = new MappingDetails();
        mappingDetails1.setMappingFormat(getMappingFormat());
        mappingDetails1.setMappingId(1L);
        mappingDetails1.setFormatId(21L);
        return Optional.of(mappingDetails1);
    }

    private MappingUpdateRequestSO getMappingUpdateRequestSOCreateRequestNull() {
        MappingUpdateRequestSO mappingUpdateRequestSO = new MappingUpdateRequestSO();
        mappingUpdateRequestSO.setFormatId(21L);
        mappingUpdateRequestSO.setMappingCreateRequestSOS(getMappingResponseSOCreateNull());
        return mappingUpdateRequestSO;
    }

    private List<MappingCreateRequestSO> getMappingResponseSOCreateNull() {
        List<MappingCreateRequestSO> mappingCreateRequestSOS = new ArrayList<>();

        mappingCreateRequestSOS.add(null);
        return mappingCreateRequestSOS;
    }

    private MappingUpdateRequestSO getMappingUpdateRequestSO() {
        MappingUpdateRequestSO mappingUpdateRequestSO = new MappingUpdateRequestSO();
        mappingUpdateRequestSO.setFormatId(21L);
        mappingUpdateRequestSO.setMappingCreateRequestSOS(getMappingResponseSO());
        return mappingUpdateRequestSO;
    }

    private MappingUpdateRequestSO getMappingUpdateRequestSO1() {
        MappingUpdateRequestSO mappingUpdateRequestSO = new MappingUpdateRequestSO();
        mappingUpdateRequestSO.setFormatId(21L);
        mappingUpdateRequestSO.setMappingCreateRequestSOS(getMappingResponseSO1());
        return mappingUpdateRequestSO;
    }

    private List<MappingCreateRequestSO> getMappingResponseSO1() {
        List<MappingCreateRequestSO> mappingCreateRequestSOS = new ArrayList<>();
        MappingCreateRequestSO mappingResponseSO = new MappingCreateRequestSO();
        mappingResponseSO.setMappingId(1L);
        mappingResponseSO.setOntologyAttributeId(1001L);
        mappingResponseSO.setUbsAttributeId(2001L);
        mappingCreateRequestSOS.add(mappingResponseSO);
        return mappingCreateRequestSOS;
    }

    private List<MappingCreateRequestSO> getMappingResponseSO() {
        List<MappingCreateRequestSO> mappingCreateRequestSOS = new ArrayList<>();
        MappingCreateRequestSO mappingResponseSO = new MappingCreateRequestSO();
        mappingResponseSO.setMappingId(1L);
        mappingResponseSO.setOntologyAttributeId(1001L);
        mappingResponseSO.setUbsAttributeId(2001L);
        mappingResponseSO.setMappingFormatReferenceId(1L);
        mappingCreateRequestSOS.add(mappingResponseSO);
        return mappingCreateRequestSOS;
    }
}
